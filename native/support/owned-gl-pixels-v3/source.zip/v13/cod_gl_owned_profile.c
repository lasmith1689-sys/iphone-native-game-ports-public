#include "cod_gl_owned_profile.h"

static int tracked(uint32_t f){return f==COD_GL_BIND_TEXTURE||f==COD_GL_GEN_TEXTURES||f==COD_GL_DELETE_TEXTURES||f==COD_GL_TEX_PARAMETER_I||
 f==COD_GL_TEX_IMAGE_2D||f==COD_GL_COMPRESSED_TEX_IMAGE_2D||f==COD_GL_TEX_SUB_IMAGE_2D||f==COD_GL_BEGIN||f==COD_GL_DRAW_ARRAYS||f==COD_GL_DRAW_ELEMENTS;}
static int upload(uint32_t f){return f==COD_GL_TEX_IMAGE_2D||f==COD_GL_COMPRESSED_TEX_IMAGE_2D||f==COD_GL_TEX_SUB_IMAGE_2D;}
static uint32_t index_of(CodGLOwnedProfileV12*p,uint32_t name){
 for(uint32_t k=0;k<COD_GL_OWNED_MAX_TEXTURES_V12;k++)if(p->textures[k].live&&p->textures[k].name==name)return k;
 return UINT32_MAX;
}
static uint32_t available(CodGLOwnedProfileV12*p){
 for(uint32_t k=0;k<COD_GL_OWNED_MAX_TEXTURES_V12;k++)if(!p->textures[k].live)return k;return UINT32_MAX;
}
static int basic_state(const CodGLOwnedProfileV12*p,const CodGLOwnedStateV12*s,int completed_pending){
 if(s->profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12||p->kind!=s->profile_kind||
   !s->context_identity||s->context_identity!=p->context_identity||!s->glstate_identity||s->glstate_identity!=p->glstate_identity||
   !s->context_generation||s->context_generation!=p->context_generation||s->esversion<2||s->esversion>3||
   !s->unit_count||s->unit_count>COD_GL_MAX_TEXTURE_UNITS||s->active_unit>=s->unit_count||!s->max_size||s->max_size>0x7fffffffu)return COD_GL_BACKEND;
 if((s->list_active||s->list_pending)&&
    (!completed_pending||s->list_active!=1u||s->list_pending!=1u))return COD_GL_ARGUMENT;
 if(s->in_begin||s->compiling||s->pbo||s->row_length||s->skip_rows||s->skip_pixels||
   s->automipmap||s->forbidden_globals||(s->alignment!=1&&s->alignment!=2&&s->alignment!=4&&s->alignment!=8)||s->requested_exists>1)return COD_GL_ARGUMENT;
 return 0;
}
static int basic(const CodGLOwnedProfileV12*p,const CodGLOwnedStateV12*s){return basic_state(p,s,0);}
static int read_state(CodGL*g,uint32_t name){
 CodGLOwnedProfileV12*p=g->owned;
 if(!p||!p->read||p->read(g->host_context,name,&p->state))return COD_GL_BACKEND;
 return basic(p,&p->state);
}
/* Complete only a finished internal Begin/End batch. Named-list recording,
 * unfinished Begin and foreign context/profile state stay refused. The actual
 * synchronous worker keeps its existing activity/current-context/fresh51 gates.
 * This is real GL4ES Finish (flush/draw/free + native GLES Finish), never a
 * private-state repair. The source packet stays in owned leased storage. */
static int prepare_begin(CodGL*g,CodGLNativeCall*c){
 CodGLOwnedProfileV12*p=g->owned;
 if(!p||!p->read||p->read(g->host_context,0,&p->state))return COD_GL_BACKEND;
 int status=basic_state(p,&p->state,1);if(status)return status;
 if(!p->state.list_active)return 0;
 if(c!=&g->packet||c->function!=COD_GL_BEGIN||c->pixels||c->owned_profile_kind||
    !g->invoke||atomic_load_explicit(&g->in_dispatch,memory_order_relaxed)!=1u)return COD_GL_BACKEND;
 CodGLNativeResult completion={0};c->function=COD_GL_FINISH;
 if(g->invoke(g->host_context,c,&completion)||read_state(g,0)){
  /* Do not reuse the packet or consume guest return/SP on uncertain completion. */
  g->failed=1;return COD_GL_BACKEND;
 }
 c->function=COD_GL_BEGIN;return 0;
}
static int fact_normal(const CodGLTextureFactV12*f){
 return f->identity&&f->name&&f->native_name&&f->target==0xde1u&&!f->forbidden&&!f->sampler_override&&
  (f->valid==0||f->valid==1)&&f->mipmap_auto<=1&&f->mipmap_need<=1&&f->mipmap_done<=1;
}
static int match(const CodGLOwnedTextureV12*r,const CodGLTextureFactV12*f){
 if(!r->live||!r->deletion_generation||!fact_normal(f)||r->name!=f->name||r->identity!=f->identity||r->native_name!=f->native_name)return COD_GL_ARGUMENT;
 if(r->width){
  if(!f->valid||f->width!=(int32_t)r->width||f->height!=(int32_t)r->height||f->nwidth!=f->width||f->nheight!=f->height||
    f->base_level!=0||f->max_level!=(int32_t)r->tail||f->mipmap_auto!=1)return COD_GL_ARGUMENT;
 }else if(f->valid||f->base_level!=-1||f->max_level!=-1||f->mipmap_auto||f->mipmap_need||f->mipmap_done)return COD_GL_ARGUMENT;
 return 0;
}
static int minfilter(uint32_t f){return f==0x2600u||f==0x2601u||(f>=0x2700u&&f<=0x2703u);}
static int mipfilter(uint32_t f){return f>=0x2700u&&f<=0x2703u;}
static int wrap(uint32_t v){return v==0x2901u||v==0x2900u||v==0x812fu||v==0x8370u;}

int cod_gl_v13_init_owned(CodGL*g,CodGLOwnedProfileV12*p,uint32_t kind,CodGLReadOwnedV12 read,
 CodGLMemory m,CodGLInvoke invoke,CodGLReadUnpack unpack,CodGLReadClient client,void*host,CodGLAllocator allocator,uint32_t scratch,uint32_t bytes){
 if(!p||!read||kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12)return COD_GL_ARGUMENT;
 CodGLOwnedStateV12 state;if(read(host,0,&state))return COD_GL_BACKEND;
 /* Bind actual worker/context identities before accepting any texture. Existing
  * backend objects are never adopted by this constructor. */
 p->kind=kind;p->context_identity=state.context_identity;p->glstate_identity=state.glstate_identity;p->context_generation=state.context_generation;
 int status=basic(p,&state);if(status)return status;
 status=cod_gl_init(g,m,invoke,unpack,client,host,allocator,scratch,bytes);if(status)return status;
 p->read=read;p->next_texture_generation=1;p->pending_index=UINT32_MAX;
 for(uint32_t k=0;k<COD_GL_OWNED_MAX_TEXTURES_V12;k++)p->textures[k].live=0;
 g->owned=p;return 0;
}

int cod_gl_owned_v13_before(CodGL*g,CodGLNativeCall*c){
 if(!g||!g->owned||!c)return COD_GL_ARGUMENT;
 uint32_t f=(uint32_t)c->function;if(!tracked(f))return 0;
 if(f==COD_GL_GEN_TEXTURES)return COD_GL_ARGUMENT; /* selected numeric-first-bind profile, not glGen-only fiction */
 CodGLOwnedProfileV12*p=g->owned;uint32_t*a=c->words;
 p->pending_index=UINT32_MAX;p->pending_new=0;p->pending_name=0;
 uint32_t request=f==COD_GL_BIND_TEXTURE?a[1]:0;int status=f==COD_GL_BEGIN?prepare_begin(g,c):read_state(g,request);if(status)return status;
 CodGLOwnedStateV12*s=&p->state;
 if(f==COD_GL_BEGIN||f==COD_GL_DRAW_ARRAYS||f==COD_GL_DRAW_ELEMENTS){
  for(uint32_t unit=0;unit<s->unit_count;unit++){
   const CodGLTextureFactV12*t=s->units+unit;if(!t->enabled_targets)continue;
   if(t->enabled_targets!=2u)return COD_GL_ARGUMENT;
   uint32_t k=index_of(p,t->name);if(k==UINT32_MAX||match(p->textures+k,t))return COD_GL_ARGUMENT;
   CodGLOwnedTextureV12*r=p->textures+k;
   if(!r->width||!minfilter(t->min_filter)||!(r->provided_mask&1u))return COD_GL_ARGUMENT;
   if(mipfilter(t->min_filter)&&r->provided_mask!=((1u<<(r->tail+1u))-1u))return COD_GL_ARGUMENT;
  }return 0;
 }
 if(f==COD_GL_BIND_TEXTURE){
  if(a[0]!=0xde1u)return COD_GL_ARGUMENT;p->pending_name=a[1];
  if(!a[1])return 0;
  uint32_t k=index_of(p,a[1]);
  if(s->requested_exists){if(k==UINT32_MAX||match(p->textures+k,&s->requested))return COD_GL_ARGUMENT;p->pending_index=k;}
  else{
   if(k!=UINT32_MAX||p->next_texture_generation==UINT64_MAX)return COD_GL_ARGUMENT;
   k=available(p);if(k==UINT32_MAX)return COD_GL_CAPACITY;p->pending_index=k;p->pending_new=1;
  }return 0;
 }
 if(f==COD_GL_DELETE_TEXTURES){
  if(a[0]>COD_GL_OWNED_MAX_TEXTURES_V12)return COD_GL_CAPACITY;
  for(uint32_t n=0;n<a[0];n++){
   if(c->names[n]){
    uint32_t k=index_of(p,c->names[n]);if(k==UINT32_MAX)return COD_GL_ARGUMENT;
    status=read_state(g,c->names[n]);if(status)return status;
    if(!p->state.requested_exists||match(p->textures+k,&p->state.requested))return COD_GL_ARGUMENT;
   }
  }
  return 0;
 }
 const CodGLTextureFactV12*t=s->units+s->active_unit;
 uint32_t k=index_of(p,t->name);if(k==UINT32_MAX||match(p->textures+k,t))return COD_GL_ARGUMENT;
 p->pending_index=k;p->pending_name=t->name;CodGLOwnedTextureV12*r=p->textures+k;
 if(f==COD_GL_TEX_PARAMETER_I){
  if(a[0]!=0xde1u)return COD_GL_ARGUMENT;
  if(a[1]==0x2801u)return minfilter(a[2])?0:COD_GL_ARGUMENT;
  if(a[1]==0x2800u)return(a[2]==0x2600u||a[2]==0x2601u)?0:COD_GL_ARGUMENT;
  if(a[1]==0x2802u||a[1]==0x2803u)return wrap(a[2])?0:COD_GL_ARGUMENT;
  return COD_GL_ARGUMENT; /* profile owns BASE/MAX/GENERATE; other setters unselected */
 }
 if(f==COD_GL_TEX_SUB_IMAGE_2D){
  if(a[0]!=0xde1u || a[1] || a[2] || a[3] || !cod_gl_cinematic_shape_v13(a[4],a[5]) ||
     a[6]!=0x1908u || a[7]!=0x1401u || !c->pixels ||
     r->width!=a[4] || r->height!=a[5] || r->tail || r->provided_mask!=1u ||
     c->owned_unpack_alignment!=s->alignment)return COD_GL_ARGUMENT;
  c->owned_profile_kind=p->kind;c->owned_profile_tail=COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1;
  c->owned_texture_identity=t->identity;c->owned_glstate_identity=s->glstate_identity;
  c->owned_context_identity=s->context_identity;c->owned_context_generation=s->context_generation;
  c->owned_texture_name=t->name;c->owned_native_texture_name=t->native_name;return 0;
 }
 if(upload(f)){
  uint32_t level=a[1],w=a[3],h=a[4];
  if(a[0]!=0xde1u||level>=COD_GL_OWNED_LEVELS_V12||!w||!h||w>8192||h>8192||w>s->max_size||h>s->max_size||
    (w&(w-1u))||(h&(h-1u))||a[5]||!c->pixels)return COD_GL_ARGUMENT;
  uint32_t tail=0,largest=w>h?w:h;
  if(!level){while(largest>1){tail++;largest>>=1;}
   /* Newly admitted original cinematic tuple is a single-level texture.
    * Existing matched-format texture paths retain their original mip tails. */
   if(f==COD_GL_TEX_IMAGE_2D && a[2]==3u && a[6]==0x1908u && cod_gl_cinematic_shape_v13(w,h))tail=0;
  }
  else{
   if(!r->width||level>r->tail)return COD_GL_ARGUMENT;tail=r->tail;
   uint32_t ew=r->width>>level,eh=r->height>>level;if(!ew)ew=1;if(!eh)eh=1;
   if(w!=ew||h!=eh)return COD_GL_ARGUMENT;
  }
  p->pending_width=w;p->pending_height=h;p->pending_level=level;p->pending_tail=tail;
  if(c->owned_unpack_alignment!=s->alignment)return COD_GL_ARGUMENT;
  c->owned_profile_kind=p->kind;c->owned_profile_tail=tail;
  c->owned_texture_identity=t->identity;c->owned_glstate_identity=s->glstate_identity;
  c->owned_context_identity=s->context_identity;c->owned_context_generation=s->context_generation;
  c->owned_texture_name=t->name;c->owned_native_texture_name=t->native_name;return 0;
 }
 return COD_GL_ARGUMENT;
}

int cod_gl_owned_v13_verify_worker_call(const CodGLNativeCall*c,const CodGLOwnedStateV12*s){
 if(!c||!s)return COD_GL_BACKEND;
 uint32_t variant=c->owned_profile_tail&COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1;
 if(!variant && c->function==COD_GL_TEX_IMAGE_2D && !c->words[2])return COD_GL_BACKEND;
 if(c->function==COD_GL_TEX_SUB_IMAGE_2D)return COD_GL_BACKEND; /* guest selector is never a worker packet */
 if(variant){const uint32_t*a=c->words;
  if(c->function!=COD_GL_TEX_IMAGE_2D || c->owned_profile_tail!=COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1 ||
     a[0]!=0xde1u || a[1] || a[2] || a[3] || !cod_gl_cinematic_shape_v13(a[4],a[5]) || a[6]!=0x1908u || a[7]!=0x1401u || !c->pixels ||
     !s->unit_count || s->active_unit>=s->unit_count || s->active_unit>=COD_GL_MAX_TEXTURE_UNITS)return COD_GL_BACKEND;
  const CodGLTextureFactV12*t=s->units+s->active_unit;
  if(!t->valid || t->width!=(int32_t)a[4] || t->height!=(int32_t)a[5] || t->nwidth!=t->width || t->nheight!=t->height ||
     t->base_level || t->max_level || t->mipmap_auto!=1)return COD_GL_BACKEND;
 }

 if(!c||!s||!upload((uint32_t)c->function)||c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12||
    s->profile_kind!=c->owned_profile_kind||!c->owned_context_generation||s->context_generation!=c->owned_context_generation||
    s->context_identity!=c->owned_context_identity||s->glstate_identity!=c->owned_glstate_identity||
    !s->unit_count||s->unit_count>COD_GL_MAX_TEXTURE_UNITS||s->active_unit>=s->unit_count||s->esversion<2||s->esversion>3||
    s->alignment!=c->owned_unpack_alignment||s->in_begin||s->compiling||s->list_active||s->list_pending||s->pbo||
    s->row_length||s->skip_rows||s->skip_pixels||s->automipmap||s->forbidden_globals||(c->owned_profile_tail&~COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1)>=14)return COD_GL_BACKEND;
 const CodGLTextureFactV12*t=s->units+s->active_unit;
 if(!fact_normal(t)||t->identity!=c->owned_texture_identity||t->name!=c->owned_texture_name||t->native_name!=c->owned_native_texture_name)return COD_GL_BACKEND;
 return 0;
}

int cod_gl_owned_v13_after(CodGL*g,CodGLNativeCall*c){
 if(!g||!g->owned||!c)return COD_GL_BACKEND;uint32_t f=(uint32_t)c->function;
 if(f==COD_GL_TEX_IMAGE_2D && (c->owned_profile_tail&COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1))f=COD_GL_TEX_SUB_IMAGE_2D;
 if(f!=COD_GL_BIND_TEXTURE&&f!=COD_GL_DELETE_TEXTURES&&f!=COD_GL_TEX_PARAMETER_I&&!upload(f))return 0;
 CodGLOwnedProfileV12*p=g->owned;
 if(f==COD_GL_DELETE_TEXTURES){
  for(uint32_t n=0;n<c->words[0];n++)if(c->names[n]){
   if(read_state(g,c->names[n])||p->state.requested_exists)return COD_GL_BACKEND;
  }
  for(uint32_t n=0;n<c->words[0];n++){uint32_t k=index_of(p,c->names[n]);if(k!=UINT32_MAX)p->textures[k].live=0;}
  return 0;
 }
 if(read_state(g,p->pending_name))return COD_GL_BACKEND;
 const CodGLTextureFactV12*t=p->state.units+p->state.active_unit;
 if(!p->pending_name)return t->name?COD_GL_BACKEND:0;
 if(!p->state.requested_exists||t->name!=p->pending_name||t->identity!=p->state.requested.identity||!fact_normal(t))return COD_GL_BACKEND;
 if(p->pending_index>=COD_GL_OWNED_MAX_TEXTURES_V12)return COD_GL_BACKEND;
 CodGLOwnedTextureV12*r=p->textures+p->pending_index;
 if(f==COD_GL_BIND_TEXTURE&&p->pending_new){
  if(t->valid||t->base_level!=-1||t->max_level!=-1||t->mipmap_auto||t->mipmap_need||t->mipmap_done)return COD_GL_BACKEND;
  r->live=1;r->identity=t->identity;r->name=t->name;r->native_name=t->native_name;
  r->deletion_generation=p->next_texture_generation++;r->width=r->height=r->tail=r->provided_mask=0;return 0;
 }
 if(f==COD_GL_TEX_SUB_IMAGE_2D){
  /* No new mip level or texture storage is created by this exact full-level update. */
  return match(r,t) || r->width!=c->words[4] || r->height!=c->words[5] || r->tail || r->provided_mask!=1u ? COD_GL_BACKEND : 0;
 }
 if(upload(f)){
  if(t->identity!=r->identity||t->native_name!=r->native_name||!t->valid||t->base_level||t->max_level!=(int32_t)p->pending_tail||t->mipmap_auto!=1)return COD_GL_BACKEND;
  if(!p->pending_level){
   if(t->width!=(int32_t)p->pending_width||t->height!=(int32_t)p->pending_height||t->nwidth!=t->width||t->nheight!=t->height)return COD_GL_BACKEND;
   r->width=p->pending_width;r->height=p->pending_height;r->tail=p->pending_tail;r->provided_mask=1;
  }else{if(match(r,t))return COD_GL_BACKEND;r->provided_mask|=1u<<p->pending_level;}
  return 0;
 }
 if(match(r,t))return COD_GL_BACKEND;
 if(f==COD_GL_TEX_PARAMETER_I){
  uint32_t pname=c->words[1],v=c->words[2];
  if((pname==0x2801u&&t->min_filter!=v)||(pname==0x2800u&&t->mag_filter!=v)||
    (pname==0x2802u&&t->wrap_s!=v)||(pname==0x2803u&&t->wrap_t!=v))return COD_GL_BACKEND;
 }return 0;
}
