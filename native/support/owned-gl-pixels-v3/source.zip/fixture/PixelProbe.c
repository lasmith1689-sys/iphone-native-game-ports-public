/* Self-authored support fixture. No engine, recovered code, or retail assets. */
#include "PixelProbe.h"
#include "cod_gl_dispatch.h"
#include "cod_gl_owned_profile.h"
#include "cod_gl_fresh51_policy_v1.h"
#include <stdlib.h>
#include <string.h>
/* Also permits syntax checking on Windows; implementation is Darwin libc. */
extern int posix_memalign(void **,size_t,size_t);
_Static_assert(COD_GL_BRIDGE_ABI_VERSION==13 && COD_GL_FUNCTION_COUNT==57,"exact ABI13 plus Normal3f feature cohort");
extern int cod_gl_v13_gl4es_execute(CodGLNativeCall*,CodGLNativeResult*);
extern int cod_gl_v13_gl4es_read_unpack(CodGLUnpackState*);
extern int cod_gl_v13_gl4es_read_client(CodGLClientState*);
extern int cod_gl_v13_gl4es_read_owned(uint32_t,CodGLOwnedStateV12*);
static uint8_t memory[0x1100],registers[20],pixels[64*64*4];
static CodGL bridge;
static CodGLOwnedProfileV12 profile;
static uintptr_t actual_context;
static OwnedGLResult *report;
static int started;
static const CodGLRange ranges[]={{0x100,0x400,3},{0x800,0x100,2},{0x1000,0x100,1}};
#define NEED(x) do {if(!(x)){report->failure_line=__LINE__;return 1;}}while(0)
static void word(uint8_t*p,uint32_t x){memcpy(p,&x,4);}
static uint32_t bits(float x){uint32_t b;memcpy(&b,&x,4);return b;}
static int read_unpack(void *p,CodGLUnpackState*s){(void)p;return owned_native_context_current()?cod_gl_v13_gl4es_read_unpack(s):COD_GL_BACKEND;}
static int read_client(void *p,CodGLClientState*s){(void)p;return owned_native_context_current()?cod_gl_v13_gl4es_read_client(s):COD_GL_BACKEND;}
static int read_owned(void*p,uint32_t name,CodGLOwnedStateV12*s){
 (void)p;if(!owned_native_context_current())return COD_GL_BACKEND;
 int rc=cod_gl_v13_gl4es_read_owned(name,s);if(rc)return rc;
 s->context_identity=actual_context;s->context_generation=1;s->profile_kind=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12;return 0;
}
static void *allocate(void*p,uint32_t n,uint32_t alignment){
 (void)p;void*out=0;if(!n||n>1024||alignment!=16||posix_memalign(&out,alignment,n))return 0;
 report->allocations++;return out;
}
static void release(void*p,void*x){(void)p;report->releases++;free(x);}
static int invoke(void*p,CodGLNativeCall*c,CodGLNativeResult*r){
 (void)p;report->last_native_function=(uint32_t)c->function;report->last_invoked=1;if(!owned_native_context_current()||cod_gl_fresh51_command_refused_v1(c))return COD_GL_BACKEND;
 if(c->owned_profile_kind){CodGLOwnedStateV12 s;if(read_owned(0,0,&s)||cod_gl_owned_v13_verify_worker_call(c,&s))return COD_GL_BACKEND;}
 if(c->function==COD_GL_TEX_IMAGE_2D && c->words[2]==0x1907u){
  static const uint8_t expected[12]={255,0,0,0,255,0,0,0,255,255,255,0};
  if(!c->pixels||c->words[3]!=2||c->words[4]!=2||memcmp(c->pixels,expected,12))return COD_GL_BACKEND;
  report->rgb_staging_verified++;
 }
 int rc=cod_gl_v13_gl4es_execute(c,r);if(rc)return rc;report->last_executed=1;
 if(c->function==COD_GL_FINISH&&report->last_token==cod_gl_v13_token("glBegin")){
  /* The candidate invokes the actual Finish executor on this same context;
   * separately observe native completion before allowing the enclosing Begin. */
  if(!owned_native_finish()){report->failure_stage=3;return COD_GL_BACKEND;}
  report->native_finishes++;report->internal_drains++;
 }
 if((c->function==COD_GL_TEX_IMAGE_2D&&c->pixels)||c->function==COD_GL_DRAW_ARRAYS||c->function==COD_GL_DRAW_ELEMENTS){
  if(!owned_native_finish())return COD_GL_BACKEND;report->native_finishes++;
  if(c->pixels)r->pixel_effect=COD_GL_PIXELS_COMPLETED_V12;
 }
 return 0;
}
static int send(const char*name,const uint32_t*a,uint32_t count){
 uint32_t token=cod_gl_v13_token(name);if(!token||count>12)return 1;
 /* Observational snapshot only: these exact matching-layout reads do not
  * query GL, drain lists, or change the selected support admission policy. */
 report->attempts++;report->last_token=token;report->last_argc=count;
 memset(report->last_packet,0,sizeof(report->last_packet));
 size_t name_bytes=strlen(name);if(name_bytes>=sizeof(report->last_packet))return 1;
 memcpy(report->last_packet,name,name_bytes);
 memset(report->last_words,0,sizeof(report->last_words));
 for(uint32_t i=0;i<count;i++)report->last_words[i]=a[i];
 report->last_invoked=report->last_executed=report->failure_stage=0;report->last_native_function=UINT32_MAX;
 CodGLClientState observed_client={0};
 report->last_client_status=(uint32_t)read_client(0,&observed_client);
 report->last_in_begin=observed_client.in_begin;report->last_compiling=observed_client.compiling;
 report->last_active=observed_client.list_active;report->last_pending=observed_client.list_pending;
 memset(registers,0,sizeof(registers));word(registers+16,0x100);word(memory+0x100,0x11223344);
 for(uint32_t i=0;i<count;i++)word(memory+0x104+4*i,a[i]);
 int rc=cod_gl_v13_dispatch(&bridge,token,registers,sizeof(registers));report->bridge_status=(uint32_t)rc;
 uint32_t sp;memcpy(&sp,registers+16,4);report->last_return_sp=sp;
 if(rc){report->failure_stage=1;return 1;}
 if(sp!=0x104+4*count){report->failure_stage=2;return 1;}
 report->packet_count++;
 if(!strcmp(name,"glFinish"))report->finish_packets++;
 if(!strcmp(name,"glScissor"))report->scissor_packets++;
 if(!strcmp(name,"glOrtho"))report->ortho_packets++;
 if(!strcmp(name,"glAlphaFunc"))report->alpha_packets++;
 if(!strcmp(name,"glNormal3f"))report->normal_packets++;
 return 0;
}
static int one(const char*n,uint32_t x){return send(n,&x,1);}
static int floats(const char*n,float a,float b,float c,float d,uint32_t count){uint32_t w[4]={bits(a),bits(b),bits(c),bits(d)};return send(n,w,count);}
static int clear(void){return floats("glClearColor",0,0,0,1,4)||one("glClear",0x4000);}
static int quad(float x0,float y0,float x1,float y1){
 const float xy[4][2]={{x0,y0},{x1,y0},{x1,y1},{x0,y1}},uv[4][2]={{0,0},{1,0},{1,1},{0,1}};
 if(one("glBegin",7))return 1;
 for(uint32_t i=0;i<4;i++)if(floats("glTexCoord2f",uv[i][0],uv[i][1],0,0,2)||floats("glVertex3f",xy[i][0],xy[i][1],0,0,3))return 1;
 return send("glEnd",0,0);
}
static int finish_only(void){
 if(send("glFinish",0,0))return 1;
 if(!owned_native_finish()){report->failure_stage=3;return 1;}
 report->native_finishes++;return 0;
}
static int finish_read(void){
 if(finish_only())return 1;
 if(!owned_native_read_pixels(pixels,sizeof(pixels)))return 1;
 if(send("glGetError",0,0))return 1;uint32_t err;memcpy(&err,registers,4);return err!=0;
}
static int sample(uint32_t x,uint32_t y,uint8_t r,uint8_t g,uint8_t b){
 if(report->sample_count>=16)return 1;
 OwnedGLSample*s=report->samples+report->sample_count++;s->x=x;s->y=y;s->phase=report->phase;
 s->expected[0]=r;s->expected[1]=g;s->expected[2]=b;s->expected[3]=255;memcpy(s->actual,pixels+4*(y*64+x),4);s->matched=1;
 for(uint32_t i=0;i<4;i++){int delta=(int)s->actual[i]-s->expected[i];if(delta< -5||delta>5)s->matched=0;}
 return !s->matched;
}
static int texture(uint32_t name,uint32_t format,const uint8_t rgba[16]){
 const uint32_t bind[2]={0xde1,name};if(send("glBindTexture",bind,2))return 1;
 memcpy(memory+0x1000,rgba,16);const uint32_t upload[9]={0xde1,0,format,2,2,0,0x1908,0x1401,0x1000};
 if(send("glTexImage2D",upload,9))return 1;
 const uint32_t params[4][3]={{0xde1,0x2801,0x2600},{0xde1,0x2800,0x2600},{0xde1,0x2802,0x812f},{0xde1,0x2803,0x812f}};
 for(uint32_t i=0;i<4;i++)if(send("glTexParameteri",params[i],3))return 1;return 0;
}
static int material(uint32_t pname,float a,float b,float c,float d){
 float v[4]={a,b,c,d};memcpy(memory+0x200,v,16);const uint32_t args[3]={0x404,pname,0x200};return send("glMaterialfv",args,3);
}
int owned_gl_pixels(uintptr_t context,OwnedGLResult*out){
 if(!out||started||!context||!owned_native_context_current())return 1;started=1;report=out;memset(out,0,sizeof(*out));actual_context=context;
 const CodGLMemory guest={memory,ranges,3};const CodGLAllocator allocator={0,allocate,release};
 NEED(!cod_gl_v13_init_owned(&bridge,&profile,COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12,read_owned,guest,invoke,read_unpack,read_client,0,allocator,0x800,0x100));
 NEED(!one("glDisable",0xb71)&&!one("glDisable",0xbe2)&&!one("glDisable",0xb44)&&!one("glDisable",0xbd0));
 const uint32_t viewport[4]={0,0,64,64};NEED(!send("glViewport",viewport,4));
 NEED(!one("glMatrixMode",0x1701)&&!send("glLoadIdentity",0,0));
 const double ortho[6]={0,64,0,64,-1,1};uint32_t ortho_words[12];memcpy(ortho_words,ortho,sizeof(ortho));NEED(!send("glOrtho",ortho_words,12));
 NEED(!one("glMatrixMode",0x1700)&&!send("glLoadIdentity",0,0));
 const uint32_t unpack[2]={0xcf5,1};NEED(!send("glPixelStorei",unpack,2));
 static const uint8_t rgb_source[16]={255,0,0,0,0,255,0,0,0,0,255,0,255,255,0,0};
 NEED(!texture(7,0x1907,rgb_source));NEED(!clear());
 const uint32_t scissor[4]={24,16,16,32},alpha[2]={0x204,0x3f000000};
 NEED(!send("glScissor",scissor,4)&&!one("glEnable",0xc11)&&!send("glAlphaFunc",alpha,2)&&!one("glEnable",0xbc0)&&!one("glEnable",0xde1));
 NEED(!floats("glColor4f",1,1,1,1,4));const uint32_t env[3]={0x2300,0x2200,0x2100};NEED(!send("glTexEnvi",env,3));
 report->phase=1;NEED(!quad(16,16,48,48)&&!finish_read());
 NEED(!sample(28,24,255,0,0)&&!sample(36,24,0,255,0)&&!sample(28,40,0,0,255)&&!sample(36,40,255,255,0));
 NEED(!sample(20,24,0,0,0)&&!sample(44,24,0,0,0)&&!sample(28,8,0,0,0)&&!sample(28,56,0,0,0));
 static const uint8_t rgba_source[16]={255,0,0,0,0,255,0,255,0,0,255,0,255,255,0,255};
 NEED(!texture(8,0x1908,rgba_source));NEED(!one("glDisable",0xc11)&&!clear()&&!one("glEnable",0xc11));
 report->phase=2;NEED(!quad(16,16,48,48)&&!finish_read());
 NEED(!sample(28,24,0,0,0)&&!sample(36,24,0,255,0)&&!sample(28,40,0,0,0)&&!sample(36,40,255,255,0));
 NEED(!one("glDisable",0xbc0)&&!one("glDisable",0xc11)&&!one("glDisable",0xde1)&&!clear());
 float ambient[4]={0,0,0,1};memcpy(memory+0x200,ambient,16);const uint32_t light_model[2]={0xb53,0x200};NEED(!send("glLightModelfv",light_model,2));
 NEED(!material(0x1602,1,1,1,1)&&!material(0x1202,0,0,0,1)&&!material(0x1600,0,0,0,1));
 NEED(!one("glEnable",0xb50)&&!one("glEnable",0x4000));
 report->phase=3;NEED(!floats("glNormal3f",0,0,1,0,3)&&!quad(8,20,24,44));
 /* Deliberately consecutive: the support candidate must genuinely drain
  * its completed pending internal list before accepting the next Begin. */
 NEED(!floats("glNormal3f",0,0,-1,0,3)&&!quad(40,20,56,44)&&!finish_read());
 NEED(!sample(16,32,255,255,255)&&!sample(48,32,0,0,0));
 NEED(report->rgb_staging_verified==1&&report->allocations==report->releases&&report->sample_count==14&&report->normal_packets==2&&report->internal_drains==1);
 report->all_samples_match=1;return 0;
}
