#ifndef OWNED_GL_PIXEL_PROBE_H
#define OWNED_GL_PIXEL_PROBE_H
#include <stdint.h>
#include <stddef.h>
typedef struct {
 uint32_t x,y;uint8_t actual[4],expected[4];uint32_t matched,phase;
} OwnedGLSample;
typedef struct {
 uint32_t failure_line,bridge_status,phase,sample_count,packet_count;
 uint32_t native_finishes,finish_packets,scissor_packets,ortho_packets,alpha_packets,normal_packets;
 uint32_t rgb_staging_verified,allocations,releases,all_samples_match;
 uint32_t attempts,last_token,last_argc,last_words[12],last_return_sp;
 uint32_t last_client_status,last_in_begin,last_compiling,last_active,last_pending;
 uint32_t last_invoked,last_executed,failure_stage,last_native_function,internal_drains;
 char last_packet[32];
 OwnedGLSample samples[16];
} OwnedGLResult;
int owned_gl_pixels(uintptr_t context,OwnedGLResult *result);
int owned_native_context_current(void);
int owned_native_finish(void);
int owned_native_read_pixels(uint8_t *pixels,size_t bytes);
#endif
