/* Self-authored, explicitly requested Simulator-only GL4ES pixel fixture. */
#define GLES_SILENCE_DEPRECATION
#import <TargetConditionals.h>
#if !TARGET_OS_SIMULATOR
#error This fixture must never be compiled for a physical device
#endif
#import <UIKit/UIKit.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES2/gl.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <string.h>
#include <gl4esinit.h>
#include "PixelProbe.h"
static EAGLContext *ownedContext;
static void *nativeLibrary;
static GLuint framebuffer,color;
static void (*nFinish)(void);
static GLenum (*nGetError)(void);
static void (*nReadPixels)(GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,void*);
static void (*nGenFramebuffers)(GLsizei,GLuint*);
static void (*nBindFramebuffer)(GLenum,GLuint);
static void (*nGenTextures)(GLsizei,GLuint*);
static void (*nBindTexture)(GLenum,GLuint);
static void (*nTexParameteri)(GLenum,GLenum,GLint);
static void (*nTexImage2D)(GLenum,GLint,GLint,GLsizei,GLsizei,GLint,GLenum,GLenum,const void*);
static void (*nFramebufferTexture2D)(GLenum,GLenum,GLenum,GLuint,GLint);
static GLenum (*nCheckFramebufferStatus)(GLenum);
static OwnedGLResult observed;
static BOOL requested,attempted;
static void bindDefault(GLenum target,GLuint value){nBindFramebuffer(target,value?value:framebuffer);}
static void *lookupNative(const char*name){
 if(!strcmp(name,"glShadeModel"))return NULL; /* ES2 must not receive ES1 entrypoints. */
 if(!strcmp(name,"glBindFramebuffer")||!strcmp(name,"glBindFramebufferOES"))return (void*)bindDefault;
 return dlsym(nativeLibrary,name);
}
static void nativeSize(int*w,int*h){*w=64;*h=64;}
int owned_native_context_current(void){
 return [NSThread isMainThread]&&ownedContext&&[EAGLContext currentContext]==ownedContext&&UIApplication.sharedApplication.applicationState==UIApplicationStateActive;
}
int owned_native_finish(void){if(!owned_native_context_current())return 0;nFinish();return nGetError()==GL_NO_ERROR;}
int owned_native_read_pixels(uint8_t*out,size_t size){
 if(!out||size!=64u*64u*4u||!owned_native_context_current())return 0;
 nBindFramebuffer(GL_FRAMEBUFFER,framebuffer);nReadPixels(0,0,64,64,GL_RGBA,GL_UNSIGNED_BYTE,out);return nGetError()==GL_NO_ERROR;
}
static BOOL createContext(void){
 if(ownedContext||!NSThread.isMainThread||getenv("LIBGL_VERSION"))return NO;
 const char *names[]={"LIBGL_MIPMAP","LIBGL_SHRINK","LIBGL_TEXCOPY","LIBGL_TEXDUMP","LIBGL_FORCE16BITS","LIBGL_AVOID24BITS","LIBGL_STREAM","LIBGL_NOLUMALPHA","LIBGL_FORCENPOT","LIBGL_NOERROR"};
 for(unsigned i=0;i<sizeof(names)/sizeof(names[0]);i++)if(setenv(names[i],"0",1))return NO;
 ownedContext=[[EAGLContext alloc]initWithAPI:kEAGLRenderingAPIOpenGLES2];
 if(!ownedContext||![EAGLContext setCurrentContext:ownedContext])return NO;
 nativeLibrary=dlopen("/System/Library/Frameworks/OpenGLES.framework/OpenGLES",RTLD_NOW|RTLD_LOCAL);
 if(!nativeLibrary)return NO;
 /* Bind native GLES explicitly; static GL4ES exports must not intercept these. */
 nFinish=(__typeof__(nFinish))dlsym(nativeLibrary,"glFinish");if(!nFinish)return NO;
 nGetError=(__typeof__(nGetError))dlsym(nativeLibrary,"glGetError");if(!nGetError)return NO;
 nReadPixels=(__typeof__(nReadPixels))dlsym(nativeLibrary,"glReadPixels");if(!nReadPixels)return NO;
 nGenFramebuffers=(__typeof__(nGenFramebuffers))dlsym(nativeLibrary,"glGenFramebuffers");if(!nGenFramebuffers)return NO;
 nBindFramebuffer=(__typeof__(nBindFramebuffer))dlsym(nativeLibrary,"glBindFramebuffer");if(!nBindFramebuffer)return NO;
 nGenTextures=(__typeof__(nGenTextures))dlsym(nativeLibrary,"glGenTextures");if(!nGenTextures)return NO;
 nBindTexture=(__typeof__(nBindTexture))dlsym(nativeLibrary,"glBindTexture");if(!nBindTexture)return NO;
 nTexParameteri=(__typeof__(nTexParameteri))dlsym(nativeLibrary,"glTexParameteri");if(!nTexParameteri)return NO;
 nTexImage2D=(__typeof__(nTexImage2D))dlsym(nativeLibrary,"glTexImage2D");if(!nTexImage2D)return NO;
 nFramebufferTexture2D=(__typeof__(nFramebufferTexture2D))dlsym(nativeLibrary,"glFramebufferTexture2D");if(!nFramebufferTexture2D)return NO;
 nCheckFramebufferStatus=(__typeof__(nCheckFramebufferStatus))dlsym(nativeLibrary,"glCheckFramebufferStatus");if(!nCheckFramebufferStatus)return NO;

 nGenFramebuffers(1,&framebuffer);nBindFramebuffer(GL_FRAMEBUFFER,framebuffer);
 nGenTextures(1,&color);nBindTexture(GL_TEXTURE_2D,color);nTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);nTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
 nTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,64,64,0,GL_RGBA,GL_UNSIGNED_BYTE,NULL);
 nFramebufferTexture2D(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_TEXTURE_2D,color,0);
 if(!framebuffer||!color||nCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE||nGetError()!=GL_NO_ERROR)return NO;
 set_getprocaddress(lookupNative);set_getmainfbsize(nativeSize);initialize_gl4es();return YES;
}
static void writeReport(NSString*status,NSString*detail){
 NSMutableArray*rows=[NSMutableArray array];
 for(uint32_t i=0;i<observed.sample_count&&i<16;i++){
  OwnedGLSample*s=&observed.samples[i];
  [rows addObject:@{@"phase":@(s->phase),@"x":@(s->x),@"y":@(s->y),@"actual":@[@(s->actual[0]),@(s->actual[1]),@(s->actual[2]),@(s->actual[3])],@"expected":@[@(s->expected[0]),@(s->expected[1]),@(s->expected[2]),@(s->expected[3])],@"matched":(s->matched?@YES:@NO)}];
 }
 NSMutableArray*words=[NSMutableArray array];
 for(uint32_t i=0;i<observed.last_argc&&i<12;i++)[words addObject:@(observed.last_words[i])];
 NSDictionary*packet=@{@"attempt":@(observed.attempts),@"name":[NSString stringWithUTF8String:observed.last_packet],
 @"token":@(observed.last_token),@"words":words,@"argc":@(observed.last_argc),@"returnSp":@(observed.last_return_sp),
 @"clientReadStatus":@(observed.last_client_status),@"inBegin":@(observed.last_in_begin),@"compiling":@(observed.last_compiling),
 @"listActive":@(observed.last_active),@"listPending":@(observed.last_pending),
 @"invokeEntered":(observed.last_invoked?@YES:@NO),@"executorReturned":(observed.last_executed?@YES:@NO),@"failureStage":@(observed.failure_stage)};
 NSDictionary*r=@{@"schema":@"owned-gl-pixels-v2",@"lastPacket":packet,@"status":status,@"detail":detail,@"simulator":@YES,@"engineLoaded":@NO,@"retailAssetsLoaded":@NO,@"presentationObserved":@NO,@"offscreenOnly":@YES,
 @"failureLine":@(observed.failure_line),@"bridgeStatus":@(observed.bridge_status),@"phase":@(observed.phase),@"packetCount":@(observed.packet_count),@"nativeFinishCount":@(observed.native_finishes),@"finishPackets":@(observed.finish_packets),@"scissorPackets":@(observed.scissor_packets),@"orthoPackets":@(observed.ortho_packets),@"alphaPackets":@(observed.alpha_packets),@"normalPackets":@(observed.normal_packets),@"rgbStagingVerified":(observed.rgb_staging_verified==1?@YES:@NO),@"allocations":@(observed.allocations),@"releases":@(observed.releases),@"allSamplesMatch":(observed.all_samples_match?@YES:@NO),@"samples":rows};
 NSError*error=nil;NSData*data=[NSJSONSerialization dataWithJSONObject:r options:NSJSONWritingPrettyPrinted error:&error];
 NSURL*directory=[NSFileManager.defaultManager URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask].firstObject;
 if(data&&directory)[data writeToURL:[directory URLByAppendingPathComponent:@"owned-gl-pixels.json"] options:NSDataWritingAtomic error:&error];
}
@interface OwnedGLScene:NSObject<UIWindowSceneDelegate>
@property(nonatomic,strong)UIWindow*window;
@property(nonatomic,strong)UILabel*label;
@property(nonatomic)NSUInteger ticks;
@end
@implementation OwnedGLScene
- (void)poll{
 if(attempted||!requested)return;
 UIWindowScene*scene=self.window.windowScene;
 if(self.ticks++>=100){attempted=YES;self.label.text=@"Foreground readiness timed out";writeReport(@"failed",@"foreground-readiness-deadline");return;}
 CGRect b=self.window.bounds;
 BOOL ready=NSThread.isMainThread&&scene&&scene.activationState==UISceneActivationStateForegroundActive&&UIApplication.sharedApplication.applicationState==UIApplicationStateActive&&self.window.isKeyWindow&&!self.window.hidden&&b.size.width>0&&b.size.height>0&&scene.traitCollection.displayScale>0;
 if(!ready){dispatch_after(dispatch_time(DISPATCH_TIME_NOW,(int64_t)(0.1*NSEC_PER_SEC)),dispatch_get_main_queue(),^{[self poll];});return;}
 attempted=YES;
 if(!createContext()){self.label.text=@"GL context setup failed";writeReport(@"failed",@"native-context-or-framebuffer");return;}
 int failed=owned_gl_pixels((uintptr_t)(__bridge void*)ownedContext,&observed);
 self.label.text=failed?@"GL pixel fixture failed":@"GL pixels matched\nRGB, scissor, alpha, ortho, normals";
 writeReport(failed?@"failed":@"passed",failed?@"packet-or-pixel-check":@"actual-offscreen-pixels");
 /* The single context, bridge, native framebuffer and any uncertain upload
  * storage remain retained until this dedicated Simulator process is retired. */
}
- (void)scene:(UIScene*)scene willConnectToSession:(UISceneSession*)session options:(UISceneConnectionOptions*)options{
 (void)session;(void)options;if(![scene isKindOfClass:UIWindowScene.class])return;
 self.window=[[UIWindow alloc]initWithWindowScene:(UIWindowScene*)scene];UIViewController*c=[UIViewController new];c.view.backgroundColor=UIColor.blackColor;
 self.label=[[UILabel alloc]initWithFrame:c.view.bounds];self.label.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;self.label.numberOfLines=0;self.label.textAlignment=NSTextAlignmentCenter;self.label.textColor=UIColor.whiteColor;self.label.text=requested?@"Waiting for owned GL fixture":@"Explicit fixture argument required";
 [c.view addSubview:self.label];self.window.rootViewController=c;[self.window makeKeyAndVisible];[self poll];
}
- (void)sceneDidBecomeActive:(UIScene*)scene{(void)scene;[self poll];}
@end
@interface OwnedGLApp:NSObject<UIApplicationDelegate>@end
@implementation OwnedGLApp
- (BOOL)application:(UIApplication*)application didFinishLaunchingWithOptions:(NSDictionary*)options{(void)application;(void)options;return YES;}
@end
int main(int argc,char**argv){@autoreleasepool{for(int i=1;i<argc;i++)if(!strcmp(argv[i],"--owned-gl-pixel-probe-v2"))requested=YES;return UIApplicationMain(argc,argv,nil,NSStringFromClass(OwnedGLApp.class));}}
