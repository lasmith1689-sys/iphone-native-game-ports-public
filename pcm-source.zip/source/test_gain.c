
#include "stereo_gain.h"
#include "ngp_voice_gain_balance_v2.h"
#include <pthread.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"line%u %s\n",__LINE__,#x);exit(1);}}while(0)
static NgpVoiceServiceV1 *service;
static NgpVoiceReportV1 vr(void){NgpVoiceReportV1 r={.version=1,.size=sizeof r};return r;}
static void *worker(void *unused){
 (void)unused;NgpVoiceReportV1 r=vr();NgpVoiceHandleV1 h=0;
 CHECK(!ngp_voice_service_v1_prepare(service,&r));CHECK(!ngp_voice_service_v1_acquire(service,1,&h,&r));
 float input[8192];for(unsigned i=0;i<8192;i++)input[i]=.125f;
 NgpVoicePcmV1 pcm={.version=1,.size=sizeof pcm,.format=NGP_VOICE_PCM_F32_V1,.channels=2,.sample_rate=44100,.bytes=input,.byte_count=sizeof input,.frame_count=4096};
 CHECK(!ngp_voice_service_v1_bind_pcm(service,h,&pcm,&r));memset(input,0,sizeof input);
 CHECK(!ngp_voice_service_v1_set_looping(service,h,1,&r));CHECK(!ngp_voice_service_v1_enable(service,&r));CHECK(!ngp_voice_service_v1_play(service,h,&r));
 const float volumes[]={0,.125f,.25f,.5f,.75f,1,2},pans[]={0,.125f,.25f,.5f,.75f,.875f,1};
 unsigned cases=0;float maximum=0;puts("{\"observations\":[");
 for(unsigned vi=0;vi<7;vi++)for(unsigned pi=0;pi<7;pi++){
  CodMilesStereoGainV1 g;CHECK(!cod_miles_stereo_gain_v1(volumes[vi],pans[pi],&g));
  NgpVoiceGainBalanceReportV2 gr={.version=2,.size=sizeof gr};
  CHECK(!ngp_voice_service_v2_set_gain_balance(service,h,g.gain,g.balance,&gr));
  CHECK(gr.gain_observation_valid && gr.voice.handle==h && gr.requested_linear_gain==g.gain && gr.requested_native_balance==g.balance);
  float output[512];for(unsigned pass=0;pass<4;pass++)CHECK(!ngp_voice_service_v1_render(service,output,256,256));
  for(unsigned i=0;i<512;i++){float expected=.125f*(i%2?g.right:g.left),error=fabsf(output[i]-expected);if(error>maximum)maximum=error;CHECK(isfinite(output[i])&&error<.00001f);}
  if(cases++)puts(",");printf("{\"volume\":%.9g,\"pan\":%.9g,\"left\":%.9g,\"right\":%.9g,\"actualLeft\":%.9g,\"actualRight\":%.9g}",volumes[vi],pans[pi],g.left,g.right,output[510],output[511]);
 }
 unsigned refused=0;float bad[][2]={{-1,0},{1,-.01f},{1,1.01f},{NAN,.5f},{1,NAN},{INFINITY,.5f},{1,INFINITY},{100,0}};
 for(unsigned i=0;i<sizeof bad/sizeof bad[0];i++){CodMilesStereoGainV1 g={11,12,13,14},before=g;CHECK(cod_miles_stereo_gain_v1(bad[i][0],bad[i][1],&g));CHECK(!memcmp(&g,&before,sizeof g));refused++;}
 CHECK(cod_miles_stereo_gain_v1(1,.5f,NULL));refused++;
 CHECK(!ngp_voice_service_v1_stop(service,h,&r));CHECK(!ngp_voice_service_v1_close(service,&r));
 printf("],\"cases\":%u,\"refusals\":%u,\"maxPcmError\":%.9g,\"callerPcmCleared\":true,\"actualVoiceGraph\":true,\"phone\":false}\n",cases,refused,maximum);return NULL;
}
int main(void){CHECK(pthread_main_np());NgpVoiceOutputV1 out={.version=1,.size=sizeof out,.sample_rate=44100,.channels=2};NgpVoiceReportV1 r=vr();CHECK(!ngp_voice_service_v1_reserve(&out,&service,&r));pthread_t t;CHECK(!pthread_create(&t,NULL,worker,NULL));CHECK(!pthread_join(t,NULL));return 0;}
