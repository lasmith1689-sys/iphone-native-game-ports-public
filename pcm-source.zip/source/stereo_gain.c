#include "stereo_gain.h"
#include <math.h>
int cod_miles_stereo_gain_v1(float volume,float pan,CodMilesStereoGainV1 *out)
{
    if(!out || !isfinite(volume) || !isfinite(pan) || volume<0 || pan<0 || pan>1)return -1;
    
    float powered=(float)pow((double)volume,1.6666666666666667);
    CodMilesStereoGainV1 v;
    v.left=(float)(pow(1.0-(double)pan,(double)(float)0.3)*powered);
    v.right=(float)(pow((double)pan,(double)(float)0.3)*powered);
    v.gain=v.left>v.right?v.left:v.right;
    if(!isfinite(v.gain) || v.gain>16)return -1;
    v.balance=v.gain==0 ? 0 : v.right>v.left ? 1-v.left/v.right : v.right/v.left-1;
    if(!isfinite(v.balance) || v.balance< -1 || v.balance>1)return -1;
    *out=v;return 0;
}
