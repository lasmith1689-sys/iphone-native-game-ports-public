#define MINIAUDIO_IMPLEMENTATION
#include "ngp_audio_shared_profile_v1.h"
