#ifndef COD_MILES_SAMPLE_PLAYBACK_V1_H
#define COD_MILES_SAMPLE_PLAYBACK_V1_H
#include "sample_control.h"
#include "stereo_gain.h"
typedef struct {
 uint32_t format,rate,loops,address,bytes,dirty,bound_rate;
 float volume,pan;
} CodMilesPcmParametersV1;
typedef struct {CodMilesControlsV1 *controls;uint32_t ready,retained;CodMilesPcmParametersV1 voices[32];} CodMilesPlaybackV1;
int cod_miles_playback_adopt_v1(CodMilesPlaybackV1*,CodMilesControlsV1*);
int cod_miles_playback_init_v1(CodMilesPlaybackV1*,uint32_t);
int cod_miles_playback_type_v1(CodMilesPlaybackV1*,uint32_t,uint32_t,uint32_t);
int cod_miles_playback_address_v1(CodMilesPlaybackV1*,uint32_t,uint32_t,uint32_t);
int cod_miles_playback_rate_v1(CodMilesPlaybackV1*,uint32_t,int32_t);
int cod_miles_playback_loop_v1(CodMilesPlaybackV1*,uint32_t,uint32_t);
int cod_miles_playback_gain_v1(CodMilesPlaybackV1*,uint32_t,float,float);

int cod_miles_playback_start_v1(CodMilesPlaybackV1*,uint32_t,unsigned,
 uint32_t source_address,const void *memory,uint32_t bytes);
#endif
