#include "sample_playback.h"
#include "ngp_voice_gain_balance_v2.h"
static NgpVoiceReportV1 report(void){NgpVoiceReportV1 r={.version=1,.size=sizeof r};return r;}
static int poison(CodMilesPlaybackV1*s){s->retained=1;return -1;}
static int lookup(CodMilesPlaybackV1*s,uint32_t h,unsigned*i,uint32_t*phase){
 if(!s||!s->ready||s->retained||!s->controls||s->controls->playback_owner!=s||h<s->controls->guest_base)return -1;
 uint32_t offset=h-s->controls->guest_base;if(offset>=512||(offset&15))return -1;
 if(cod_miles_control_v1(s->controls,h,1,COD_MILES_CONTROL_STATUS,phase))return -1;
 *i=offset/16;return 0;
}
static void defaults(CodMilesPcmParametersV1*p){CodMilesPcmParametersV1 v={.rate=11025,.loops=1,.volume=1,.pan=.5f};*p=v;}
static int valid(CodMilesPlaybackV1*s,unsigned i,const NgpVoiceReportV1*r){
 CodMilesControlVoiceV1*v=s->controls->voices+i;
 return !r->status&&!r->library_status&&r->handle==v->handle&&r->generation==v->generation&&r->kind==1&&r->slot_index==i&&!r->render_allocator_violations?0:poison(s);
}
int cod_miles_playback_adopt_v1(CodMilesPlaybackV1*s,CodMilesControlsV1*c){
 if(!s||s->ready||s->retained||s->controls||!c||!c->ready||c->retained||c->playback_owner)return -1;
 for(unsigned i=0;i<32;i++){uint32_t phase;if(c->voices[i].bound||cod_miles_control_v1(c,c->guest_base+16*i,1,1,&phase)||phase!=COD_MILES_DONE)return -1;}
 c->playback_owner=s;s->controls=c;for(unsigned i=0;i<32;i++)defaults(s->voices+i);s->ready=1;return 0;
}
int cod_miles_playback_init_v1(CodMilesPlaybackV1*s,uint32_t h){
 unsigned i;uint32_t phase;if(lookup(s,h,&i,&phase))return -1;
 if(cod_miles_control_v1(s->controls,h,1,COD_MILES_CONTROL_END,&phase))return poison(s);
 NgpVoiceReportV1 r=report();uint64_t handle=s->controls->voices[i].handle;
 if(ngp_voice_service_v1_set_pitch(s->controls->service,handle,1,&r)||valid(s,i,&r)||ngp_voice_service_v1_set_looping(s->controls->service,handle,0,&r)||valid(s,i,&r))return poison(s);
 if(cod_miles_playback_gain_v1(s,h,1,.5f))return poison(s);
 defaults(s->voices+i);return 0;
}
int cod_miles_playback_type_v1(CodMilesPlaybackV1*s,uint32_t h,uint32_t type,uint32_t flags){
 unsigned i;uint32_t phase;if(type>3||flags||lookup(s,h,&i,&phase)||phase!=COD_MILES_DONE)return -1;
 if(s->voices[i].bound_rate)return -1;
 if(s->voices[i].format!=type){s->voices[i].format=type;s->voices[i].dirty=1;}return 0;
}
int cod_miles_playback_address_v1(CodMilesPlaybackV1*s,uint32_t h,uint32_t address,uint32_t bytes){
 unsigned i;uint32_t phase;if((uint64_t)address+bytes>UINT64_C(0x100000000)||bytes>64u*1024*1024||lookup(s,h,&i,&phase)||phase!=COD_MILES_DONE)return -1;
 if(s->voices[i].bound_rate)return -1;
 s->voices[i].address=address;s->voices[i].bytes=bytes;s->voices[i].dirty=1;return 0;
}
int cod_miles_playback_rate_v1(CodMilesPlaybackV1*s,uint32_t h,int32_t rate){
 unsigned i;uint32_t phase;if(lookup(s,h,&i,&phase))return -1;if(rate<=0)return 0;
 if(rate<8000||rate>192000)return -1;CodMilesPcmParametersV1*p=s->voices+i;
 if(p->bound_rate&&!p->dirty){float pitch=(float)rate/p->bound_rate;if(pitch<.125f||pitch>8)return -1;NgpVoiceReportV1 r=report();if(ngp_voice_service_v1_set_pitch(s->controls->service,s->controls->voices[i].handle,pitch,&r)||valid(s,i,&r))return poison(s);}
 p->rate=(uint32_t)rate;return 0;
}
int cod_miles_playback_loop_v1(CodMilesPlaybackV1*s,uint32_t h,uint32_t loops){
 unsigned i;uint32_t phase;if(loops>1||lookup(s,h,&i,&phase))return -1;NgpVoiceReportV1 r=report();
 if(ngp_voice_service_v1_set_looping(s->controls->service,s->controls->voices[i].handle,loops==0,&r)||valid(s,i,&r))return poison(s);
 s->voices[i].loops=loops;return 0;
}
int cod_miles_playback_gain_v1(CodMilesPlaybackV1*s,uint32_t h,float volume,float pan){
 CodMilesStereoGainV1 g;unsigned i;uint32_t phase;if(cod_miles_stereo_gain_v1(volume,pan,&g)||lookup(s,h,&i,&phase))return -1;
 NgpVoiceGainBalanceReportV2 r={.version=2,.size=sizeof r};
 if(ngp_voice_service_v2_set_gain_balance(s->controls->service,s->controls->voices[i].handle,g.gain,g.balance,&r)||valid(s,i,&r.voice)||!r.gain_observation_valid||r.requested_linear_gain!=g.gain||r.requested_native_balance!=g.balance)return poison(s);
 s->voices[i].volume=volume;s->voices[i].pan=pan;return 0;
}
int cod_miles_playback_start_v1(CodMilesPlaybackV1*s,uint32_t h,unsigned resume,uint32_t address,const void*memory,uint32_t bytes){
 unsigned i;uint32_t phase;if(resume>1||lookup(s,h,&i,&phase))return -1;CodMilesPcmParametersV1*p=s->voices+i;
 if(!p->address||!p->bytes||(resume&&phase==COD_MILES_PLAYING))return 0;
 if(resume&&p->bound_rate&&!p->dirty){
  NgpVoiceReportV1 r=report();
  if(ngp_voice_service_v1_snapshot(s->controls->service,s->controls->voices[i].handle,&r)||valid(s,i,&r))return poison(s);
  if(r.source_cursor==r.source_frames)return -1; 
 }
 if(p->dirty||!p->bound_rate){
  if(phase!=COD_MILES_DONE||address!=p->address||bytes!=p->bytes||!memory)return -1;
  unsigned channels=(p->format&2)?2:1,unit=(p->format&1)?2:1;
  if(p->bytes%(channels*unit))return -1;
  NgpVoicePcmV1 pcm={.version=1,.size=sizeof pcm,.format=unit==2?NGP_VOICE_PCM_S16_V1:NGP_VOICE_PCM_U8_V1,.channels=channels,.sample_rate=p->rate,.bytes=memory,.byte_count=p->bytes,.frame_count=p->bytes/(channels*unit)};
  if(cod_miles_control_bind_pcm_owned_v2(s->controls,s,h,1,&pcm))return poison(s);
  p->bound_rate=p->rate;p->dirty=0;NgpVoiceReportV1 r=report();
  if(ngp_voice_service_v1_set_pitch(s->controls->service,s->controls->voices[i].handle,1,&r)||valid(s,i,&r))return poison(s);
 }
 if(cod_miles_control_start_v1(s->controls,h,1,resume))return poison(s);return 0;
}
