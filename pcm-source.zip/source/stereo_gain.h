#ifndef COD_MILES_STEREO_GAIN_V1_H
#define COD_MILES_STEREO_GAIN_V1_H
typedef struct {float left,right,gain,balance;} CodMilesStereoGainV1;

int cod_miles_stereo_gain_v1(float volume,float pan,CodMilesStereoGainV1 *out);
#endif
