#ifndef COD_MILES_SAMPLE_CONTROL_V1_H
#define COD_MILES_SAMPLE_CONTROL_V1_H
#include "ngp_positional_provider_v1.h"

enum { COD_MILES_CONTROL_STATUS=1, COD_MILES_CONTROL_STOP=2, COD_MILES_CONTROL_END=3 };
enum { COD_MILES_DONE=2, COD_MILES_PLAYING=4, COD_MILES_STOPPED=8 };
typedef struct {
    uint32_t token, phase, bound, slot;
    uint64_t handle, generation;
} CodMilesControlVoiceV1;
typedef struct {
    NgpVoiceServiceV1 *service;
    NgpVoiceTokensV1 *ordinary;
    NgpPositionalProviderV1 *positional;
    uint32_t guest_base, ready, retained;
    const void *playback_owner; 
    CodMilesControlVoiceV1 voices[64];
} CodMilesControlsV1;

int cod_miles_controls_adopt_v1(CodMilesControlsV1 *, NgpVoiceServiceV1 *,
    NgpVoiceTokensV1 *, NgpPositionalProviderV1 *, uint32_t, const uint32_t [64]);
int cod_miles_control_v1(CodMilesControlsV1 *, uint32_t guest_handle, uint32_t kind,
    uint32_t operation, uint32_t *observed_status);

int cod_miles_control_bind_pcm_owned_v2(CodMilesControlsV1 *, const void *, uint32_t, uint32_t, const NgpVoicePcmV1 *);
int cod_miles_control_bind_pcm_v1(CodMilesControlsV1 *, uint32_t, uint32_t, const NgpVoicePcmV1 *);
int cod_miles_control_start_v1(CodMilesControlsV1 *, uint32_t, uint32_t, unsigned resume);
#endif
