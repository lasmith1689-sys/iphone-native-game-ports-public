
#include "sample_playback.h"
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define CHECK(x) do{if(!(x)){fprintf(stderr,"line%u %s\n",__LINE__,#x);exit(1);}}while(0)
static NgpVoiceServiceV1*service;static CodMilesControlsV1 control;static CodMilesPlaybackV1 playback;
static NgpVoiceReportV1 vr(void){NgpVoiceReportV1 r={.version=1,.size=sizeof r};return r;}
static uint32_t status(uint32_t h){uint32_t s;CHECK(!cod_miles_control_v1(&control,h,1,1,&s));return s;}
static float output[512];static unsigned samples,refusals;
static void render(unsigned blocks){for(unsigned n=0;n<blocks;n++){CHECK(!ngp_voice_service_v1_render(service,output,256,256));for(unsigned i=0;i<512;i++){CHECK(isfinite(output[i]));if(fabsf(output[i])>.00001f)samples++;}}}
static void*worker(void*unused){
 (void)unused;NgpVoiceReportV1 r=vr();CHECK(!ngp_voice_service_v1_prepare(service,&r));
 NgpVoiceTokensV1*ordinary=NULL;NgpPositionalProviderV1*positional=NULL;
 NgpVoiceTokensReportV1 t={.version=1,.size=sizeof t};NgpPositionalReportV1 p={.version=1,.size=sizeof p};
 CHECK(!ngp_voice_tokens_v1_reserve(1,&ordinary,&t));CHECK(!ngp_voice_tokens_v1_prepare(ordinary,service,&t));CHECK(!ngp_positional_v1_open(service,&positional,&p));
 uint32_t tokens[64]={0};for(unsigned i=0;i<32;i++)CHECK(!ngp_voice_tokens_v1_assign(ordinary,tokens+i,&t));for(unsigned i=32;i<64;i++)CHECK(!ngp_positional_v1_acquire(positional,tokens+i,&p));
 CHECK(!cod_miles_controls_adopt_v1(&control,service,ordinary,positional,0x18003000,tokens));CHECK(!cod_miles_playback_adopt_v1(&playback,&control));CHECK(!ngp_voice_service_v1_enable(service,&r));
 CodMilesPlaybackV1 other={0};CHECK(cod_miles_playback_adopt_v1(&other,&control));CHECK(!other.ready&&!other.controls);refusals++;
 int16_t foreign[2]={123,456};NgpVoicePcmV1 foreign_pcm={.version=1,.size=sizeof foreign_pcm,.format=NGP_VOICE_PCM_S16_V1,.channels=1,.sample_rate=44100,.bytes=foreign,.byte_count=sizeof foreign,.frame_count=2};
 CHECK(cod_miles_control_bind_pcm_v1(&control,control.guest_base,1,&foreign_pcm));CHECK(!control.voices[0].bound);refusals++;
 CHECK(cod_miles_control_bind_pcm_owned_v2(&control,&other,control.guest_base,1,&foreign_pcm));CHECK(!control.voices[0].bound);refusals++;
 for(unsigned fmt=0;fmt<4;fmt++){
  uint32_t h=control.guest_base+16*fmt,address=0x18030000;unsigned channels=(fmt&2)?2:1,unit=(fmt&1)?2:1;uint8_t bytes[8192];unsigned size=2048*channels*unit;
  if(unit==1)memset(bytes,160,size);else for(unsigned i=0;i<size;i+=2){bytes[i]=0;bytes[i+1]=0x20;}
  CHECK(!cod_miles_playback_init_v1(&playback,h));CHECK(status(h)==2);CHECK(!cod_miles_playback_start_v1(&playback,h,0,0,NULL,0));CHECK(status(h)==2);
  CHECK(!cod_miles_playback_type_v1(&playback,h,fmt,0));CHECK(!cod_miles_playback_address_v1(&playback,h,address,size));CHECK(!cod_miles_playback_rate_v1(&playback,h,44100));CHECK(!cod_miles_playback_gain_v1(&playback,h,1,0));CHECK(!cod_miles_playback_loop_v1(&playback,h,1));
  CHECK(cod_miles_playback_start_v1(&playback,h,0,address+1,bytes,size));refusals++;CHECK(status(h)==2);
  CHECK(!cod_miles_playback_start_v1(&playback,h,0,address,bytes,size));CHECK(status(h)==4);memset(bytes,0,sizeof bytes);render(2);
  
  for(unsigned i=0;i<512;i++){float wanted=i%2?0:unit==1?160*.00784313725490196078f-1:.25f;if(fabsf(output[i]-wanted)>=.00001f)fprintf(stderr,"format%u sample%u actual%.9g wanted%.9g\n",fmt,i,output[i],wanted);CHECK(fabsf(output[i]-wanted)<.00001f);}
  CHECK(!cod_miles_playback_rate_v1(&playback,h,22050));CHECK(!ngp_voice_service_v1_snapshot(service,control.voices[fmt].handle,&r));CHECK(r.requested_pitch==.5f);
  uint32_t phase;CHECK(!cod_miles_control_v1(&control,h,1,2,&phase)&&phase==8);CHECK(!cod_miles_playback_start_v1(&playback,h,1,0,NULL,0));CHECK(status(h)==4);
  CHECK(!cod_miles_playback_loop_v1(&playback,h,0));render(24);CHECK(status(h)==4);
  CHECK(!cod_miles_control_v1(&control,h,1,3,&phase)&&phase==2);
  CHECK(cod_miles_playback_address_v1(&playback,h,address,size));refusals++;CHECK(cod_miles_playback_type_v1(&playback,h,fmt,0));refusals++;
  if(fmt==3){CHECK(!cod_miles_playback_loop_v1(&playback,h,1));CHECK(!cod_miles_playback_start_v1(&playback,h,0,0,NULL,0));render(60);CHECK(status(h)==2);CHECK(cod_miles_playback_start_v1(&playback,h,1,0,NULL,0));refusals++;CHECK(status(h)==2);}
  CHECK(!cod_miles_playback_init_v1(&playback,h));CHECK(status(h)==2);
  CHECK(!cod_miles_playback_start_v1(&playback,h,0,0,NULL,0));CHECK(status(h)==2); 
 }
 uint32_t h=control.guest_base;
 CHECK(cod_miles_playback_type_v1(&playback,h,4,0));refusals++;CHECK(cod_miles_playback_type_v1(&playback,h,1,1));refusals++;
 CHECK(cod_miles_playback_loop_v1(&playback,h,2));refusals++;CHECK(cod_miles_playback_rate_v1(&playback,h,7999));refusals++;CHECK(cod_miles_playback_rate_v1(&playback,h,192001));refusals++;
 CHECK(cod_miles_playback_address_v1(&playback,h,0xfffffff0u,32));refusals++;CHECK(cod_miles_playback_address_v1(&playback,h,1,64u*1024*1024+1));refusals++;
 CHECK(cod_miles_playback_init_v1(&playback,h+1));refusals++;CHECK(cod_miles_playback_init_v1(&playback,h+512));refusals++;
 CHECK(!cod_miles_playback_rate_v1(&playback,h,0));CHECK(!cod_miles_playback_rate_v1(&playback,h,-1));CHECK(playback.voices[0].rate==11025);
 CHECK(!playback.retained&&!control.retained);CHECK(samples>0);CHECK(!ngp_voice_service_v1_close(service,&r));
 printf("{\"formats\":4,\"refusals\":%u,\"nonzeroPcmSamples\":%u,\"copiedSource\":true,\"ratePitchObserved\":true,\"loopResumeObserved\":true,\"noOldReplayAfterInit\":true,\"phone\":false}\n",refusals,samples);return NULL;
}
int main(void){CHECK(pthread_main_np());NgpVoiceOutputV1 out={.version=1,.size=sizeof out,.sample_rate=44100,.channels=2};NgpVoiceReportV1 r=vr();CHECK(!ngp_voice_service_v1_reserve(&out,&service,&r));pthread_t t;CHECK(!pthread_create(&t,NULL,worker,NULL));CHECK(!pthread_join(t,NULL));return 0;}
