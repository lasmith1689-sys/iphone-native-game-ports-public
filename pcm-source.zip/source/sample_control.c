#include "sample_control.h"

static NgpVoiceReportV1 report(void)
{ NgpVoiceReportV1 r={0}; r.version=1; r.size=sizeof r; return r; }
static int failed(CodMilesControlsV1 *s)
{ s->retained=1; return -1; }
static int resolve(CodMilesControlsV1 *s, unsigned index, uint64_t *handle)
{
    CodMilesControlVoiceV1 *v=&s->voices[index];
    if(index<32) {
        NgpVoiceTokensReportV1 r={.version=1,.size=sizeof r};
        if(ngp_voice_tokens_v1_resolve(s->ordinary,v->token,handle,&r) ||
           r.status || r.phase!=NGP_TOKENS_READY || r.kind!=NGP_VOICE_ORDINARY_V1 ||
           !r.worker_observation || r.capacity!=32 || r.reserved_tracked!=32 || r.loans_tracked!=32)
            return -1;
    } else {
        NgpPositionalReportV1 r={.version=1,.size=sizeof r};
        if(ngp_positional_v1_resolve(s->positional,v->token,handle,&r) ||
           r.status || r.phase!=NGP_POSITIONAL_LIVE || !r.worker_observation || r.capacity!=32 || r.active!=32)
            return -1;
    }
    return !*handle;
}
static int valid_snapshot(const NgpVoiceReportV1 *r, unsigned index, uint64_t handle)
{
    return r->version==1 && r->size==sizeof *r && !r->status && !r->library_status &&
        (r->phase==NGP_VOICE_READY_OPEN_V1 || r->phase==NGP_VOICE_READY_GATED_V1) &&
        r->kind==(index<32?NGP_VOICE_ORDINARY_V1:NGP_VOICE_POSITIONAL_V1) &&
        r->slot_index==index && r->handle==handle && r->generation &&
        r->bound<=1 && r->playing<=1 && r->looping<=1 && !r->render_allocator_violations;
}
int cod_miles_controls_adopt_v1(CodMilesControlsV1 *s, NgpVoiceServiceV1 *service,
    NgpVoiceTokensV1 *ordinary, NgpPositionalProviderV1 *positional,
    uint32_t base, const uint32_t tokens[64])
{
    if(!s || s->ready || s->retained || s->service || !service || !ordinary || !positional ||
       !tokens || !base || (base&15u) || (uint64_t)base+1024>UINT64_C(0x100000000)) return -1;
    s->service=service; s->ordinary=ordinary; s->positional=positional; s->guest_base=base;
    for(unsigned i=0;i<64;i++) {
        CodMilesControlVoiceV1 *v=&s->voices[i];
        if(!tokens[i]) return failed(s);
        v->token=tokens[i]; uint64_t h=0; NgpVoiceReportV1 r=report();
        if(resolve(s,i,&h) || ngp_voice_service_v1_snapshot(service,h,&r) ||
           !valid_snapshot(&r,i,h) || r.bound || r.playing || r.looping || r.source_frames || r.source_cursor)
            return failed(s);
        for(unsigned j=0;j<i;j++) if(s->voices[j].handle==h || (j/32==i/32 && tokens[j]==tokens[i])) return failed(s);
        v->handle=h; v->generation=r.generation; v->slot=i; v->phase=COD_MILES_DONE;
    }
    s->ready=1; return 0;
}
static int lookup(CodMilesControlsV1 *s,uint32_t guest,uint32_t kind,unsigned *index)
{
    if(!s || !s->ready || s->retained || (kind!=1 && kind!=2) || guest<s->guest_base) return -1;
    uint32_t offset=guest-s->guest_base;
    if(offset>=1024 || (offset&15u)) return -1;
    unsigned i=offset/16;
    if((i<32?1u:2u)!=kind) return -1;
    *index=i; return 0;
}
static int observe(CodMilesControlsV1 *s,unsigned i,NgpVoiceReportV1 *r)
{
    CodMilesControlVoiceV1 *v=&s->voices[i]; uint64_t h=0;
    if(resolve(s,i,&h) || h!=v->handle || ngp_voice_service_v1_snapshot(s->service,h,r) ||
       !valid_snapshot(r,i,h) || r->generation!=v->generation || r->bound!=v->bound ||
       (r->bound && (!r->source_frames || r->source_cursor>r->source_frames))) return failed(s);
    if(v->phase==COD_MILES_PLAYING) {
        if(!r->bound) return failed(s);
        if(!r->playing) {
            
            if(r->looping || r->source_cursor!=r->source_frames) return failed(s);
            v->phase=COD_MILES_DONE;
        }
    } else if((v->phase!=COD_MILES_DONE && v->phase!=COD_MILES_STOPPED) || r->playing ||
              (v->phase==COD_MILES_STOPPED && !r->bound)) return failed(s);
    return 0;
}
static int after(CodMilesControlsV1 *s,unsigned i,const NgpVoiceReportV1 *r,unsigned playing)
{
    CodMilesControlVoiceV1 *v=&s->voices[i];
    return valid_snapshot(r,i,v->handle) && r->generation==v->generation &&
        r->bound==v->bound && r->playing==playing ? 0 : failed(s);
}
int cod_miles_control_v1(CodMilesControlsV1 *s,uint32_t guest,uint32_t kind,uint32_t op,uint32_t *out)
{
    if(!out || op<1 || op>3 || !s || !s->ready || s->retained || (kind!=1 && kind!=2)) return -1;
    
    if(!guest) { *out=0; return 0; }
    unsigned i; if(lookup(s,guest,kind,&i)) return -1;
    NgpVoiceReportV1 r=report(); if(observe(s,i,&r)) return -1;
    CodMilesControlVoiceV1 *v=&s->voices[i];
    if((op==COD_MILES_CONTROL_END && v->phase!=COD_MILES_DONE) ||
       (op==COD_MILES_CONTROL_STOP && v->phase==COD_MILES_PLAYING)) {
        r=report();
        if(ngp_voice_service_v1_stop(s->service,v->handle,&r) || after(s,i,&r,0)) return failed(s);
        v->phase=op==COD_MILES_CONTROL_END?COD_MILES_DONE:COD_MILES_STOPPED;
    }
    *out=v->phase; return 0;
}
int cod_miles_control_bind_pcm_owned_v2(CodMilesControlsV1 *s,const void *owner,uint32_t guest,uint32_t kind,const NgpVoicePcmV1 *pcm)
{
    unsigned i; if(!pcm || lookup(s,guest,kind,&i)) return -1;
    if((i<32 && s->playback_owner!=owner) || (i>=32 && owner)) return -1;
    NgpVoiceReportV1 r=report(); if(observe(s,i,&r)) return -1;
    CodMilesControlVoiceV1 *v=&s->voices[i]; if(v->phase!=COD_MILES_DONE) return -1;
    if(ngp_voice_service_v1_bind_pcm(s->service,v->handle,pcm,&r)) return failed(s);
    v->bound=1;
    if(after(s,i,&r,0) || !r.source_frames || r.source_frames!=pcm->frame_count || r.source_cursor) return failed(s);
    return 0;
}
int cod_miles_control_bind_pcm_v1(CodMilesControlsV1 *s,uint32_t guest,uint32_t kind,const NgpVoicePcmV1 *pcm)
{ return cod_miles_control_bind_pcm_owned_v2(s,0,guest,kind,pcm); }
int cod_miles_control_start_v1(CodMilesControlsV1 *s,uint32_t guest,uint32_t kind,unsigned resume)
{
    unsigned i; if(resume>1 || lookup(s,guest,kind,&i)) return -1;
    NgpVoiceReportV1 r=report(); if(observe(s,i,&r)) return -1;
    CodMilesControlVoiceV1 *v=&s->voices[i];
    if(!v->bound || (resume && v->phase==COD_MILES_PLAYING)) return 0;
    
    if(resume && r.source_cursor==r.source_frames) return -1;
    if(!resume) {
        if(ngp_voice_service_v1_stop(s->service,v->handle,&r) || after(s,i,&r,0) ||
           ngp_voice_service_v1_seek(s->service,v->handle,0,&r)) return failed(s);
    }
    if(ngp_voice_service_v1_play(s->service,v->handle,&r) || after(s,i,&r,1)) return failed(s);
    v->phase=COD_MILES_PLAYING; return 0;
}
