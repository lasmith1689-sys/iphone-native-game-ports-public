#include "ngp_dxt_v1.h"

static int span(const void*p,size_t n){return p&&n&&(uintptr_t)p<=UINTPTR_MAX-(n-1);}
static int overlap(const void*p,size_t pn,const void*q,size_t qn){
 uintptr_t a=(uintptr_t)p,b=(uintptr_t)q;return a<=b?b-a<pn:a-b<qn;
}
static uint32_t u16(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8);}
static uint32_t u32(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
/* Exact normalized formula followed by one final nearest-byte quantization. */
static uint8_t nearest(uint32_t numerator,uint32_t denominator){return (uint8_t)((2*numerator+denominator)/(2*denominator));}
static void colors(const uint8_t*p,uint32_t format,uint8_t rgb[4][4]){
 uint32_t c0=u16(p),c1=u16(p+2);
 for(uint32_t code=0;code<4;code++){
  uint32_t a=0,b=0,divisor=1;
  if(code==0)a=1;else if(code==1)b=1;
  else if(format>=0x83f2||c0>c1){a=code==2?2:1;b=3-a;divisor=3;}
  else if(code==2){a=b=1;divisor=2;}
  for(uint32_t k=0;k<3;k++){
   uint32_t shift=k==0?11:k==1?5:0,mask=k==1?63:31;
   uint32_t x=(c0>>shift)&mask,y=(c1>>shift)&mask;
   rgb[code][k]=nearest((a*x+b*y)*255,divisor*mask);
  }
  rgb[code][3]=(format==0x83f1&&c0<=c1&&code==3)?0:255;
 }
}
int ngp_dxt_v1_decode(const void*compressed,size_t compressed_bytes,
 uint32_t width,uint32_t height,uint32_t format,void*rgba,size_t rgba_bytes){
 if(!width||!height||width>8192||height>8192||(width&(width-1))||(height&(height-1))||format<0x83f0||format>0x83f3)return NGP_DXT_INVALID_V1;
 uint32_t blocksize=format<=0x83f1?8:16;
 uint64_t blocks=(uint64_t)((width+3)/4)*((height+3)/4),need_source=blocks*blocksize,need_output=(uint64_t)width*height*4;
 if(need_source>NGP_DXT_MAX_BYTES_V1||need_output>NGP_DXT_MAX_BYTES_V1||compressed_bytes!=need_source||rgba_bytes!=need_output||!span(compressed,compressed_bytes)||!span(rgba,rgba_bytes)||overlap(compressed,compressed_bytes,rgba,rgba_bytes))return NGP_DXT_INVALID_V1;
 const uint8_t*source=compressed;uint8_t*out=rgba;size_t offset=0;
 for(uint32_t by=0;by<height;by+=4)for(uint32_t bx=0;bx<width;bx+=4){
  const uint8_t*block=source+offset;const uint8_t*color=block+(format<=0x83f1?0:8);uint8_t palette[4][4],alpha[8];uint64_t alpha_bits=0;offset+=blocksize;
  colors(color,format,palette);uint32_t color_bits=u32(color+4);
  if(format==0x83f3){
   alpha[0]=block[0];alpha[1]=block[1];
   for(uint32_t k=2;k<8;k++){
    if(alpha[0]>alpha[1])alpha[k]=nearest((8-k)*alpha[0]+(k-1)*alpha[1],7);
    else if(k<6)alpha[k]=nearest((6-k)*alpha[0]+(k-1)*alpha[1],5);
    else alpha[k]=k==6?0:255;
   }
   for(uint32_t k=0;k<6;k++)alpha_bits|=(uint64_t)block[2+k]<<(8*k);
  }
  for(uint32_t y=0;y<4&&by+y<height;y++)for(uint32_t x=0;x<4&&bx+x<width;x++){
   uint32_t k=y*4+x,code=(color_bits>>(2*k))&3;size_t at=((size_t)(by+y)*width+bx+x)*4;
   out[at]=palette[code][0];out[at+1]=palette[code][1];out[at+2]=palette[code][2];
   out[at+3]=format==0x83f2?(uint8_t)(((block[k/2]>>(4*(k&1)))&15)*17):format==0x83f3?alpha[(alpha_bits>>(3*k))&7]:palette[code][3];
  }
 }
 return NGP_DXT_OK_V1;
}
