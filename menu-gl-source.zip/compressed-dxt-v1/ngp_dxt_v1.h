#ifndef NGP_DXT_V1_H
#define NGP_DXT_V1_H
#include <stdint.h>
#include <stddef.h>
enum {NGP_DXT_OK_V1=0,NGP_DXT_INVALID_V1=1,NGP_DXT_MAX_BYTES_V1=64*1024*1024};
/* Native owned/live spans only. Exact sizes, disjoint and stable for the call.
 * Positive POT1..8192, formats83f0..83f3. Invalid: no data read/output change.
 * Success: tightly packed RGBA8, declared nearest rational quantization.
 * No GL/upload/allocation/callback, sRGB or arbitrary-pointer validation. */
int ngp_dxt_v1_decode(const void *compressed,size_t compressed_bytes,
 uint32_t width,uint32_t height,uint32_t format,void *rgba,size_t rgba_bytes);
#endif
