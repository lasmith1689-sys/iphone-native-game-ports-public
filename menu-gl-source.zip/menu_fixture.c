#include "cod_gl_dispatch.h"
#include <stddef.h>

#define CHECK(x) do { if(!(x))return __LINE__; } while(0)
int _fltused;
static uint8_t memory[4096], regs[96], before[96];
static CodGL bridge;
static uint32_t invoked, bad_packet, live_list, pending_list, compiling, in_begin, backend_failure;
static double expected_ortho[6];
static enum CodGLFunction expected;
static uint32_t expected_words[4];
void *memset(void *,int,size_t);
void *memcpy(void *,const void *,size_t);

static void word(uint8_t *p,uint32_t x){for(uint32_t i=0;i<4;i++)p[i]=(uint8_t)(x>>(8*i));}
static int same(const void *a,const void *b,uint32_t n){const uint8_t*x=a,*y=b;for(uint32_t i=0;i<n;i++)if(x[i]!=y[i])return 0;return 1;}
static void *allocate(void *p,uint32_t n,uint32_t a){(void)p;(void)n;(void)a;return 0;}
static void release(void*p,void*q){(void)p;(void)q;}
static int unpack(void*p,CodGLUnpackState*s){(void)p;*s=(CodGLUnpackState){.alignment=4};return 0;}
static int client(void*p,CodGLClientState*s){(void)p;*s=(CodGLClientState){.list_active=live_list,.list_pending=pending_list,.compiling=compiling,.in_begin=in_begin};return 0;}
static int invoke(void*p,CodGLNativeCall*c,CodGLNativeResult*r){
 (void)p;(void)r;invoked++;
 if(c->function!=expected)bad_packet++;
 if(c->function==COD_GL_ORTHO){if(!same(c->ortho,expected_ortho,48))bad_packet++;}
 if(c->function==COD_GL_SCISSOR && !same(c->words,expected_words,16))bad_packet++;
 if(c->function==COD_GL_ALPHA_FUNC && !same(c->words,expected_words,8))bad_packet++;
 return backend_failure?COD_GL_BACKEND:0;
}
static void prepare(const void *args,uint32_t n){
 memset(regs,0x9a,sizeof(regs));word(regs+16,0x101);word(memory+0x101,0x4ccc87);
 if(n)memcpy(memory+0x105,args,n);memcpy(before,regs,sizeof(regs));
}
static int call(const char*name){return cod_gl_dispatch(&bridge,cod_gl_token(name),regs,sizeof(regs));}
static int success_regs(uint32_t argument_bytes){word(before+16,0x105+argument_bytes);return same(before,regs,sizeof(regs));}

__attribute__((visibility("default"))) int menu_fixture(void){
 const CodGLRange ranges[]={{0x100,0x100,3},{0x300,0x100,3}};
 CodGLMemory m={memory,ranges,2};CodGLAllocator a={0,allocate,release};
 invoked=bad_packet=live_list=pending_list=compiling=in_begin=backend_failure=0;
 CHECK(!cod_gl_init(&bridge,m,invoke,unpack,client,0,a,0x300,0x100));
 uint32_t index=999;
 CHECK(cod_gl_token_function_v13(0xfed400cc,&index)==COD_GL_UNKNOWN && index==999);
 CHECK(cod_gl_token("glTexSubImage2D")==0xfed400d0);
 CHECK(cod_gl_token("glFinish")==0xfed400d4 && cod_gl_token("glScissor")==0xfed400d8);
 CHECK(cod_gl_token("glOrtho")==0xfed400dc && cod_gl_token("glAlphaFunc")==0xfed400e0);
 for(uint32_t f=0;f<COD_GL_FUNCTION_COUNT;f++){
  CHECK(!cod_gl_token_function_v13(cod_gl_function_token_v13(f),&index) && index==f);
 }
 CHECK(!cod_gl_function_token_v13(COD_GL_FUNCTION_COUNT));
 CHECK(cod_gl_token_function_v13(0xfed400e4,&index)==COD_GL_UNKNOWN);
 expected=COD_GL_FINISH;prepare(0,0);CHECK(!call("glFinish") && success_regs(0));
 expected=COD_GL_SCISSOR;expected_words[0]=(uint32_t)-12;expected_words[1]=17;expected_words[2]=1179;expected_words[3]=2556;
 prepare(expected_words,16);CHECK(!call("glScissor") && success_regs(16));
 expected_words[2]=0xffffffff;prepare(expected_words,16);uint32_t calls=invoked;
 CHECK(call("glScissor")==COD_GL_ARGUMENT && invoked==calls && same(before,regs,sizeof(regs)));
 expected=COD_GL_ORTHO;
 double planes[6]={0.0,2556.0,1179.0,0.0,0.0,1.0};memcpy(expected_ortho,planes,48);
 prepare(planes,48);CHECK(!call("glOrtho") && success_regs(48));
 /* Truncated x86 stack cannot read into a following unlisted memory range. */
 prepare(planes,48);word(regs+16,0x1d0);memcpy(before,regs,sizeof(regs));calls=invoked;
 CHECK(call("glOrtho")==COD_GL_MEMORY && invoked==calls && same(before,regs,sizeof(regs)));
 /* Equal planes, NaN/infinity and double values overflowing float are refused. */
 planes[1]=0;prepare(planes,48);CHECK(call("glOrtho")==COD_GL_ARGUMENT && invoked==calls);
 const uint64_t invalid[]={UINT64_C(0x7ff0000000000000),UINT64_C(0x7ff0000000000001),UINT64_C(0x7fefffffffffffff),UINT64_C(0xfff0000000000000)};
 for(uint32_t i=0;i<4;i++){memcpy(planes+1,invalid+i,8);prepare(planes,48);CHECK(call("glOrtho")==COD_GL_ARGUMENT && invoked==calls);}
 planes[0]=1.0;planes[1]=1.0+0x1p-30;prepare(planes,48);CHECK(call("glOrtho")==COD_GL_ARGUMENT && invoked==calls);
 planes[0]=0.0;planes[1]=0x1p-149;prepare(planes,48);CHECK(call("glOrtho")==COD_GL_ARGUMENT && invoked==calls);
 expected=COD_GL_ALPHA_FUNC;expected_words[1]=0x3f000000;
 for(uint32_t fn=0x200;fn<=0x207;fn++){expected_words[0]=fn;prepare(expected_words,8);CHECK(!call("glAlphaFunc") && success_regs(8));}
 expected_words[0]=0x208;prepare(expected_words,8);CHECK(call("glAlphaFunc")==COD_GL_ARGUMENT);
 expected_words[0]=0x206;expected_words[1]=0x7fc00000;prepare(expected_words,8);CHECK(call("glAlphaFunc")==COD_GL_ARGUMENT);
 live_list=1;prepare(0,0);calls=invoked;CHECK(call("glFinish")==COD_GL_ARGUMENT && invoked==calls);
 pending_list=1;expected=COD_GL_FINISH;prepare(0,0);CHECK(!call("glFinish") && success_regs(0));
 compiling=1;prepare(0,0);calls=invoked;CHECK(call("glFinish")==COD_GL_ARGUMENT && invoked==calls);compiling=0;
 in_begin=1;prepare(0,0);CHECK(call("glFinish")==COD_GL_ARGUMENT && invoked==calls);in_begin=0;
 expected=COD_GL_ORTHO;planes[1]=2556;prepare(planes,48);CHECK(!call("glOrtho") && success_regs(48));
 expected=COD_GL_SCISSOR;expected_words[2]=1179;prepare(expected_words,16);CHECK(!call("glScissor") && success_regs(16));
 expected=COD_GL_ALPHA_FUNC;expected_words[0]=0x206;expected_words[1]=0x3f000000;prepare(expected_words,8);CHECK(!call("glAlphaFunc") && success_regs(8));
 pending_list=0;
 live_list=0;backend_failure=1;expected=COD_GL_FINISH;prepare(0,0);
 CHECK(call("glFinish")==COD_GL_BACKEND && bridge.failed && same(before,regs,sizeof(regs)));
 calls=invoked;CHECK(call("glFinish")==COD_GL_BACKEND && invoked==calls);
 CHECK(!bad_packet);return 0;
}
