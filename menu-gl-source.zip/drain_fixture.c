/* Own policy controls; recording backend, never GPU observations. */
#include "cod_gl_owned_profile.h"
#include <stddef.h>
void *memcpy(void*,const void*,size_t);
void *memset(void*,int,size_t);
#define CHECK(x) do{if(!(x))return __LINE__;}while(0)
static CodGL bridge;
static CodGLOwnedProfileV12 profile;
static CodGLOwnedStateV12 state;
static uint8_t memory[1024],regs[32],before[32],memory_before[1024];
static uint32_t scenario,invokes,finishes,begins,bad,read_failed;
static void word(uint8_t*p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static int same(const void*a,const void*b,size_t n){const uint8_t*x=a,*y=b;for(size_t i=0;i<n;i++)if(x[i]!=y[i])return 0;return 1;}
static int read_owned(void*p,uint32_t name,CodGLOwnedStateV12*out){(void)p;(void)name;if(read_failed)return COD_GL_BACKEND;*out=state;return 0;}
static int read_unpack(void*p,CodGLUnpackState*out){(void)p;*out=(CodGLUnpackState){.alignment=4};return 0;}
static int read_client(void*p,CodGLClientState*out){(void)p;*out=(CodGLClientState){0};return 0;}
static void*allocate(void*p,uint32_t n,uint32_t a){(void)p;(void)n;(void)a;bad++;return 0;}
static void release(void*p,void*q){(void)p;(void)q;bad++;}
static int invoke(void*p,CodGLNativeCall*c,CodGLNativeResult*r){
 (void)p;(void)r;invokes++;
 if(c!=&bridge.packet||c->pixels||c->owned_profile_kind||c->words[0]!=7||
    !same(regs,before,sizeof(regs))||!same(memory,memory_before,sizeof(memory)))bad++;
 if(c->function==COD_GL_FINISH){
  finishes++;
  if(scenario==2){uint8_t nested[32];memcpy(nested,regs,sizeof(nested));
   if(cod_gl_dispatch(&bridge,cod_gl_token("glBegin"),nested,sizeof(nested))!=COD_GL_BACKEND||!same(nested,regs,sizeof(nested)))bad++;
   if(c->function!=COD_GL_FINISH||c->words[0]!=7)bad++;
  }
  if(scenario==30)return COD_GL_BACKEND;
  if(scenario!=31)state.list_active=state.list_pending=0;
  if(scenario==32)state.context_generation++;
  if(scenario==33)read_failed=1;
  if(scenario==34)state.forbidden_globals=1;
 }else if(c->function==COD_GL_BEGIN){begins++;if(state.list_active||state.list_pending)bad++;if(scenario==35)return COD_GL_BACKEND;}
 else bad++;
 return 0;
}
__attribute__((visibility("default"))) int drain_fixture(uint32_t which){
 CHECK(which<36);scenario=which;invokes=finishes=begins=bad=read_failed=0;
 memset(memory,0x55,sizeof(memory));memset(regs,0x9a,sizeof(regs));
 state=(CodGLOwnedStateV12){.context_identity=1,.glstate_identity=2,.context_generation=3,
  .profile_kind=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12,.unit_count=2,.esversion=2,.max_size=8192,.alignment=4};
 static const CodGLRange ranges[]={{0x100,0x100,3},{0x300,0x100,3}};
 CodGLMemory m={memory,ranges,2};CodGLAllocator a={0,allocate,release};
 CHECK(!cod_gl_v13_init_owned(&bridge,&profile,state.profile_kind,read_owned,m,invoke,read_unpack,read_client,0,a,0x300,0x100));
 state.list_active=state.list_pending=which?1:0;
 switch(which){
 case 3:state.list_pending=0;break;case 4:state.list_active=0;break;
 case 5:state.list_active=state.list_pending=2;break;case 6:state.in_begin=1;break;
 case 7:state.compiling=1;break;case 8:state.pbo=1;break;
 case 9:state.row_length=1;break;case 10:state.skip_rows=1;break;
 case 11:state.skip_pixels=1;break;case 12:state.automipmap=1;break;
 case 13:state.forbidden_globals=1;break;case 14:state.alignment=3;break;
 case 15:state.requested_exists=2;break;case 16:state.context_identity=4;break;
 case 17:state.glstate_identity=4;break;case 18:state.context_generation=4;break;
 case 19:state.profile_kind=0;break;case 20:state.unit_count=0;break;
 case 21:state.unit_count=17;break;case 22:state.active_unit=2;break;
 case 23:state.esversion=1;break;case 24:state.esversion=4;break;
 case 25:state.max_size=0;break;case 26:state.max_size=0x80000000u;break;
 case 27:read_failed=1;break;case 28:state.context_identity=0;break;
 case 29:state.context_generation=0;break;default:break;
 }
 word(regs+16,0x100);word(memory+0x100,0x12345678);word(memory+0x104,7);
 memcpy(before,regs,sizeof(regs));memcpy(memory_before,memory,sizeof(memory));
 int rc=cod_gl_dispatch(&bridge,cod_gl_token("glBegin"),regs,sizeof(regs));
 CHECK(!bad&&same(memory,memory_before,sizeof(memory))&&!atomic_load(&bridge.in_dispatch));
 if(which<=2){
  CHECK(!rc&&!bridge.failed&&begins==1&&finishes==(which?1u:0u));
  word(before+16,0x108);CHECK(same(before,regs,sizeof(regs))&&bridge.packet.function==COD_GL_BEGIN);
 }else if(which<30){CHECK(rc&&!bridge.failed&&!invokes&&same(before,regs,sizeof(regs)));}
 else{
  CHECK(rc==COD_GL_BACKEND&&bridge.failed&&finishes==1&&begins==(which==35?1u:0u)&&same(before,regs,sizeof(regs)));
  CHECK(bridge.packet.function==(which==35?COD_GL_BEGIN:COD_GL_FINISH));
  uint32_t count=invokes;CHECK(cod_gl_dispatch(&bridge,cod_gl_token("glBegin"),regs,sizeof(regs))==COD_GL_BACKEND&&invokes==count&&same(before,regs,sizeof(regs)));
 }
 return 0;
}
