/* Personal Apple build adapter, not an upstream contribution.
 * The pinned source has exactly two AliasDecl uses, both void(array,index).
 * Mach-O Clang cannot emit GCC alias attributes. Preserve typed call behavior;
 * address identity of the two spelling variants is deliberately not promised.
 * The workflow checks the exact source bytes/count before enabling this macro. */
#if !defined(__APPLE__) || !defined(__aarch64__)
#error This adapter is scoped to Apple ARM64 only
#endif
#define AliasDecl(RET, NAME, DEF, OLD) \
    RET APIENTRY_GL4ES NAME DEF { OLD(array, index); }
