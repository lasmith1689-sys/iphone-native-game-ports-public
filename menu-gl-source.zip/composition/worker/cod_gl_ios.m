/* UIKit and native GLES headers stay isolated from the desktop GL4ES TU. */
#define GLES_SILENCE_DEPRECATION
#import "cod_gl_ios.h"
#import <QuartzCore/CAEAGLLayer.h>
#import <OpenGLES/EAGL.h>
#import <OpenGLES/ES2/gl.h>
#import <OpenGLES/ES2/glext.h>
#include <dlfcn.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>
#include <gl4esinit.h>
#include "cod_gl_fresh51_policy_v1.h"
#include "cod_gl_worker_stack_policy_v1.h"
#include "cod_gl_borrow_failure_policy_v1.h"

/* Never return or unwind borrowed callers after uncertain queue publication.
 * No allocation, cleanup, retry or quiescence claim occurs on this path. */
static __attribute__((noinline,noreturn)) void cod_gl_borrow_failure_terminal_v1(void) {
 __builtin_trap();
}

extern int cod_gl4es_execute(CodGLNativeCall *,CodGLNativeResult *);
extern void cod_gl4es_finish(void);
extern int cod_gl_v13_gl4es_read_unpack(CodGLUnpackState *);
extern int cod_gl_v13_gl4es_read_client(CodGLClientState *);
extern int cod_gl_v13_gl4es_read_owned(uint32_t,CodGLOwnedStateV12 *);
static uint64_t createdContextGeneration;
static int cod_gl_composition_v1_install_owned_environment(uint32_t profile) {
 if(profile!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12)return COD_GL_ARGUMENT;
 if(getenv("LIBGL_VERSION"))return COD_GL_ARGUMENT; /* no advertised-version override in this profile */
 const char *names[]={"LIBGL_MIPMAP","LIBGL_SHRINK","LIBGL_TEXCOPY","LIBGL_TEXDUMP",
  "LIBGL_FORCE16BITS","LIBGL_AVOID24BITS","LIBGL_STREAM","LIBGL_NOLUMALPHA","LIBGL_FORCENPOT","LIBGL_NOERROR"};
 for(uint32_t i=0;i<sizeof(names)/sizeof(names[0]);i++)if(setenv(names[i],"0",1))return COD_GL_BACKEND;
 return 0;
}
static BOOL everCreated;
static CodGLRenderWorker *activeWorker;
/* All backend values below are accessed only on the owned serial queue. */
static void *nativeBackend;
static GLuint nativeDefaultFramebuffer;
static GLint nativeWidth,nativeHeight;
static void (*nativeBindFramebuffer)(GLenum,GLuint);
static void bind_default(GLenum target,GLuint name) {
 nativeBindFramebuffer(target,name?name:nativeDefaultFramebuffer);
}
static BOOL optional_native_profile_allows(const char *name,EAGLRenderingAPI api) {
 if(!strcmp(name,"glShadeModel"))return api==kEAGLRenderingAPIOpenGLES1;
 return YES;
}
static void *lookup_native(const char *name) {
 if(!optional_native_profile_allows(name,[EAGLContext currentContext].API))return NULL;
 if(!strcmp(name,"glBindFramebuffer") || !strcmp(name,"glBindFramebufferOES"))return (void *)bind_default;
 return dlsym(nativeBackend,name);
}
static void native_size(int *w,int *h) {*w=nativeWidth;*h=nativeHeight;}

/* Portable policy body: called only under the worker's admission lock. */
typedef enum {COD_LIFE_OPEN=0,COD_LIFE_RETIRING=1,COD_LIFE_RETAINED_FAILURE=2,COD_LIFE_CLOSED=3} CodGLLifePhase;
typedef struct {CodGLLifePhase phase;uint32_t in_flight;} CodGLLifetime;
static BOOL cod_lifetime_can_enter(const CodGLLifetime *s) {
 return s->phase==COD_LIFE_OPEN && s->in_flight<UINT32_MAX;
}
static BOOL cod_lifetime_enter(CodGLLifetime *s) {
 if(!cod_lifetime_can_enter(s))return NO;
 ++s->in_flight;return YES;
}
static BOOL cod_lifetime_leave(CodGLLifetime *s) {
 if(!s->in_flight){s->phase=COD_LIFE_RETAINED_FAILURE;return NO;}
 --s->in_flight;return YES;
}
/* -1 refuses without changing admission; 0 begins; 1 is already closed. */
static int cod_lifetime_begin_retirement(CodGLLifetime *s) {
 if(s->phase==COD_LIFE_CLOSED)return 1;
 if(s->phase!=COD_LIFE_OPEN || s->in_flight)return -1;
 s->phase=COD_LIFE_RETIRING;return 0;
}
static BOOL cod_lifetime_retirement_result(CodGLLifetime *s,BOOL completed) {
 if(s->phase!=COD_LIFE_RETIRING){s->phase=COD_LIFE_RETAINED_FAILURE;return NO;}
 s->phase=completed?COD_LIFE_CLOSED:COD_LIFE_RETAINED_FAILURE;return completed;
}
typedef enum {COD_RETIRE_REFUSE=-1,COD_RETIRE_CLEAN=0,COD_RETIRE_DRAIN=1} CodGLRetireAction;
/* Pure read of the existing typed snapshot. No GL/error calls or state writes. */
static CodGLRetireAction cod_retire_action(const CodGLClientState *s) {
 if(s->in_begin || s->compiling)return COD_RETIRE_REFUSE;
 if(!s->list_active && !s->list_pending)return COD_RETIRE_CLEAN;
 if(s->list_active && s->list_pending)return COD_RETIRE_DRAIN;
 return COD_RETIRE_REFUSE;
}
/* End portable policy body. */

@implementation CodGLView
+ (Class)layerClass {return [CAEAGLLayer class];}
@end

@interface CodGLCompositionJobV1 : NSObject
@property(nonatomic,copy) dispatch_block_t block;
@property(nonatomic,strong) dispatch_semaphore_t done;
@property(nonatomic) BOOL failed;
@end
@implementation CodGLCompositionJobV1
@end

@interface CodGLRenderWorker () {
 NSThread *_thread; NSCondition *_condition; NSMutableArray<CodGLCompositionJobV1 *> *_jobs;
 BOOL _stopping; EAGLContext *_context; CodGLView *_view; CAEAGLLayer *_layer;
 GLuint _framebuffer,_color,_depthStencil;
 BOOL _initialized,_active,_closed,_ownerSet;
 CodGLLifetime _lifetime;
 pthread_t _engineOwner;
 uint32_t _ownedProfileKind;uint64_t _contextGeneration;
 uintptr_t _freshGLStateIdentity;
 /* Written once by the first completed GL-thread init job; never a public getter. */
 pthread_t _stackThread;CodGLWorkerStackFactsV1 _stackStartup;BOOL _stackObserved;
 uint64_t _drawableGeneration;BOOL _factsValid;CodGLHostFactsV1 _facts;
}
- (BOOL)beginOperation:(BOOL)engine;
- (void)endOperation;
- (BOOL)operationsOpen;
- (BOOL)freshProfileStateAdmissible;
@end

@implementation CodGLRenderWorker
- (void)workerMain {
 /* A serial dispatch queue can change pthreads between blocks. EAGL current
  * context is thread-local, so all GL work stays on this actual NSThread. */
 @autoreleasepool {for(;;) {
  [_condition lock];while(!_jobs.count && !_stopping)[_condition wait];
  if(!_jobs.count && _stopping){[_condition unlock];break;}
  CodGLCompositionJobV1 *job=_jobs.firstObject;[_jobs removeObjectAtIndex:0];[_condition unlock];
  dispatch_semaphore_t completed=job.done;
  /* Do not publish completion before the job pool and owned block unwind. */
  @try {@autoreleasepool {
   @try {job.block();}
   @catch(...) {job.failed=YES;_active=NO;_factsValid=NO;}
   @finally {job.block=nil;}
  }} @catch(...) {job.failed=YES;_active=NO;_factsValid=NO;}
  @finally {job=nil;dispatch_semaphore_signal(completed);}
 }}
}
- (BOOL)performSync:(dispatch_block_t)block {
 if(!block || !_thread || !_condition || !_jobs)return NO;
 if([NSThread currentThread]==_thread){block();return YES;}
 /* Own these outside @try so the uncertain catch does not intentionally
  * release them before terminal failure. Only this producer reads phase. */
 CodGLCompositionJobV1 *job=nil;
 dispatch_semaphore_t completion=nil;
 volatile uint32_t phase=COD_GL_BORROW_UNPUBLISHED_V1;
 @try {
  job=[CodGLCompositionJobV1 new];if(!job)return NO;
  job.block=block;
  completion=dispatch_semaphore_create(0);if(!completion)return NO;
  job.done=completion;
  if(!job.block || job.done!=completion)return NO;
  [_condition lock];if(_stopping){[_condition unlock];return NO;}
  /* addObject may have published even when its caller sees an exception. */
  phase=COD_GL_BORROW_MAYBE_PUBLISHED_V1;
  [_jobs addObject:job];[_condition signal];[_condition unlock];
  long waitResult=dispatch_semaphore_wait(completion,DISPATCH_TIME_FOREVER);
  if(!cod_gl_borrow_wait_can_ack_v1(phase,waitResult))cod_gl_borrow_failure_terminal_v1();
  phase=COD_GL_BORROW_ACKNOWLEDGED_V1;
  return !job.failed;
 } @catch(...) {
  if(cod_gl_borrow_exception_fatal_v1(phase))cod_gl_borrow_failure_terminal_v1();
  @throw;
 }
}
- (BOOL)bindDrawable:(BOOL)checkInitialErrors {
 /* This is the existing storage/lifecycle transaction, never an ordinary GL
  * call. Invalidate before effects; publish only after all real measurements. */
 _factsValid=NO;
 if([EAGLContext currentContext]!=_context || !_contextGeneration ||
    _drawableGeneration==UINT64_MAX)return NO;
 GLint w=-1,h=-1,r=-1,g=-1,b=-1,a=-1,cf=-1,dw=-1,dh=-1,d=-1,s=-1,df=-1;
 GLint fbo=-1,ct=-1,cn=-1,dt=-1,dn=-1,st=-1,sn=-1;
 glBindRenderbuffer(GL_RENDERBUFFER,_color);
 if(![_context renderbufferStorage:GL_RENDERBUFFER fromDrawable:_layer])return NO;
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_WIDTH,&w);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_HEIGHT,&h);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_INTERNAL_FORMAT,&cf);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_RED_SIZE,&r);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_GREEN_SIZE,&g);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_BLUE_SIZE,&b);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_ALPHA_SIZE,&a);
 if(w<=0 || h<=0 || w>8192 || h>8192 || cf<=0 ||
    r<=0 || r>32 || g<=0 || g>32 || b<=0 || b>32 || a<0 || a>32)return NO;
 glBindFramebuffer(GL_FRAMEBUFFER,_framebuffer);
 glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_RENDERBUFFER,_color);
 glBindRenderbuffer(GL_RENDERBUFFER,_depthStencil);
 glRenderbufferStorage(GL_RENDERBUFFER,GL_DEPTH24_STENCIL8_OES,w,h);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_WIDTH,&dw);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_HEIGHT,&dh);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_INTERNAL_FORMAT,&df);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_DEPTH_SIZE,&d);
 glGetRenderbufferParameteriv(GL_RENDERBUFFER,GL_RENDERBUFFER_STENCIL_SIZE,&s);
 if(dw!=w || dh!=h || df<=0 || d<=0 || d>32 || s<=0 || s>32)return NO;
 glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_RENDERBUFFER,_depthStencil);
 glFramebufferRenderbuffer(GL_FRAMEBUFFER,GL_STENCIL_ATTACHMENT,GL_RENDERBUFFER,_depthStencil);
 glGetIntegerv(GL_FRAMEBUFFER_BINDING,&fbo);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,&ct);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_COLOR_ATTACHMENT0,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,&cn);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,&dt);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_DEPTH_ATTACHMENT,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,&dn);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_STENCIL_ATTACHMENT,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE,&st);
 glGetFramebufferAttachmentParameteriv(GL_FRAMEBUFFER,GL_STENCIL_ATTACHMENT,GL_FRAMEBUFFER_ATTACHMENT_OBJECT_NAME,&sn);
 if(fbo<=0 || (GLuint)fbo!=_framebuffer || ct!=GL_RENDERBUFFER || dt!=GL_RENDERBUFFER || st!=GL_RENDERBUFFER ||
    cn<=0 || dn<=0 || sn<=0 || (GLuint)cn!=_color || (GLuint)dn!=_depthStencil || (GLuint)sn!=_depthStencil)return NO;
 glBindRenderbuffer(GL_RENDERBUFFER,_color);
 if(glCheckFramebufferStatus(GL_FRAMEBUFFER)!=GL_FRAMEBUFFER_COMPLETE ||
    (checkInitialErrors && glGetError()!=GL_NO_ERROR))return NO;
 CodGLHostFactsV1 facts={0};
 facts.abi=COD_GL_HOST_ABI_V1;facts.bytes=sizeof(facts);facts.profile_kind=_ownedProfileKind;
 facts.worker_identity=(uintptr_t)(__bridge void *)self;facts.context_identity=(uintptr_t)(__bridge void *)_context;
 facts.context_generation=_contextGeneration;facts.drawable_generation=_drawableGeneration+1;
 facts.framebuffer=_framebuffer;facts.color_renderbuffer=_color;facts.depth_stencil_renderbuffer=_depthStencil;
 facts.width=(uint32_t)w;facts.height=(uint32_t)h;facts.color_format=(uint32_t)cf;facts.depth_stencil_format=(uint32_t)df;
 facts.red_bits=(uint32_t)r;facts.green_bits=(uint32_t)g;facts.blue_bits=(uint32_t)b;facts.alpha_bits=(uint32_t)a;
 facts.depth_bits=(uint32_t)d;facts.stencil_bits=(uint32_t)s;
 nativeWidth=w;nativeHeight=h;_drawableGeneration=facts.drawable_generation;_facts=facts;_factsValid=YES;
 return YES;
}
- (int)readFacts:(CodGLHostFactsV1 *)facts {
 if(!facts || ![self beginOperation:YES])return COD_GL_BACKEND;
 @try {
 __block int status=COD_GL_BACKEND;
 if(![self performSync:^{
  if(!self->_active || self->_closed || !self->_factsValid ||
     [EAGLContext currentContext]!=self->_context || self->_facts.context_generation!=self->_contextGeneration ||
     self->_facts.drawable_generation!=self->_drawableGeneration)return;
  *facts=self->_facts;status=0;
 }])return COD_GL_BACKEND;
 return status;
 } @finally {[self endOperation];}
}

- (instancetype)initWithView:(CodGLView *)view error:(NSError **)error {
 return [self initWithView:view ownedTextureProfile:COD_GL_PROFILE_NONE_V12 error:error];
}
- (instancetype)initWithView:(CodGLView *)view ownedTextureProfile:(uint32_t)namedProfile error:(NSError **)error {
 if(namedProfile!=COD_GL_PROFILE_NONE_V12 && namedProfile!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12){
  if(error)*error=[NSError errorWithDomain:@"CodGL" code:4 userInfo:@{NSLocalizedDescriptionKey:@"Unknown source/API texture profile"}];return nil;
 }
 if(!(self=[super init]))return nil;
 if(![NSThread isMainThread] || UIApplication.sharedApplication.applicationState==UIApplicationStateBackground ||
    !view.window || view.bounds.size.width<=0 || view.bounds.size.height<=0) {
  if(error)*error=[NSError errorWithDomain:@"CodGL" code:1 userInfo:@{NSLocalizedDescriptionKey:@"Attached nonzero UIKit drawable on main is required"}];return nil;
 }
 @synchronized([CodGLRenderWorker class]) {
  if(everCreated) {if(error)*error=[NSError errorWithDomain:@"CodGL" code:2 userInfo:@{NSLocalizedDescriptionKey:@"GL4ES process-global context cannot be recreated"}];return nil;}
  everCreated=YES;activeWorker=self;
 }
 _ownedProfileKind=namedProfile;
 _view=view;view.opaque=YES;view.contentScaleFactor=view.window.screen.scale;_layer=(CAEAGLLayer *)view.layer;
 _layer.drawableProperties=@{kEAGLDrawablePropertyRetainedBacking:@NO,kEAGLDrawablePropertyColorFormat:kEAGLColorFormatRGBA8};
 _condition=[NSCondition new];_jobs=[NSMutableArray array];
 _thread=[[NSThread alloc] initWithTarget:self selector:@selector(workerMain) object:nil];
 if(!_condition || !_jobs || !_thread) {
  /* No thread/job was started. Preserve the process-life partial owner. */
  if(error)*error=[NSError errorWithDomain:@"CodGL" code:5 userInfo:@{NSLocalizedDescriptionKey:@"Owned GL queue/thread construction failed"}];return nil;
 }
 _thread.name=@"cod.native.gl.render";
 _thread.stackSize=(NSUInteger)COD_GL_WORKER_STACK_REQUEST_BYTES_V1;
 [_thread start];
 __block BOOL ok=NO;
 BOOL initCompleted=[self performSync:^{
  /* Capacity refusal returns normally through workerMain's completion signal. */
  if(self->_stackObserved || [NSThread currentThread]!=self->_thread)return;
  pthread_t actualGLThread=pthread_self();
  uintptr_t actualHigh=(uintptr_t)pthread_get_stackaddr_np(actualGLThread);
  uintptr_t actualBytes=(uintptr_t)pthread_get_stacksize_np(actualGLThread);
  uintptr_t actualSP=0;
#if defined(__arm64__) || defined(__aarch64__)
  __asm__ volatile("mov %0, sp" : "=r"(actualSP));
#else
#error This worker stack observation requires a real ARM64 SP sample
#endif
  CodGLWorkerStackFactsV1 observed={0};
  if(!cod_gl_worker_stack_validate_v1(actualHigh,actualBytes,actualSP,
       (uintptr_t)COD_GL_WORKER_STACK_REQUEST_BYTES_V1,&observed))return;
  self->_stackThread=actualGLThread;self->_stackStartup=observed;self->_stackObserved=YES;
  self->_context=[[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
  if(!self->_context || ![EAGLContext setCurrentContext:self->_context] || createdContextGeneration==UINT64_MAX)return;
  self->_contextGeneration=++createdContextGeneration;
  const char *extensions=(const char *)glGetString(GL_EXTENSIONS);
  /* Stencil capability is required, not silently replaced with a depth-only surface. */
  if(!extensions || !strstr(extensions,"GL_OES_packed_depth_stencil"))return;
  nativeBackend=dlopen("/System/Library/Frameworks/OpenGLES.framework/OpenGLES",RTLD_NOW|RTLD_LOCAL);
  if(!nativeBackend)return;
  nativeBindFramebuffer=(void (*)(GLenum,GLuint))dlsym(nativeBackend,"glBindFramebuffer");
  if(!nativeBindFramebuffer)return;
  glGenFramebuffers(1,&self->_framebuffer);glGenRenderbuffers(1,&self->_color);glGenRenderbuffers(1,&self->_depthStencil);
  nativeDefaultFramebuffer=self->_framebuffer;
  if(![self bindDrawable:YES])return;
  if(self->_ownedProfileKind && cod_gl_composition_v1_install_owned_environment(self->_ownedProfileKind))return;
  set_getprocaddress(lookup_native);set_getmainfbsize(native_size);initialize_gl4es();self->_initialized=YES;
  if(self->_ownedProfileKind){
   CodGLOwnedStateV12 actual;
   if(cod_gl_v13_gl4es_read_owned(0,&actual) || actual.automipmap || actual.forbidden_globals || actual.esversion<2)return;
   if(!actual.glstate_identity)return;
   self->_freshGLStateIdentity=actual.glstate_identity;
  }
  self->_active=YES;ok=YES;
 }];
 if(!initCompleted || !ok) {
  [self close];
  if(error)*error=[NSError errorWithDomain:@"CodGL" code:3 userInfo:@{NSLocalizedDescriptionKey:@"Real EAGL color/depth/stencil surface or native backend setup failed"}];return nil;
 }return self;
}
- (BOOL)beginOperation:(BOOL)engine {
 @synchronized(self) {
  /* Refuse terminal/overflow state before even considering owner mutation. */
  if(!cod_lifetime_can_enter(&self->_lifetime))return NO;
  pthread_t now;
  if(engine){now=pthread_self();if(self->_ownerSet && !pthread_equal(now,self->_engineOwner))return NO;}
  if(!cod_lifetime_enter(&self->_lifetime))return NO;
  if(engine && !self->_ownerSet){self->_engineOwner=now;self->_ownerSet=YES;}
  return YES;
 }
}
- (void)endOperation {
 @synchronized(self) {(void)cod_lifetime_leave(&self->_lifetime);}
}
- (BOOL)operationsOpen {
 @synchronized(self) {return self->_lifetime.phase==COD_LIFE_OPEN;}
}
- (BOOL)freshProfileStateAdmissible {
 if(!_ownedProfileKind)return YES;
 if(_ownedProfileKind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12||!_freshGLStateIdentity||
    !_active||_closed||[EAGLContext currentContext]!=_context)return NO;
 CodGLOwnedStateV12 actual;
 if(cod_gl_v13_gl4es_read_owned(0,&actual))return NO;
 /* Raw reader supplies private GLstate identity, NOT public context/profile
  * identities. Existing EAGL guard and upload-specific binding stay separate.
  * Never call basic(): ordinary immediate Begin/End/pending may be live. */
 return actual.glstate_identity==_freshGLStateIdentity&&!actual.forbidden_globals;
}
- (int)invoke:(CodGLNativeCall *)call result:(CodGLNativeResult *)result {
 if(result)result->pixel_effect=COD_GL_PIXELS_NOT_CONSUMED_V12;
 if(!call || !result || ![self beginOperation:YES])return COD_GL_BACKEND;
 @try {
 __block int status=COD_GL_BACKEND;
 void (^work)(void)=^{
  if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context)return;
  if(![self freshProfileStateAdmissible])return;
  if(self->_ownedProfileKind&&cod_gl_fresh51_command_refused_v1(call))return;
  if(call->owned_profile_kind){
   CodGLOwnedStateV12 actual;
   if(cod_gl_v13_gl4es_read_owned(0,&actual))return;
   actual.context_identity=(uintptr_t)(__bridge void *)self->_context;actual.context_generation=self->_contextGeneration;actual.profile_kind=self->_ownedProfileKind;
   if(cod_gl_owned_v13_verify_worker_call(call,&actual))return;
  }
  status=cod_gl4es_execute(call,result);
  if(!status && (((call->function==COD_GL_TEX_IMAGE_2D || call->function==COD_GL_COMPRESSED_TEX_IMAGE_2D) && call->pixels) || call->function==COD_GL_DRAW_ARRAYS || call->function==COD_GL_DRAW_ELEMENTS)) {
   if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context){status=COD_GL_BACKEND;return;}
   /* Native GLES, not namespaced GL4ES: do not clear/query the shim's error
    * route. Complete native reads before returning the staging/guest lease. */
   glFinish();
   if(call->pixels)result->pixel_effect=COD_GL_PIXELS_COMPLETED_V12;
  }
  BOOL postAllowed=[self freshProfileStateAdmissible];
  if(!status&&!postAllowed)status=COD_GL_BACKEND;
 };
 if(![self performSync:work])return COD_GL_BACKEND;
 return status;
 } @finally {[self endOperation];}
}
- (BOOL)present {
 if(![self beginOperation:YES])return NO;
 @try {
 __block BOOL ok=NO;
 void (^work)(void)=^{
  if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context)return;
  if(![self freshProfileStateAdmissible])return;
  cod_gl4es_finish();glBindRenderbuffer(GL_RENDERBUFFER,self->_color);
  ok=[self->_context presentRenderbuffer:GL_RENDERBUFFER];
  if(![self freshProfileStateAdmissible])ok=NO;
 };
 if(![self performSync:work])return NO;
 return ok;
 } @finally {[self endOperation];}
}
- (int)readUnpack:(CodGLUnpackState *)state {
 if(!state || ![self beginOperation:YES])return COD_GL_BACKEND;
 @try {
 __block int status=COD_GL_BACKEND;
 if(![self performSync:^{
  if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context)return;
  status=cod_gl_v13_gl4es_read_unpack(state);
 }])return COD_GL_BACKEND;
 return status;
 } @finally {[self endOperation];}
}
- (CGSize)drawablePixelSize {
 if(![self beginOperation:NO])return CGSizeZero;
 @try {__block CGSize size=CGSizeZero;[self performSync:^{if(!self->_closed)size=CGSizeMake(nativeWidth,nativeHeight);}];return size;}
 @finally {[self endOperation];}
}
- (int)readClient:(CodGLClientState *)state {
 if(!state || ![self beginOperation:YES])return COD_GL_BACKEND;
 @try {
 __block int status=COD_GL_BACKEND;
 if(![self performSync:^{
  if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context)return;
  status=cod_gl_v13_gl4es_read_client(state);
 }])return COD_GL_BACKEND;
 return status;
 } @finally {[self endOperation];}
}
- (int)readOwned:(CodGLOwnedStateV12 *)state requestedName:(uint32_t)name {
 if(!state || ![self beginOperation:YES])return COD_GL_BACKEND;
 @try {
 __block int status=COD_GL_BACKEND;
 if(![self performSync:^{
  if(!self->_active || self->_closed || [EAGLContext currentContext]!=self->_context)return;
  status=cod_gl_v13_gl4es_read_owned(name,state);
  if(!status){state->context_identity=(uintptr_t)(__bridge void *)self->_context;state->context_generation=self->_contextGeneration;state->profile_kind=self->_ownedProfileKind;}
 }])return COD_GL_BACKEND;
 return status;
 } @finally {[self endOperation];}
}
- (BOOL)pauseAndDrain {
 if(![NSThread isMainThread])return NO;
 if(![self operationsOpen])return NO;
 __block BOOL ok=NO;BOOL completed=[self performSync:^{
  if(self->_closed)return;
  self->_active=NO;self->_factsValid=NO;
  EAGLContext *current=[EAGLContext currentContext];
  /* Inactive is not proof of clearing: an exception or a failed earlier
   * clear can leave this context current. Never issue GL against no context
   * or an unexpected foreign context on the owned thread. */
  if(current && current!=self->_context)return;
  if(current==self->_context && current && self->_initialized)cod_gl4es_finish();
  ok=[EAGLContext setCurrentContext:nil] && [EAGLContext currentContext]==nil;
 }];return completed && ok;
}
- (BOOL)resume {
 if(![NSThread isMainThread] || UIApplication.sharedApplication.applicationState==UIApplicationStateBackground)return NO;
 if(![self operationsOpen])return NO;
 __block BOOL ok=NO;[self performSync:^{
  if(self->_closed || self->_active)return;
  if(![EAGLContext setCurrentContext:self->_context])return;
  /* Host has stopped engine calls and completed UIKit layout before resume. */
  /* Preserve pending engine error state: do not consume glGetError on resume. */
  if(![self bindDrawable:NO]){[EAGLContext setCurrentContext:nil];return;}
  self->_active=YES;ok=YES;
 }];return ok;
}
- (BOOL)close {
 if(![NSThread isMainThread] || UIApplication.sharedApplication.applicationState==UIApplicationStateBackground)return NO;
 int admission;
 @synchronized(self) {admission=cod_lifetime_begin_retirement(&self->_lifetime);}
 if(admission<0)return NO;
 if(admission>0)return YES;
 /* The host has separately stopped the entire bridge/guest/staging domain.
  * The ticket count proves only absence of admitted public worker operations. */
 if(!_thread || !_condition || !_jobs) {
  @synchronized(self) {(void)cod_lifetime_retirement_result(&self->_lifetime,NO);}return NO;
 }
 __block BOOL ok=NO;BOOL completed=NO;
 @try {completed=[self performSync:^{
  /* Unknown/partial initialization is deliberately retained for process exit. */
  if(!self->_initialized || !self->_context)return;
  EAGLContext *current=[EAGLContext currentContext];
  if(current && current!=self->_context)return;
  if(!current && ![EAGLContext setCurrentContext:self->_context])return;
  if([EAGLContext currentContext]!=self->_context)return;
  self->_active=NO;self->_factsValid=NO;
  CodGLClientState state={0};
  if(cod_gl_v13_gl4es_read_client(&state))return;
  CodGLRetireAction action=cod_retire_action(&state);
  if(action==COD_RETIRE_REFUSE)return;
  if(action==COD_RETIRE_DRAIN) {
   cod_gl4es_finish();
   if([EAGLContext currentContext]!=self->_context)return;
   state=(CodGLClientState){0};
   if(cod_gl_v13_gl4es_read_client(&state) || cod_retire_action(&state)!=COD_RETIRE_CLEAN)return;
  }
  if(self->_initialized){close_gl4es();self->_initialized=NO;}
  if(self->_framebuffer)glDeleteFramebuffers(1,&self->_framebuffer);
  if(self->_color)glDeleteRenderbuffers(1,&self->_color);
  if(self->_depthStencil)glDeleteRenderbuffers(1,&self->_depthStencil);
  self->_framebuffer=self->_color=self->_depthStencil=0;
  set_getprocaddress(NULL);set_getmainfbsize(NULL);
  nativeDefaultFramebuffer=0;nativeWidth=nativeHeight=0;nativeBindFramebuffer=NULL;
  if(nativeBackend)dlclose(nativeBackend);nativeBackend=NULL;
  ok=[EAGLContext setCurrentContext:nil] && [EAGLContext currentContext]==nil;
  if(ok){self->_context=nil;self->_closed=YES;}
 }];} @catch(NSException *exception) {(void)exception;completed=NO;}
 BOOL retired;
 @synchronized(self) {retired=cod_lifetime_retirement_result(&self->_lifetime,completed && ok);}
 if(retired){[_condition lock];_stopping=YES;[_condition signal];[_condition unlock];}
 if(retired){@synchronized([CodGLRenderWorker class]){if(activeWorker==self)activeWorker=nil;}}
 /* Once destruction has begun, NO retains uncertain remaining ownership. It
  * does not promise a live unchanged context and never retries destruction. */
 return retired;
}
@end

/* Raw worker-pointer C callbacks are deliberately absent. Use capsule API. */
