#ifndef COD_GL_WORKER_STACK_POLICY_V1_H
#define COD_GL_WORKER_STACK_POLICY_V1_H
#include <stdint.h>
#define COD_GL_WORKER_STACK_REQUEST_BYTES_V1 UINT64_C(8388608)
typedef struct {uintptr_t low,high,sp,requested_bytes,observed_bytes;} CodGLWorkerStackFactsV1;
_Static_assert(sizeof(uintptr_t)==8,"64-bit worker stack observation");
static inline int cod_gl_worker_stack_validate_v1(uintptr_t high,uintptr_t bytes,uintptr_t sp,
                                                uintptr_t requested,CodGLWorkerStackFactsV1 *out) {
 /* This finite constructor policy has a fixed request; no cap/clamp fallback. */
 if(!out || !high || !bytes || !sp || requested!=(uintptr_t)COD_GL_WORKER_STACK_REQUEST_BYTES_V1 ||
    bytes<requested || ((high|bytes|sp|requested)&(uintptr_t)15) || bytes>=high)return 0;
 uintptr_t low=high-bytes; /* guarded subtraction, nonzero low */
 if(sp<low || sp>=high)return 0;
 /* Commit once only after every check. Caller owns a stable writable POD. */
 out->low=low;out->high=high;out->sp=sp;out->requested_bytes=requested;out->observed_bytes=bytes;
 return 1;
}
#endif
