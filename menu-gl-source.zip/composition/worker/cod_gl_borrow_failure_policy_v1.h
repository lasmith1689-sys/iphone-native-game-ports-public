#ifndef COD_GL_BORROW_FAILURE_POLICY_V1_H
#define COD_GL_BORROW_FAILURE_POLICY_V1_H
#include <stdint.h>
/* Producer-local states, never shared with the job executor. MAYBE is set
 * before the first operation that might publish a borrowed job. */
enum {COD_GL_BORROW_UNPUBLISHED_V1=0,COD_GL_BORROW_MAYBE_PUBLISHED_V1=1,
      COD_GL_BORROW_ACKNOWLEDGED_V1=2};
static inline int cod_gl_borrow_exception_fatal_v1(uint32_t phase) {
 return phase!=COD_GL_BORROW_UNPUBLISHED_V1 && phase!=COD_GL_BORROW_ACKNOWLEDGED_V1;
}
static inline int cod_gl_borrow_wait_can_ack_v1(uint32_t phase,int64_t result) {
 return phase==COD_GL_BORROW_MAYBE_PUBLISHED_V1 && result==0;
}
#endif
