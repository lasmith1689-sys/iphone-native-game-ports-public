#import "worker/cod_gl_ios.h"
#include <pthread.h>
#include <stdlib.h>
#include <stdatomic.h>

enum {CAP_NEW=0,CAP_IDLE=1,CAP_ENGINE=2,CAP_MAIN=3,CAP_FAILED=4,CAP_CLOSED=5};
struct CodGLHostCapsuleV1 { _Atomic uint32_t phase;pthread_t engine;uint32_t owner_set; };
static CodGLHostCapsuleV1 canonicalCapsule;
static CodGLCompositionWorkerV1 *canonicalWorker; /* process-life strong quarantine */
static int known(const void *p){return p==&canonicalCapsule;}
static int fail(void){atomic_store_explicit(&canonicalCapsule.phase,CAP_FAILED,memory_order_release);return COD_GL_HOST_BACKEND_V1;}
static int engine(const void *p){
 return known(p) && atomic_load_explicit(&canonicalCapsule.phase,memory_order_acquire)==CAP_ENGINE &&
  canonicalCapsule.owner_set && pthread_equal(canonicalCapsule.engine,pthread_self());
}
int cod_gl_host_v1_validate(CodGLHostCapsuleV1 *p){
 return known(p) && atomic_load_explicit(&canonicalCapsule.phase,memory_order_acquire)==CAP_IDLE?0:COD_GL_HOST_STATE_V1;
}
int cod_gl_host_v1_create(CodGLCompositionViewV1 *view,CodGLHostCapsuleV1 **out){
 if(!out)return COD_GL_HOST_ARGUMENT_V1;*out=NULL;
 @try {@autoreleasepool {
  if(!view || ![NSThread isMainThread] || [view class]!=[CodGLCompositionViewV1 class])return COD_GL_HOST_ARGUMENT_V1;
  uint32_t expected=CAP_NEW;
  if(!atomic_compare_exchange_strong_explicit(&canonicalCapsule.phase,&expected,CAP_MAIN,memory_order_acq_rel,memory_order_acquire))return COD_GL_HOST_STATE_V1;
  canonicalWorker=[[CodGLCompositionWorkerV1 alloc] initWithView:view ownedTextureProfile:COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 error:NULL];
  if(!canonicalWorker)return fail();
  atomic_store_explicit(&canonicalCapsule.phase,CAP_IDLE,memory_order_release);*out=&canonicalCapsule;return 0;
 }}@catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_enter(CodGLHostCapsuleV1 *p){
 if(!known(p))return COD_GL_HOST_ARGUMENT_V1;
 if(pthread_main_np())return COD_GL_HOST_STATE_V1;
 uint32_t expected=CAP_IDLE;
 if(!atomic_compare_exchange_strong_explicit(&p->phase,&expected,CAP_ENGINE,memory_order_acq_rel,memory_order_acquire))return COD_GL_HOST_STATE_V1;
 pthread_t now=pthread_self();
 if(p->owner_set && !pthread_equal(now,p->engine)){atomic_store_explicit(&p->phase,CAP_IDLE,memory_order_release);return COD_GL_HOST_STATE_V1;}
 if(!p->owner_set){p->engine=now;p->owner_set=1;}return 0;
}
int cod_gl_host_v1_leave(CodGLHostCapsuleV1 *p,int success){
 if(!engine(p))return COD_GL_HOST_STATE_V1;
 atomic_store_explicit(&p->phase,success?CAP_IDLE:CAP_FAILED,memory_order_release);
 return success?0:COD_GL_HOST_BACKEND_V1;
}
int cod_gl_host_v1_read_facts(CodGLHostCapsuleV1 *p,CodGLHostFactsV1 *out){
 if(!engine(p) || !out)return COD_GL_HOST_STATE_V1;
 @try {@autoreleasepool {int rc=[canonicalWorker readFacts:out];return rc?fail():0;}}
 @catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_invoke(void *p,CodGLNativeCall *call,CodGLNativeResult *result){
 if(!engine(p) || !call || !result)return COD_GL_BACKEND;
 @try {@autoreleasepool {int rc=[canonicalWorker invoke:call result:result];return rc?fail():0;}}
 @catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_read_unpack(void *p,CodGLUnpackState *state){
 if(!engine(p) || !state)return COD_GL_BACKEND;
 @try {@autoreleasepool {int rc=[canonicalWorker readUnpack:state];return rc?fail():0;}}
 @catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_read_client(void *p,CodGLClientState *state){
 if(!engine(p) || !state)return COD_GL_BACKEND;
 @try {@autoreleasepool {int rc=[canonicalWorker readClient:state];return rc?fail():0;}}
 @catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_read_owned(void *p,uint32_t requested,CodGLOwnedStateV12 *state){
 if(!engine(p) || !state)return COD_GL_BACKEND;
 @try {@autoreleasepool {int rc=[canonicalWorker readOwned:state requestedName:requested];return rc?fail():0;}}
 @catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_present(CodGLHostCapsuleV1 *p,uint64_t generation){
 if(!engine(p) || !generation)return COD_GL_HOST_STATE_V1;
 @try {@autoreleasepool {
  CodGLHostFactsV1 facts={0};
  if([canonicalWorker readFacts:&facts] || facts.drawable_generation!=generation)return fail();
  return [canonicalWorker present]?0:fail();
 }}@catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
/* No ObjC or GL in allocator callbacks. Only the own bridge may release its
 * exact allocator-owned pointer, including a provably unused/completed stage
 * after capsule failure. Failed/uncertain stages are not passed to release. */
void *cod_gl_host_v1_allocate(void *p,uint32_t bytes,uint32_t alignment){
 if(!engine(p) || !bytes || bytes>COD_GL_MAX_STAGING_BYTES || alignment!=COD_GL_STAGING_ALIGNMENT)return NULL;
 void *out=NULL;if(posix_memalign(&out,alignment,bytes))return NULL;return out;
}
void cod_gl_host_v1_release(void *p,void *allocation){if(known(p))free(allocation);}
static int lifecycle(CodGLHostCapsuleV1 *p,uint32_t op){
 if(!known(p))return COD_GL_HOST_ARGUMENT_V1;
 @try {@autoreleasepool {
  if(![NSThread isMainThread])return COD_GL_HOST_STATE_V1;
  uint32_t expected=CAP_IDLE;
  if(!atomic_compare_exchange_strong_explicit(&p->phase,&expected,CAP_MAIN,memory_order_acq_rel,memory_order_acquire))return COD_GL_HOST_STATE_V1;
  BOOL ok=op==0?[canonicalWorker pauseAndDrain]:op==1?[canonicalWorker resume]:[canonicalWorker close];
  if(!ok)return fail();
  atomic_store_explicit(&p->phase,op==2?CAP_CLOSED:CAP_IDLE,memory_order_release);return 0;
 }}@catch(NSException *exception){(void)exception;fail();return COD_GL_HOST_EXCEPTION_V1;}
}
int cod_gl_host_v1_pause(CodGLHostCapsuleV1 *p){return lifecycle(p,0);}
int cod_gl_host_v1_resume(CodGLHostCapsuleV1 *p){return lifecycle(p,1);}
int cod_gl_host_v1_close(CodGLHostCapsuleV1 *p){return lifecycle(p,2);}
