#ifndef COD_GL_COMPRESSED_STAGE_V12_H
#define COD_GL_COMPRESSED_STAGE_V12_H
#include "cod_gl_dispatch.h"
/* Pure host preparation. Neither this component nor success admits a GL profile,
 * texture object, context, GPU allocation, resolver spelling or native invoke.
 * Native callbacks must be a stable unique-allocation allocator, as in ABI11. */
typedef struct {
 uint32_t words[8],return_sp,format,row_bytes,row_stride,readable_bytes,owned_bytes;
 void *pixels;
} CodGLCompressedStageV12;
/* Registers/read mapping/output are untouched on failure. On success pixels is
 * the sole owned stage; caller frees it after real completion or quarantines it
 * if an invoke can have consumed it. Decode scratch has already been released. */
COD_GL_API int cod_gl_v13_prepare_compressed(CodGLMemory memory,CodGLAllocator allocator,
 const uint8_t *registers,uint32_t register_bytes,uint32_t actual_unpack_alignment,
 CodGLCompressedStageV12 *out);
#endif
