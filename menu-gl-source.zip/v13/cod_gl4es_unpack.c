/* Compile using the EXACT pinned glstate.c compile-db command/defines, changing
 * only source and output paths. Private layout is never guessed or serialized.
 * This read-only helper performs no GL query, flush, allocation or error read. */
#include "cod_gl_dispatch.h"
#include "gl4es.h"
#include "../glx/hardext.h"
#include "init.h"
#include "texture.h"
#include <stddef.h>
_Static_assert(sizeof(uintptr_t)==8 && sizeof(CodGLArray)==40,"Actual native64 array ABI");
_Static_assert(offsetof(CodGLClientState,texture_unit_count)==40 && offsetof(CodGLClientState,texture_coordinate_base)==44 &&
 offsetof(CodGLClientState,attributes)==48 && sizeof(CodGLClientState)==1328,"Actual SDK compiled ABI10 metadata");

int cod_gl_v13_gl4es_read_unpack(CodGLUnpackState *out) {
 if(!out || !glstate || !glstate->vao)return COD_GL_BACKEND;
 out->alignment=glstate->texture.unpack_align;
 out->row_length=glstate->texture.unpack_row_length;
 out->skip_rows=glstate->texture.unpack_skip_rows;
 out->skip_pixels=glstate->texture.unpack_skip_pixels;
 out->in_begin=glstate->list.begin?1u:0u;
 out->compiling=glstate->list.compiling?1u:0u;
 out->unpack_buffer_bound=glstate->vao->unpack?1u:0u;
 out->texture_options=(globals4es.texcopydata || globals4es.texshrink || globals4es.force16bits ||
  globals4es.avoid24bits || globals4es.automipmap || globals4es.texstream || globals4es.nolumalpha || globals4es.forcenpot)?1u:0u;
 int units=hardext.maxtex;
 if(units<1 || units>MAX_TEX || units>COD_GL_MAX_TEXTURE_UNITS || glstate->texture.active>=(uint32_t)units)return COD_GL_BACKEND;
 gltexture_t *bound=glstate->texture.bound[glstate->texture.active][ENABLED_TEX2D];
 if(!bound)return COD_GL_BACKEND;
 /* -1 is the actual pinned default/no-base-override sentinel, not a request
  * for level1. At admitted upload level0, base_level==level is false for-1. */
 out->texture_object_options=(bound->shrink || bound->base_level>0 || bound->base_level< -1 || bound->mipmap_auto ||
  bound->mipmap_need || bound->npot || bound->streamed || bound->compressed)?1u:0u;
 return 0;
}

int cod_gl_v13_gl4es_read_client(CodGLClientState *out) {
 if(!out || !glstate || !glstate->vao || MAX_VATTRIB>COD_GL_MAX_ATTRIBUTES)return COD_GL_BACKEND;
 int units=hardext.maxtex;uint32_t base=(uint32_t)ATT_MULTITEXCOORD0;
 if(units<1 || units>MAX_TEX || units>COD_GL_MAX_TEXTURE_UNITS || base<4u || base>MAX_VATTRIB ||
    (uint32_t)units>MAX_VATTRIB-base || glstate->texture.client>=(uint32_t)units || glstate->texture.active>=(uint32_t)units)return COD_GL_BACKEND;
 glvao_t *vao=glstate->vao;
 out->in_begin=glstate->list.begin?1u:0u;
 out->compiling=glstate->list.compiling?1u:0u;
 out->array_buffer_bound=vao->vertex?1u:0u;
 out->list_active=glstate->list.active?1u:0u;
 out->list_pending=glstate->list.pending?1u:0u;
 out->element_buffer_bound=vao->elements?1u:0u;
 out->client_texture=glstate->texture.client;
 out->server_texture=glstate->texture.active;
 out->attribute_count=MAX_VATTRIB;
 out->texture_unit_count=(uint32_t)units;out->texture_coordinate_base=base;
 /* Named-VAO/shared/locked caches are deliberately outside this slice. */
 out->locked=(vao->locked || vao->array || vao->shared_arrays || vao!=glstate->defaultvao)?1u:0u;
 for(uint32_t k=0;k<MAX_VATTRIB;++k) {
  vertexattrib_t *a=vao->vertexattrib+k;CodGLArray *b=out->attributes+k;
  b->kind=k==ATT_VERTEX?COD_GL_ARRAY_VERTEX:k==ATT_NORMAL?COD_GL_ARRAY_NORMAL:
          k==ATT_COLOR?COD_GL_ARRAY_COLOR:(k>=base && k-base<(uint32_t)units)?COD_GL_ARRAY_TEXCOORD0+k-base:0u;
  b->enabled=a->enabled?1u:0u;b->size=(uint32_t)a->size;b->type=a->type;b->stride=(uint32_t)a->stride;
  b->buffer_bound=(a->buffer || a->real_buffer || a->real_pointer)?1u:0u;b->divisor=(uint32_t)a->divisor;
  b->pointer=(uintptr_t)a->pointer;
 }
 return 0;
}

/* ABI12 actual-layout reads. This function neither creates a texture nor writes
 * private backend fields. Unit/name/context identities remain native pointers. */
#include "cod_gl_owned_profile.h"
static void cod_gl_v13_fact(CodGLTextureFactV12 *out,const gltexture_t *t,uint32_t unit) {
 CodGLTextureFactV12 empty={0};*out=empty;
 out->enabled_targets=glstate->enable.texture[unit];
 out->sampler_override=glstate->samplers.sampler[unit]?1u:0u;
 if(!t)return;
 out->identity=(uintptr_t)t;out->name=t->texture;out->native_name=t->glname;out->target=t->target;
 out->width=t->width;out->height=t->height;out->nwidth=t->nwidth;out->nheight=t->nheight;
 out->base_level=t->base_level;out->max_level=t->max_level;out->valid=t->valid;
 out->mipmap_auto=t->mipmap_auto;out->mipmap_need=t->mipmap_need;out->mipmap_done=t->mipmap_done;
 out->min_filter=t->sampler.min_filter;out->mag_filter=t->sampler.mag_filter;
 out->wrap_s=t->sampler.wrap_s;out->wrap_t=t->sampler.wrap_t;
 out->forbidden=(t->shrink?1u:0u)|(t->npot?2u:0u)|(t->streamed?4u:0u)|(t->compressed?8u:0u)|
  (t->useratio?16u:0u)|(t->adjust?32u:0u)|(t->binded_fbo?64u:0u)|(t->renderdepth?128u:0u)|
  (t->renderstencil?256u:0u)|(t->data?512u:0u);
}
/* Scalar-only fresh51 restrictions. Existing ABI12 bits0..8 stay unchanged.
 * Trust the actual valid private object graph/lifetime, as the original reader
 * already does. No GL query, flush, allocation or private-state repair here. */
static uint32_t cod_gl_fresh51_forbidden_v1(void) {
 enum {MISSING=0x0200u,USER_PROGRAM=0x0400u,LEGACY_PROGRAM=0x0800u,
       NAMED_LIST=0x1000u,RASTER=0x2000u,VIRTUAL_FBO=0x4000u,ATTACHMENT=0x8000u};
 if(!glstate||!glstate->glsl||!glstate->fpe_state||!glstate->headlists||
    !glstate->fbo.framebufferlist||!glstate->fbo.renderbufferlist||
    !glstate->fbo.fbo_0||!glstate->fbo.default_rb)return MISSING;
 uint32_t bad=(globals4es.es!=2||hardext.esversion!=2)?MISSING:0;
 if(glstate->glsl->program||glstate->glsl->glprogram)bad|=USER_PROGRAM;
 if(glstate->glsl->vtx_prog||glstate->glsl->frg_prog||
    glstate->fpe_state->vertex_prg_id||glstate->fpe_state->fragment_prg_id||
    glstate->enable.vertex_arb||glstate->enable.fragment_arb||
    glstate->fpe_state->vertex_prg_enable||glstate->fpe_state->fragment_prg_enable)bad|=LEGACY_PROGRAM;
 if(glstate->list.compiling||kh_size(glstate->headlists))bad|=NAMED_LIST;
 if(glstate->raster.bm_drawing||glstate->raster.bitmap||glstate->raster.bm_texture||
    glstate->raster.data||glstate->raster.immediate.texture)bad|=RASTER;
 if(glstate->fbo.current_fb!=glstate->fbo.fbo_0||glstate->fbo.fbo_read!=glstate->fbo.fbo_0||
    glstate->fbo.fbo_draw!=glstate->fbo.fbo_0||glstate->fbo.current_rb!=glstate->fbo.default_rb||
    glstate->fbo.internal||glstate->fbo.mainfbo_fbo||glstate->fbo.mainfbo_tex||
    glstate->fbo.mainfbo_dep||glstate->fbo.mainfbo_ste)bad|=VIRTUAL_FBO;
 khint_t fb=kh_get(framebufferlist_t,glstate->fbo.framebufferlist,0);
 khint_t rb=kh_get(renderbufferlist_t,glstate->fbo.renderbufferlist,0);
 if(kh_size(glstate->fbo.framebufferlist)!=1||kh_size(glstate->fbo.renderbufferlist)!=1||
    fb==kh_end(glstate->fbo.framebufferlist)||rb==kh_end(glstate->fbo.renderbufferlist))bad|=ATTACHMENT;
 else if(kh_value(glstate->fbo.framebufferlist,fb)!=glstate->fbo.fbo_0||
         kh_value(glstate->fbo.renderbufferlist,rb)!=glstate->fbo.default_rb)bad|=ATTACHMENT;
 if(glstate->fbo.default_rb->renderbuffer||glstate->fbo.default_rb->secondarybuffer||
    glstate->fbo.default_rb->secondarytexture||glstate->fbo.fbo_0->id||
    glstate->fbo.fbo_0->depth||glstate->fbo.fbo_0->stencil||
    glstate->fbo.fbo_0->t_depth||glstate->fbo.fbo_0->t_stencil)bad|=ATTACHMENT;
 for(unsigned i=0;i<MAX_DRAW_BUFFERS;i++)
  if(glstate->fbo.fbo_0->color[i]||glstate->fbo.fbo_0->t_color[i])bad|=ATTACHMENT;
 return bad;
}
int cod_gl_v13_gl4es_read_owned(uint32_t requested,CodGLOwnedStateV12 *out) {
 if(!out || !glstate || !glstate->vao || !glstate->texture.list)return COD_GL_BACKEND;
 int units=hardext.maxtex;
 if(units<1 || units>MAX_TEX || units>COD_GL_MAX_TEXTURE_UNITS || glstate->texture.active>=(uint32_t)units || hardext.maxsize<1)return COD_GL_BACKEND;
 CodGLOwnedStateV12 state={0};state.glstate_identity=(uintptr_t)glstate;
 state.unit_count=(uint32_t)units;state.active_unit=glstate->texture.active;
 state.esversion=(uint32_t)hardext.esversion;state.max_size=(uint32_t)hardext.maxsize;
 state.in_begin=glstate->list.begin?1u:0u;state.compiling=glstate->list.compiling?1u:0u;
 state.list_active=glstate->list.active?1u:0u;state.list_pending=glstate->list.pending?1u:0u;
 state.pbo=glstate->vao->unpack?1u:0u;state.alignment=glstate->texture.unpack_align;
 state.row_length=glstate->texture.unpack_row_length;state.skip_rows=glstate->texture.unpack_skip_rows;
 state.skip_pixels=glstate->texture.unpack_skip_pixels;state.automipmap=globals4es.automipmap;
 state.forbidden_globals=(globals4es.texcopydata?1u:0u)|(globals4es.texshrink?2u:0u)|
  (globals4es.force16bits?4u:0u)|(globals4es.avoid24bits?8u:0u)|(globals4es.texstream?16u:0u)|
  (globals4es.nolumalpha?32u:0u)|(globals4es.forcenpot?64u:0u)|(globals4es.texdump?128u:0u)|(globals4es.noerror?256u:0u);
 state.forbidden_globals|=cod_gl_fresh51_forbidden_v1();
 for(uint32_t unit=0;unit<(uint32_t)units;unit++)cod_gl_v13_fact(state.units+unit,glstate->texture.bound[unit][ENABLED_TEX2D],unit);
 gltexture_t *texture=0;
 if(!requested)texture=glstate->texture.zero;
 else {khint_t k=kh_get(tex,glstate->texture.list,requested);if(k!=kh_end(glstate->texture.list))texture=kh_value(glstate->texture.list,k);}
 state.requested_exists=texture?1u:0u;
 if(texture)cod_gl_v13_fact(&state.requested,texture,state.active_unit);
 *out=state;return 0;
}
