#include "cod_gl_dispatch.h"
#include "cod_gl_compressed_stage.h"
#include "cod_gl_owned_profile.h"

#define TOKEN_BASE 0xfed40000u
typedef struct { const char *name; uint8_t argument_bytes; } Function;
static const Function functions[COD_GL_FUNCTION_COUNT]={
 {"glClear",4},{"glClearColor",16},{"glViewport",16},{"glEnable",4},{"glDisable",4},
 {"glBlendFunc",8},{"glDepthFunc",4},{"glDepthMask",4},{"glCullFace",4},{"glFrontFace",4},
 {"glMatrixMode",4},{"glLoadIdentity",0},{"glLoadMatrixf",4},{"glPushMatrix",0},{"glPopMatrix",0},
 {"glBegin",4},{"glEnd",0},{"glColor4f",16},{"glTexCoord2f",8},{"glVertex3f",12},
 {"glGenTextures",8},{"glDeleteTextures",8},{"glBindTexture",8},{"glTexParameteri",12},
 {"glGetError",0},{"glGetString",4},{"glPixelStorei",8},{"glTexImage2D",36},
 {"glEnableClientState",4},{"glDisableClientState",4},{"glVertexPointer",16},
 {"glColorPointer",16},{"glTexCoordPointer",16},{"glNormalPointer",12},{"glDrawArrays",12},
 {"glDrawElements",16},{"glGetIntegerv",8},{"glClearDepth",8},
 {"glLightModelf",8},{"glLightModelfv",8},{"glMaterialf",12},{"glMaterialfv",12},
 {"glTexEnvi",12},{"glShadeModel",4},{"glPolygonMode",8},
 {"glActiveTexture",4},{"glClientActiveTexture",4},
 {"glFogi",8},{"glHint",8},{"glFogf",8},
 {"glCompressedTexImage2D",32},{"glTexSubImage2D",36},
 {"glFinish",0},{"glScissor",16},{"glOrtho",48},{"glAlphaFunc",8},{"glNormal3f",12}
};
static uint32_t load32(const uint8_t *p) {
 return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static void store32(uint8_t *p,uint32_t v) { for(uint32_t k=0;k<4;++k)p[k]=(uint8_t)(v>>(8*k)); }
static int finite32(float value) {
 return (load32((const uint8_t *)&value)&0x7f800000u)!=0x7f800000u;
}
static int equal(const char *a,const char *b) {
 for(uint32_t k=0;k<128;++k){if(a[k]!=b[k])return 0;if(!a[k])return 1;}return 0;
}
static int span(CodGLMemory m,uint32_t a,uint32_t n,uint32_t access,uint8_t **out) {
 uint64_t end=(uint64_t)a+n;if(!a || !n || end>0x100000000ull)return COD_GL_MEMORY;
 for(uint32_t k=0;k<m.range_count;++k) {
  const CodGLRange *r=m.ranges+k;uint64_t rend=(uint64_t)r->address+r->bytes;
  if(a>=r->address && end<=rend && (r->access&access)==access) {*out=m.base+a;return 0;}
 } return COD_GL_MEMORY;
}
int cod_gl_init(CodGL *g,CodGLMemory m,CodGLInvoke invoke,CodGLReadUnpack read_unpack,CodGLReadClient read_client,void *host,CodGLAllocator allocator,uint32_t scratch,uint32_t bytes) {
 if(!g || !m.base || !m.ranges || !m.range_count || m.range_count>COD_GL_MAX_RANGES || !invoke || !read_unpack || !read_client || !allocator.allocate || !allocator.release)return COD_GL_ARGUMENT;
 for(uint32_t k=0;k<m.range_count;++k) {
  const CodGLRange *r=m.ranges+k;
  if(!r->address || !r->bytes || (uint64_t)r->address+r->bytes>0x100000000ull ||
     !r->access || (r->access&~3u))return COD_GL_MEMORY;
  for(uint32_t j=0;j<k;++j)if((uint64_t)r->address<(uint64_t)m.ranges[j].address+m.ranges[j].bytes &&
     (uint64_t)m.ranges[j].address<(uint64_t)r->address+r->bytes)return COD_GL_MEMORY;
 }
 uint8_t *p;if(bytes<4 || span(m,scratch,bytes,COD_GL_WRITE,&p))return COD_GL_MEMORY;
 g->memory=m;g->invoke=invoke;g->read_unpack=read_unpack;g->read_client=read_client;g->host_context=host;g->scratch_address=scratch;
 g->scratch_bytes=bytes;g->scratch_used=0;
 g->owned=0;g->allocator=allocator;g->failed=0;g->quarantined_bytes=0;g->quarantined_pixels=0;
 for(uint32_t k=0;k<4;++k){g->string_addresses[k]=0;g->string_capacities[k]=0;}
 atomic_init(&g->in_dispatch,0);
 return 0;
}
uint32_t cod_gl_token(const char *name) {
 if(!name)return 0;
 if(equal(name,"glCompressedTexImage2DARB"))return TOKEN_BASE+4*COD_GL_COMPRESSED_TEX_IMAGE_2D;
 if(equal(name,"glActiveTextureARB"))return TOKEN_BASE+4*COD_GL_ACTIVE_TEXTURE;
 if(equal(name,"glClientActiveTextureARB"))return TOKEN_BASE+4*COD_GL_CLIENT_ACTIVE_TEXTURE;
 for(uint32_t k=0;k<COD_GL_FUNCTION_COUNT;++k)if(equal(name,functions[k].name))return cod_gl_function_token_v13(k);
 return 0;
}
int cod_gl_lookup_guest(CodGL *g,uint32_t address,uint32_t *token) {
 if(!g || !token)return COD_GL_ARGUMENT;
 char name[128];uint8_t *p;
 for(uint32_t k=0;k<sizeof(name);++k) {
  if((uint64_t)address+k>0xffffffffu || span(g->memory,address+k,1,COD_GL_READ,&p))return COD_GL_MEMORY;
  name[k]=(char)*p;if(!name[k]){
   uint32_t found=cod_gl_token(name);
   if(((found==TOKEN_BASE+4*COD_GL_COMPRESSED_TEX_IMAGE_2D || found==COD_GL_SUBIMAGE_TOKEN_V1) && !g->owned) ||
      (found==TOKEN_BASE+4*COD_GL_GEN_TEXTURES && g->owned)){*token=0;return COD_GL_UNKNOWN;}
   *token=found;return found?0:COD_GL_UNKNOWN;
  }
 }return COD_GL_ARGUMENT;
}
static int texture_span(const CodGLUnpackState *unpack,const uint32_t *a,uint32_t *length,uint32_t *padded) {
 int32_t width=(int32_t)a[3],height=(int32_t)a[4];uint32_t components;
 if(width<0 || height<0 || a[5]!=0 || a[7]!=0x1401u)return COD_GL_ARGUMENT;
 switch(a[6]) {case 0x1906:case 0x1909:components=1;break;case 0x190a:components=2;break;
  case 0x1907:components=3;break;case 0x1908:case 0x80e1:components=4;break;default:return COD_GL_ARGUMENT;}
 if(!width || !height){*length=*padded=0;return 0;}
 uint64_t row=(uint64_t)(uint32_t)width*components;
 uint64_t alignment=unpack->alignment;
 row=(row+alignment-1)&~(alignment-1);
 if(row>0xffffffffu)return COD_GL_MEMORY;
 uint64_t preceding_rows=(uint64_t)(height-1)*row,last_row=(uint64_t)width*components;
 uint64_t total=preceding_rows+last_row,full_rows=(uint64_t)(uint32_t)height*row;
 if(total>COD_GL_MAX_STAGING_BYTES || full_rows>COD_GL_MAX_STAGING_BYTES)return COD_GL_CAPACITY;
 *length=(uint32_t)total;*padded=(uint32_t)full_rows;return 0;
}
/* Bounds are authoritative matching-layout metadata, never synthesized caps. */
static int texture_domain(const CodGLClientState *s) {
 if(!s->texture_unit_count || s->texture_unit_count>COD_GL_MAX_TEXTURE_UNITS ||
    s->texture_coordinate_base<4u || s->texture_coordinate_base>COD_GL_MAX_ATTRIBUTES ||
    s->texture_unit_count>COD_GL_MAX_ATTRIBUTES-s->texture_coordinate_base ||
    s->client_texture>=s->texture_unit_count || s->server_texture>=s->texture_unit_count)return COD_GL_BACKEND;
 return 0;
}
static int client_snapshot(CodGL *g) {
 CodGLClientState *s=&g->client;
 if(g->read_client(g->host_context,s) || texture_domain(s))return COD_GL_BACKEND;
 if(s->in_begin || s->compiling || s->array_buffer_bound || s->element_buffer_bound || s->locked ||
    !s->attribute_count || s->attribute_count>COD_GL_MAX_ATTRIBUTES)return COD_GL_ARGUMENT;
 return 0;
}
static int array_shape(uint32_t kind,uint32_t size,uint32_t type,uint32_t stride,uint32_t *element) {
 uint32_t unit;
 if(type==0x1406u)unit=4; /* binary32, bit-preserving guest/native little endian */
 else if(type==0x1401u && kind==COD_GL_ARRAY_COLOR)unit=1;
 else return COD_GL_ARGUMENT;
 if(kind==COD_GL_ARRAY_VERTEX) {if(size<2 || size>4 || unit!=4)return COD_GL_ARGUMENT;}
 else if(kind==COD_GL_ARRAY_NORMAL) {if(size!=3 || unit!=4)return COD_GL_ARGUMENT;}
 else if(kind==COD_GL_ARRAY_COLOR) {if(size!=4)return COD_GL_ARGUMENT;}
 else if(kind>=COD_GL_ARRAY_TEXCOORD0 && kind<COD_GL_ARRAY_TEXCOORD0+COD_GL_MAX_TEXTURE_UNITS) {if(!size || size>4 || unit!=4)return COD_GL_ARGUMENT;}
 else return COD_GL_ARGUMENT;
 if(stride>1048576u || stride%unit)return COD_GL_ARGUMENT;
 *element=size*unit;return 0;
}
static int arrays_draw_span(CodGL *g,uint32_t first,uint32_t count) {
 CodGLClientState *s=&g->client;
 if(first>32768u || count>32768u || (uint64_t)first+count>32768u)return COD_GL_CAPACITY;
 if(!count)return 0;
 uint32_t seen=0;
 for(uint32_t k=0;k<s->attribute_count;++k) {
  CodGLArray *a=s->attributes+k;if(!a->enabled)continue;
  if(a->kind<1 || a->kind>=COD_GL_ARRAY_TEXCOORD0+s->texture_unit_count || (seen&(1u<<a->kind)) || a->buffer_bound || a->divisor)return COD_GL_ARGUMENT;
  seen|=1u<<a->kind;
  uint32_t element;int status=array_shape(a->kind,a->size,a->type,a->stride,&element);if(status)return status;
  uintptr_t base=(uintptr_t)g->memory.base;
  if(a->pointer<base || (uint64_t)(a->pointer-base)>0xffffffffu)return COD_GL_MEMORY;
  uint32_t address=(uint32_t)(a->pointer-base),unit=a->type==0x1401u?1u:4u;
  if(!address || address%unit)return COD_GL_MEMORY;
  uint64_t stride=a->stride?a->stride:element;
  /* GL4ES can copy a prefix through first+count; validate the whole prefix,
   * not merely the nominal first element. No borrowed host pointer passes. */
  uint64_t length=((uint64_t)first+count-1)*stride+element;
  /* The pinned CPU helpers read element bytes, but the direct native GLES
   * handoff is also admitted. Conservatively require the complete final
   * record there until a separate native-driver guard test narrows it. */
  uint64_t full_records=((uint64_t)first+count)*stride;if(full_records>length)length=full_records;
  if(length>0x7fffffffu)return COD_GL_MEMORY;
  uint8_t *p;if(span(g->memory,address,(uint32_t)length,COD_GL_READ,&p))return COD_GL_MEMORY;
  if((uintptr_t)p!=a->pointer || (uintptr_t)p%unit)return COD_GL_MEMORY;
 }
 return (seen&(1u<<COD_GL_ARRAY_VERTEX))?0:COD_GL_ARGUMENT;
}
static int dispatch_owned(CodGL *g,uint32_t token,uint8_t *regs,uint32_t reg_bytes) {
 if(!g || !regs || reg_bytes<20 || token<TOKEN_BASE || (token-TOKEN_BASE)%4)return COD_GL_UNKNOWN;
 if(g->failed)return COD_GL_BACKEND;
 uint32_t f;
 if(cod_gl_token_function_v13(token,&f))return COD_GL_UNKNOWN;
 uint32_t sp=load32(regs+16),argc=functions[f].argument_bytes/4;uint8_t *stack;
 if((uint64_t)sp+4+functions[f].argument_bytes>0xffffffffu ||
    span(g->memory,sp,4+functions[f].argument_bytes,COD_GL_READ,&stack))return COD_GL_MEMORY;
 CodGLNativeCall *call=&g->packet;CodGLNativeResult result={0};call->function=(enum CodGLFunction)f;call->pixels=0;call->owned_profile_kind=0;call->owned_profile_tail=0;call->owned_unpack_alignment=0;
 for(uint32_t k=0;k<argc;++k)call->words[k]=load32(stack+4+4*k);
 uint8_t *names_out=0,*integer_out=0;uint32_t string_index=4;
 void *owned_pixels=0;uint32_t owned_bytes=0;
 if(f==COD_GL_NORMAL_3F) {
  /* Native scalar normal state, including legal immediate-mode use. */
  for(uint32_t k=0;k<3;k++)if((call->words[k]&0x7f800000u)==0x7f800000u)return COD_GL_ARGUMENT;
 }
 if(f>=COD_GL_FINISH && f<=COD_GL_ALPHA_FUNC) {
  /* Read authoritative state before conversion or backend mutation. GL4ES
   * retains completed Begin/End batches as active+pending; each selected
   * wrapper drains that state itself when necessary. Named-list recording
   * (active without pending), an unfinished Begin, and compiling stay closed. */
  if(g->read_client(g->host_context,&g->client))return COD_GL_BACKEND;
  if(g->client.in_begin || g->client.compiling ||
     g->client.list_active!=g->client.list_pending)return COD_GL_ARGUMENT;
  if(f==COD_GL_SCISSOR) {
   if((int32_t)call->words[2]<0 || (int32_t)call->words[3]<0)return COD_GL_ARGUMENT;
  }else if(f==COD_GL_ALPHA_FUNC) {
   if(call->words[0]<0x200u || call->words[0]>0x207u ||
      (call->words[1]&0x7f800000u)==0x7f800000u)return COD_GL_ARGUMENT;
  }else if(f==COD_GL_ORTHO) {
   _Static_assert(sizeof(double)==8,"glOrtho requires binary64 storage");
   for(uint32_t k=0;k<6u;k++) {
    uint64_t bits=(uint64_t)call->words[2u*k]|((uint64_t)call->words[2u*k+1u]<<32);
    /* The pinned GL4ES implementation converts to native float. Do not admit
     * NaN/infinity or overflowing scalar conversions at this boundary. */
    if((bits&UINT64_C(0x7fffffffffffffff))>UINT64_C(0x47efffffe0000000))return COD_GL_ARGUMENT;
    for(uint32_t b=0;b<8u;b++)((uint8_t *)&call->ortho[k])[b]=(uint8_t)(bits>>(8u*b));
   }
   if((float)call->ortho[0]==(float)call->ortho[1] ||
      (float)call->ortho[2]==(float)call->ortho[3] ||
      (float)call->ortho[4]==(float)call->ortho[5])return COD_GL_ARGUMENT;
   for(uint32_t k=0;k<3;k++) {
    float low=(float)call->ortho[2*k],high=(float)call->ortho[2*k+1];
    float delta=high-low,sum=high+low;
    if(!finite32(delta)||!finite32(sum)||!finite32(2.0f/delta)||!finite32(-sum/delta))return COD_GL_ARGUMENT;
   }
  }
 }else if(f>=COD_GL_ENABLE_CLIENT_STATE && f<=COD_GL_DRAW_ELEMENTS) {
  int status=client_snapshot(g);if(status)return status;
  uint32_t *a=call->words;
  if(f==COD_GL_ENABLE_CLIENT_STATE || f==COD_GL_DISABLE_CLIENT_STATE) {
   /* Enum-only calls retain actual backend validation/error semantics. Every
    * enabled unknown attribute is still rejected at the later draw boundary. */
  }else if(f==COD_GL_DRAW_ELEMENTS) {
   /* This source-supported first slice admits triangles with USHORT indices.
    * Decode bytewise: a guest pointer need not have native alignment. Mapping
    * and contents must remain stable for this entire synchronous dispatch. */
   if(a[0]!=4u || (int32_t)a[1]<0 || a[2]!=0x1403u)return COD_GL_ARGUMENT;
   if(a[1]>32768u)return COD_GL_CAPACITY;
   if(a[1]) {
    uint32_t length=2u*a[1],maximum=0;uint8_t *indices;
    if(span(g->memory,a[3],length,COD_GL_READ,&indices))return COD_GL_MEMORY;
    for(uint32_t k=0;k<a[1];++k) {
     uint32_t index=(uint32_t)indices[2*k]|((uint32_t)indices[2*k+1]<<8);
     if(index>32767u)return COD_GL_CAPACITY;
     if(index>maximum)maximum=index;
    }
    status=arrays_draw_span(g,0,maximum+1u);if(status)return status;
    uint32_t padded=(length+COD_GL_STAGING_ALIGNMENT-1u)&~(COD_GL_STAGING_ALIGNMENT-1u);
    owned_pixels=g->allocator.allocate(g->allocator.context,padded,COD_GL_STAGING_ALIGNMENT);
    if(!owned_pixels)return COD_GL_CAPACITY;
    if((uintptr_t)owned_pixels%COD_GL_STAGING_ALIGNMENT || (uintptr_t)owned_pixels>UINTPTR_MAX-padded) {
     g->allocator.release(g->allocator.context,owned_pixels);return COD_GL_BACKEND;
    }
    for(uint32_t k=0;k<padded;++k)((volatile uint8_t *)owned_pixels)[k]=0;
    for(uint32_t k=0;k<length;++k)((uint8_t *)owned_pixels)[k]=indices[k];
    owned_bytes=padded;call->pixels=owned_pixels;
   }
  }else if(f==COD_GL_DRAW_ARRAYS) {
   if(a[0]>9u || (int32_t)a[1]<0 || (int32_t)a[2]<0)return COD_GL_ARGUMENT;
   if(a[0]==8u && a[2]>32000u)return COD_GL_CAPACITY;
   status=arrays_draw_span(g,a[1],a[2]);if(status)return status;
  }else {
   uint32_t kind=f==COD_GL_VERTEX_POINTER?COD_GL_ARRAY_VERTEX:f==COD_GL_NORMAL_POINTER?COD_GL_ARRAY_NORMAL:
                 f==COD_GL_COLOR_POINTER?COD_GL_ARRAY_COLOR:COD_GL_ARRAY_TEXCOORD0+g->client.client_texture;
   uint32_t size=f==COD_GL_NORMAL_POINTER?3u:a[0],type=f==COD_GL_NORMAL_POINTER?a[0]:a[1];
   uint32_t stride=f==COD_GL_NORMAL_POINTER?a[1]:a[2],address=f==COD_GL_NORMAL_POINTER?a[2]:a[3];
   uint32_t element;status=array_shape(kind,size,type,stride,&element);if(status)return status;
   if(address) {
    uint32_t unit=type==0x1401u?1u:4u;if(address%unit)return COD_GL_MEMORY;
    uint8_t *p;if(span(g->memory,address,element,COD_GL_READ,&p) || (uintptr_t)p%unit)return COD_GL_MEMORY;call->pixels=p;
   }
  }
 }else if(f==COD_GL_FOG_I || f==COD_GL_HINT || f==COD_GL_FOG_F) {
  const uint32_t *a=call->words;
  /* Exact finite scalar startup values; vector/color/other setters stay closed. */
  if(f==COD_GL_FOG_I && (a[0]!=0x0b65u || a[1]!=0x0800u))return COD_GL_ARGUMENT;
  if(f==COD_GL_HINT && (a[0]!=0x0c54u || a[1]!=0x1100u))return COD_GL_ARGUMENT;
  if(f==COD_GL_FOG_F && ((a[0]!=0x0b62u || a[1]!=0x3f800000u) &&
     (a[0]!=0x0b63u || a[1]!=0x00000000u) && (a[0]!=0x0b64u || a[1]!=0x3f800000u)))return COD_GL_ARGUMENT;
  /* Actual matching backend state: never record/flush a live or pending list. */
  if(g->read_client(g->host_context,&g->client))return COD_GL_BACKEND;
  if(g->client.in_begin || g->client.compiling || g->client.list_active || g->client.list_pending)return COD_GL_ARGUMENT;
 }else if(f==COD_GL_ACTIVE_TEXTURE || f==COD_GL_CLIENT_ACTIVE_TEXTURE) {
  if(g->read_client(g->host_context,&g->client) || texture_domain(&g->client))return COD_GL_BACKEND;
  if(g->client.in_begin || g->client.compiling || g->client.list_active || g->client.list_pending)return COD_GL_ARGUMENT;
  if(call->words[0]<0x84c0u || call->words[0]-0x84c0u>=g->client.texture_unit_count)return COD_GL_ARGUMENT;
 }else if(f>=COD_GL_TEX_ENV_I && f<=COD_GL_POLYGON_MODE) {
  const uint32_t *a=call->words;
  /* Exact first source-default tuples, not generic fixed-function setters. */
  if(f==COD_GL_TEX_ENV_I) {
   if(a[0]!=0x2300u || a[1]!=0x2200u || a[2]!=0x2100u)return COD_GL_ARGUMENT;
  }else if(f==COD_GL_SHADE_MODEL) {
   if(a[0]!=0x1d01u)return COD_GL_ARGUMENT;
  }else if(a[0]!=0x0408u || a[1]!=0x1b02u)return COD_GL_ARGUMENT;
  if(g->read_client(g->host_context,&g->client))return COD_GL_BACKEND;
  if(g->client.in_begin || g->client.compiling || g->client.list_active || g->client.list_pending)return COD_GL_ARGUMENT;
  /* The server selector controls texenv; client array metadata cannot stand
   * in for it. Other two setters do not depend on either texture selector. */
  if(f==COD_GL_TEX_ENV_I && texture_domain(&g->client))return COD_GL_BACKEND;
 }else if(f>=COD_GL_LIGHT_MODEL_F && f<=COD_GL_MATERIAL_FV) {
  uint32_t *a=call->words;uint32_t vector=(f==COD_GL_LIGHT_MODEL_FV || f==COD_GL_MATERIAL_FV);
  if(f==COD_GL_LIGHT_MODEL_F) {
   if(a[0]!=0x0b51u && a[0]!=0x0b52u)return COD_GL_ARGUMENT;
   if(a[1]!=0 && a[1]!=0x80000000u && a[1]!=0x3f800000u)return COD_GL_ARGUMENT;
  }else if(f==COD_GL_LIGHT_MODEL_FV) {
   if(a[0]!=0x0b53u)return COD_GL_ARGUMENT;
  }else if(f==COD_GL_MATERIAL_F) {
   if(a[0]!=0x0404u || a[1]!=0x1601u || (a[2]>0x43000000u && a[2]!=0x80000000u))return COD_GL_ARGUMENT;
  }else {
   if(a[0]!=0x0404u || (a[1]!=0x1602u && a[1]!=0x1202u && a[1]!=0x1600u))return COD_GL_ARGUMENT;
  }
  /* Authoritative matching-backend metadata, with no GL query, flush or
   * requested-setter shadow. No guest vector is read while a list is live. */
  if(g->read_client(g->host_context,&g->client))return COD_GL_BACKEND;
  if(g->client.in_begin || g->client.compiling || g->client.list_active || g->client.list_pending)return COD_GL_ARGUMENT;
  if(vector) {
   uint8_t *v;uint32_t address=a[f==COD_GL_LIGHT_MODEL_FV?1:2];
   if(span(g->memory,address,16,COD_GL_READ,&v))return COD_GL_MEMORY;
   for(uint32_t k=0;k<16;++k)((uint8_t *)call->fixed_vector)[k]=v[k];
   for(uint32_t k=0;k<4;++k) {
    uint32_t bits=load32((const uint8_t *)call->fixed_vector+4*k);
    if(bits>0x3f800000u && bits!=0x80000000u)return COD_GL_ARGUMENT;
   }
  }
 }else if(f==COD_GL_CLEAR_DEPTH) {
  _Static_assert(sizeof(double)==8,"ClearDepth requires native binary64 storage");
  uint64_t bits=(uint64_t)call->words[0]|((uint64_t)call->words[1]<<32);
  /* Explicit first-slice domain: finite0..1 plus negative zero. Classify bits
   * without evaluating a signaling NaN or an out-of-range double->float cast.
   * The actual pinned GL4ES wrapper converts the admitted native double to
   * its real GLES float clear depth. This is not double GPU precision. */
  if(bits>0x3ff0000000000000ull && bits!=0x8000000000000000ull)return COD_GL_ARGUMENT;
  for(uint32_t k=0;k<8;++k)((uint8_t *)&call->clear_depth)[k]=(uint8_t)(bits>>(8*k));
 }else if(f==COD_GL_GET_INTEGER_V) {
  /* Arity is pname-specific: three scalar capability queries only.
   * The unit query additionally binds its actual return to typed metadata. */
  if(call->words[0]!=0x0d33u && call->words[0]!=0x0d31u && call->words[0]!=0x84e2u)return COD_GL_ARGUMENT;
  if(call->words[0]==0x84e2u) {
   if(g->read_client(g->host_context,&g->client) || texture_domain(&g->client))return COD_GL_BACKEND;
   if(g->client.in_begin || g->client.compiling || g->client.list_active || g->client.list_pending)return COD_GL_ARGUMENT;
  }
  if(span(g->memory,call->words[1],4,COD_GL_READ|COD_GL_WRITE,&integer_out))return COD_GL_MEMORY;
  /* A native GL error may leave output untouched. Seed actual caller bytes,
   * including unaligned guest output, instead of copying stale packet data. */
  for(uint32_t k=0;k<4;++k)((uint8_t *)&call->query_integer)[k]=integer_out[k];
 }else if(f==COD_GL_LOAD_MATRIX_F) {
  uint8_t *matrix;if(span(g->memory,call->words[0],64,COD_GL_READ,&matrix))return COD_GL_MEMORY;
  /* byte-copy into aligned native floats, preserving binary32 payloads. */
  for(uint32_t k=0;k<64;++k)((uint8_t *)call->matrix)[k]=matrix[k];
 }else if(f==COD_GL_GEN_TEXTURES || f==COD_GL_DELETE_TEXTURES) {
  int32_t n=(int32_t)call->words[0];if(n<0 || n>COD_GL_MAX_NAMES)return COD_GL_CAPACITY;
  if(n) {
   uint8_t *names;if(span(g->memory,call->words[1],4*(uint32_t)n,
      f==COD_GL_GEN_TEXTURES?(COD_GL_READ|COD_GL_WRITE):COD_GL_READ,&names))return COD_GL_MEMORY;
   if(f==COD_GL_GEN_TEXTURES)names_out=names;
   /* Preserve output preimage: GL errors may leave all or some names
    * unwritten. Unconditional copyback must then retain those guest bytes. */
   for(uint32_t k=0;k<(uint32_t)n;++k)call->names[k]=load32(names+4*k);
  }
 }else if(f==COD_GL_PIXEL_STORE_I) {
  int32_t value=(int32_t)call->words[1];
  if(call->words[0]==0x0cf5u) {if(value!=1 && value!=2 && value!=4 && value!=8)return COD_GL_ARGUMENT;}
  else if(call->words[0]==0x0cf2u || call->words[0]==0x0cf3u || call->words[0]==0x0cf4u) {
   if(value<0)return COD_GL_ARGUMENT;
  }else return COD_GL_ARGUMENT;
 }else if(f==COD_GL_COMPRESSED_TEX_IMAGE_2D) {
   if(!g->owned)return COD_GL_ARGUMENT;
   CodGLUnpackState unpack;if(g->read_unpack(g->host_context,&unpack))return COD_GL_BACKEND;
   if(unpack.in_begin || unpack.compiling || unpack.unpack_buffer_bound || unpack.texture_options || unpack.row_length || unpack.skip_rows || unpack.skip_pixels)return COD_GL_ARGUMENT;
   CodGLCompressedStageV12 stage;int status=cod_gl_v13_prepare_compressed(g->memory,g->allocator,regs,reg_bytes,unpack.alignment,&stage);if(status)return status;
   owned_pixels=stage.pixels;owned_bytes=stage.owned_bytes;call->pixels=stage.pixels;call->owned_unpack_alignment=unpack.alignment;
   /* Preserve the original compressed arguments; executor selects decoded native format. */
 }else if(f==COD_GL_TEX_SUB_IMAGE_2D) {
  const uint32_t *a=call->words;
  if(!g->owned || a[0]!=0x0de1u || a[1] || a[2] || a[3] || !cod_gl_cinematic_shape_v13(a[4],a[5]) ||
     a[6]!=0x1908u || a[7]!=0x1401u || !a[8])return COD_GL_ARGUMENT;
  CodGLUnpackState unpack;
  if(g->read_unpack(g->host_context,&unpack))return COD_GL_BACKEND;
  if(unpack.in_begin || unpack.compiling || unpack.unpack_buffer_bound || unpack.texture_options ||
     unpack.row_length || unpack.skip_rows || unpack.skip_pixels ||
     (unpack.alignment!=1 && unpack.alignment!=2 && unpack.alignment!=4 && unpack.alignment!=8))return COD_GL_ARGUMENT;
  /* Both admitted RGBA row widths divide every admitted alignment. */
  const uint32_t bytes=a[4]*a[5]*4u;uint8_t *pixels;
  if(span(g->memory,a[8],bytes,COD_GL_READ,&pixels))return COD_GL_MEMORY;
  owned_pixels=g->allocator.allocate(g->allocator.context,bytes,COD_GL_STAGING_ALIGNMENT);
  if(!owned_pixels)return COD_GL_CAPACITY;
  if((uintptr_t)owned_pixels%COD_GL_STAGING_ALIGNMENT || (uintptr_t)owned_pixels>UINTPTR_MAX-bytes){
   g->allocator.release(g->allocator.context,owned_pixels);return COD_GL_BACKEND;
  }
  for(uint32_t k=0;k<bytes;k++)((uint8_t*)owned_pixels)[k]=pixels[k];
  owned_bytes=bytes;call->pixels=owned_pixels;call->owned_unpack_alignment=unpack.alignment;
 }else if(f==COD_GL_TEX_IMAGE_2D) {
  CodGLUnpackState unpack;
  if(g->read_unpack(g->host_context,&unpack))return COD_GL_BACKEND;
  if(unpack.in_begin || unpack.compiling || unpack.unpack_buffer_bound || unpack.texture_options || (!g->owned && unpack.texture_object_options))return COD_GL_ARGUMENT;
  if(unpack.alignment!=1 && unpack.alignment!=2 && unpack.alignment!=4 && unpack.alignment!=8)return COD_GL_ARGUMENT;
  if(g->owned)call->owned_unpack_alignment=unpack.alignment;
   /* glstate fields are GLuint; reject wrapped negatives and bounds whose
   * later upstream signed arithmetic is not admitted by this first slice. */
  /* Pinned GL4ES repacks nonzero row/skip into a separate tight allocation;
   * that allocation's later aligned reads are not proved by guest staging.
   * Reject this state until a separately audited repack path exists. */
  if(unpack.row_length || unpack.skip_rows || unpack.skip_pixels)return COD_GL_ARGUMENT;
  if(call->words[0]!=0x0de1u || (g->owned?call->words[1]>13u:call->words[1]!=0) || call->words[3]>8192 || call->words[4]>8192 || call->words[5])return COD_GL_ARGUMENT;
  if((call->words[3] && (call->words[3]&(call->words[3]-1))) || (call->words[4] && (call->words[4]&(call->words[4]-1))))return COD_GL_ARGUMENT;
  uint32_t internal=call->words[2],external=call->words[6];
  if(internal==3)internal=0x1907u;else if(internal==4)internal=0x1908u;
  /* Original 4CD293 tuple: retain internal RGB and every RGBA input byte.
   * Admission is exact and owned; no format rewrite or alpha fiction. */
  uint32_t cinematic_rgb=g->owned && call->words[2]==3u && external==0x1908u &&
      call->words[1]==0 && cod_gl_cinematic_shape_v13(call->words[3],call->words[4]) && call->words[8];
  /* Keep the observed desktop GL_RGBA4 and GL_RGB5 requests and RGBA8 source spans.
   * Pack into checked owned storage before GL4ES can allocate for conversion. */
  uint32_t packed16=g->owned && (internal==0x8056u || internal==0x8050u) &&
      external==0x1908u && call->words[8];
  /* The screen texture selects explicit GL_RGB on an 8/8/8 drawable. */
  uint32_t opaque_rgb=g->owned && call->words[2]==0x1907u && external==0x1908u && call->words[8];
  if((internal!=external && !cinematic_rgb && !packed16 && !opaque_rgb) ||
      call->words[7]!=0x1401u)return COD_GL_ARGUMENT;
  if(internal!=0x1907u && internal!=0x1908u && !packed16)return COD_GL_ARGUMENT;
  if(call->words[8]) {
   uint32_t length,padded;int status=texture_span(&unpack,call->words,&length,&padded);if(status)return status;
   if(length) {
    uint8_t *pixels;if(span(g->memory,call->words[8],length,COD_GL_READ,&pixels))return COD_GL_MEMORY;
    uint32_t source_stride=0,packed_stride=0;
    if(packed16 || opaque_rgb) {
     uint32_t mask=unpack.alignment-1u;
     source_stride=(call->words[3]*4u+mask)&~mask;
     uint32_t destination_components=opaque_rgb?3u:2u;
     packed_stride=(call->words[3]*destination_components+mask)&~mask;
     padded=packed_stride*call->words[4];
    }
    owned_pixels=g->allocator.allocate(g->allocator.context,padded,COD_GL_STAGING_ALIGNMENT);
    if(!owned_pixels)return COD_GL_CAPACITY;
    if((uintptr_t)owned_pixels%COD_GL_STAGING_ALIGNMENT || (uintptr_t)owned_pixels>UINTPTR_MAX-padded) {
     g->allocator.release(g->allocator.context,owned_pixels);return COD_GL_BACKEND;
    }
    /* Only proven guest bytes are read. The native allocation supplies final
     * padding and a naturally aligned source for pinned pixel_convert paths. */
    for(uint32_t k=0;k<padded;++k)((volatile uint8_t *)owned_pixels)[k]=0;
    if(opaque_rgb) {
     for(uint32_t y=0;y<call->words[4];++y) {
      const uint8_t *src=pixels+y*source_stride;
      uint8_t *dst=(uint8_t *)owned_pixels+y*packed_stride;
      for(uint32_t x=0;x<call->words[3];++x) {
       dst[3u*x]=src[4u*x];
       dst[3u*x+1u]=src[4u*x+1u];
       dst[3u*x+2u]=src[4u*x+2u];
      }
     }
    }else if(packed16) {
     for(uint32_t y=0;y<call->words[4];++y) {
      const uint8_t *src=pixels+y*source_stride;
      uint8_t *dst=(uint8_t *)owned_pixels+y*packed_stride;
      for(uint32_t x=0;x<call->words[3];++x) {
       const uint8_t *rgba=src+4u*x;
       uint32_t packed;
       if(internal==0x8050u)
        packed=((rgba[0]&0xf8u)<<8)|((rgba[1]&0xfcu)<<3)|(rgba[2]>>3);
       else
        packed=((rgba[0]&0xf0u)<<8)|((rgba[1]&0xf0u)<<4)|(rgba[2]&0xf0u)|(rgba[3]>>4);
       dst[2u*x]=(uint8_t)packed;
       dst[2u*x+1u]=(uint8_t)(packed>>8);
      }
     }
    }else{
     for(uint32_t k=0;k<length;++k)((uint8_t *)owned_pixels)[k]=pixels[k];
    }
    owned_bytes=padded;call->pixels=owned_pixels;
   }
  }
 }else if(f==COD_GL_GET_STRING) {
  if(call->words[0]>=0x1f00u && call->words[0]<=0x1f03u) {
   string_index=call->words[0]-0x1f00u;
  }
 }
 if(g->owned){int status=cod_gl_owned_v13_before(g,call);if(status){if(owned_pixels)g->allocator.release(g->allocator.context,owned_pixels);call->pixels=0;return status;}}
 /* The retained worker was compiled with function-count51. Use an explicit
  * host-only variant of its existing texture packet, preserving its original
  * native glFinish path and current-context/admission checks. */
 if(f==COD_GL_TEX_SUB_IMAGE_2D)call->function=COD_GL_TEX_IMAGE_2D;
 /* invoke is synchronous and must enforce one engine owner + live worker
  * context. Native GL error state is not consumed or converted to success. */
 /* A callback that never writes the effect starts uncertain, not safely free. */
 if(owned_pixels)result.pixel_effect=COD_GL_PIXELS_UNCERTAIN_V12;
 int invoke_status=g->invoke(g->host_context,call,&result);
 if(invoke_status || (owned_pixels && result.pixel_effect!=COD_GL_PIXELS_COMPLETED_V12)) {
  g->failed=1;
  if(owned_pixels){
   if(result.pixel_effect==COD_GL_PIXELS_NOT_CONSUMED_V12 || result.pixel_effect==COD_GL_PIXELS_COMPLETED_V12)
    g->allocator.release(g->allocator.context,owned_pixels);
   else {g->quarantined_pixels=owned_pixels;g->quarantined_bytes=owned_bytes;}
   call->pixels=0;
  }
  return COD_GL_BACKEND;
 }
 /* V8 production invoke confirms real native GLES completion of staged
  * uploads before success. An uncertain failure above retains the allocation. */
 if(owned_pixels){g->allocator.release(g->allocator.context,owned_pixels);call->pixels=0;}
 if(g->owned && cod_gl_owned_v13_after(g,call)){g->failed=1;return COD_GL_BACKEND;}
 /* Never substitute a cap or copy back a contradictory unit count. */
 if(f==COD_GL_GET_INTEGER_V && call->words[0]==0x84e2u && call->query_integer!=(int32_t)g->client.texture_unit_count) {
  g->failed=1;return COD_GL_BACKEND;
 }
 if(integer_out)for(uint32_t k=0;k<4;++k)integer_out[k]=((const uint8_t *)&call->query_integer)[k];
 if(names_out)for(uint32_t k=0;k<call->words[0];++k)store32(names_out+4*k,call->names[k]);
 if(f==COD_GL_GET_STRING) {
  uint32_t address=0;
  if(result.string) {
   if(string_index==4)return COD_GL_ARGUMENT;
   uint32_t n=0;while(n<65536 && result.string[n])++n;
   if(n==65536)return COD_GL_CAPACITY;
   if(g->string_capacities[string_index]>=n+1)address=g->string_addresses[string_index];
   else {
    if(n+1>g->scratch_bytes-g->scratch_used)return COD_GL_CAPACITY;
    address=g->scratch_address+g->scratch_used;g->scratch_used+=n+1;
    g->string_addresses[string_index]=address;g->string_capacities[string_index]=n+1;
   }
   uint8_t *out;
   if(span(g->memory,address,n+1,COD_GL_WRITE,&out))return COD_GL_MEMORY;
   for(uint32_t k=0;k<=n;++k)out[k]=result.string[k];
  }store32(regs,address);
 }else if(f==COD_GL_GET_ERROR)store32(regs,result.word);
 store32(regs+16,sp+4+functions[f].argument_bytes);return 0;
}
int cod_gl_dispatch(CodGL *g,uint32_t token,uint8_t *regs,uint32_t reg_bytes) {
 if(!g)return COD_GL_ARGUMENT;
 uint32_t expected=0;
 if(!atomic_compare_exchange_strong(&g->in_dispatch,&expected,1))return COD_GL_BACKEND;
 int status=dispatch_owned(g,token,regs,reg_bytes);
 atomic_store(&g->in_dispatch,0);return status;
}
