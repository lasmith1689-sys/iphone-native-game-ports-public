#include "cod_gl_compressed_stage.h"
#include "../compressed-dxt-v1/ngp_dxt_v1.h"

static uint32_t load32(const uint8_t*p){return(uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static int extent(const void*p,uint32_t n){return p && n && (uintptr_t)p<=UINTPTR_MAX-(n-1u);}
static int overlaps(const void*a,uint32_t an,const void*b,uint32_t bn){
 return (uintptr_t)a<=(uintptr_t)b+bn-1u && (uintptr_t)b<=(uintptr_t)a+an-1u;
}
static int map(CodGLMemory m,uint32_t a,uint32_t n,const uint8_t**out){
 uint64_t end=(uint64_t)a+n;if(!a||!n||end>0x100000000ull)return COD_GL_MEMORY;
 if((uint64_t)(uintptr_t)m.base>UINTPTR_MAX-(end-1u))return COD_GL_MEMORY;
 for(uint32_t k=0;k<m.range_count;k++){
  const CodGLRange*r=m.ranges+k;
  if(a>=r->address && end<=(uint64_t)r->address+r->bytes && (r->access&COD_GL_READ)){
   *out=m.base+a;return 0;
  }
 }
 return COD_GL_MEMORY;
}
static int borrowed_overlap(void*p,uint32_t n,const uint8_t*r,uint32_t rn,
 const void*out,const uint8_t*stack,const uint8_t*source,uint32_t sn){
 return overlaps(p,n,r,rn)||overlaps(p,n,out,sizeof(CodGLCompressedStageV12))||
   overlaps(p,n,stack,36)||overlaps(p,n,source,sn);
}

int cod_gl_v13_prepare_compressed(CodGLMemory m,CodGLAllocator allocator,
 const uint8_t*registers,uint32_t register_bytes,uint32_t alignment,CodGLCompressedStageV12*out){
 if(!m.base||!m.ranges||!m.range_count||m.range_count>COD_GL_MAX_RANGES||
    !allocator.allocate||!allocator.release||register_bytes<20||register_bytes>4096||
    !extent(registers,register_bytes)||!extent(out,sizeof(*out)))return COD_GL_ARGUMENT;
 if(alignment!=1&&alignment!=2&&alignment!=4&&alignment!=8)return COD_GL_ARGUMENT;
 if(overlaps(registers,register_bytes,out,sizeof(*out)))return COD_GL_MEMORY;
 for(uint32_t k=0;k<m.range_count;k++){
  const CodGLRange*r=m.ranges+k;
  if(!r->address||!r->bytes||(uint64_t)r->address+r->bytes>0x100000000ull||
     !r->access||(r->access&~3u))return COD_GL_MEMORY;
  for(uint32_t j=0;j<k;j++)if((uint64_t)r->address<(uint64_t)m.ranges[j].address+m.ranges[j].bytes &&
    (uint64_t)m.ranges[j].address<(uint64_t)r->address+r->bytes)return COD_GL_MEMORY;
 }
 uint32_t sp=load32(registers+16);const uint8_t*stack;
 if((uint64_t)sp+36>0xffffffffu||map(m,sp,36,&stack))return COD_GL_MEMORY;
 CodGLCompressedStageV12 stage;
 for(uint32_t k=0;k<8;k++)stage.words[k]=load32(stack+4+4*k);
 const uint32_t*a=stage.words;uint32_t w=a[3],h=a[4],fmt=a[2];
 if(a[0]!=0xde1u||a[1]>13u||fmt<0x83f0u||fmt>0x83f3u||!w||!h||w>8192||h>8192||
    (w&(w-1u))||(h&(h-1u))||a[5])return COD_GL_ARGUMENT;
 uint64_t source_bytes=((uint64_t)(w+3u)/4u)*((h+3u)/4u)*(fmt<=0x83f1u?8u:16u);
 uint64_t tight=(uint64_t)w*h*4u;
 uint32_t components=fmt==0x83f0u?3u:4u;
 uint64_t row=(uint64_t)w*components,stride=(row+alignment-1u)&~((uint64_t)alignment-1u);
 uint64_t readable=(h-1u)*stride+row,full=(uint64_t)h*stride;
 if(source_bytes>COD_GL_MAX_STAGING_BYTES||tight>COD_GL_MAX_STAGING_BYTES||
    full>COD_GL_MAX_STAGING_BYTES||readable>COD_GL_MAX_STAGING_BYTES)return COD_GL_CAPACITY;
 if(a[6]!=source_bytes)return COD_GL_ARGUMENT;
 const uint8_t*source;if(map(m,a[7],(uint32_t)source_bytes,&source))return COD_GL_MEMORY;
 if(overlaps(out,sizeof(*out),source,(uint32_t)source_bytes)||overlaps(out,sizeof(*out),stack,36))return COD_GL_MEMORY;
 void*scratch=allocator.allocate(allocator.context,(uint32_t)tight,COD_GL_STAGING_ALIGNMENT);
 if(!scratch)return COD_GL_CAPACITY;
 if(!extent(scratch,(uint32_t)tight))return COD_GL_MEMORY;
 /* A pointer into a live borrowed object is not reclaimed as an allocation.
  * Such allocator outputs violate the explicit fresh-allocation contract. */
 if(borrowed_overlap(scratch,(uint32_t)tight,registers,register_bytes,out,stack,source,(uint32_t)source_bytes))return COD_GL_MEMORY;
 if((uintptr_t)scratch%COD_GL_STAGING_ALIGNMENT){allocator.release(allocator.context,scratch);return COD_GL_MEMORY;}
 int decoded=ngp_dxt_v1_decode(source,(size_t)source_bytes,w,h,fmt,scratch,(size_t)tight);
 if(decoded){allocator.release(allocator.context,scratch);return COD_GL_ARGUMENT;}
 void*packed=allocator.allocate(allocator.context,(uint32_t)full,COD_GL_STAGING_ALIGNMENT);
 if(!packed){allocator.release(allocator.context,scratch);return COD_GL_CAPACITY;}
 if(!extent(packed,(uint32_t)full)||overlaps(packed,(uint32_t)full,scratch,(uint32_t)tight)||
    borrowed_overlap(packed,(uint32_t)full,registers,register_bytes,out,stack,source,(uint32_t)source_bytes)){
  allocator.release(allocator.context,scratch);return COD_GL_MEMORY;
 }
 if((uintptr_t)packed%COD_GL_STAGING_ALIGNMENT){allocator.release(allocator.context,packed);allocator.release(allocator.context,scratch);return COD_GL_MEMORY;}
 uint8_t*dst=packed;const uint8_t*src=scratch;
 for(uint32_t i=0;i<(uint32_t)full;i++)dst[i]=0;
 for(uint32_t y=0;y<h;y++)for(uint32_t x=0;x<w;x++)for(uint32_t c=0;c<components;c++)
  dst[(size_t)y*(size_t)stride+x*components+c]=src[((size_t)y*w+x)*4u+c];
 allocator.release(allocator.context,scratch);
 stage.return_sp=sp+36;stage.format=components==3?0x1907u:0x1908u;stage.row_bytes=(uint32_t)row;
 stage.row_stride=(uint32_t)stride;stage.readable_bytes=(uint32_t)readable;
 stage.owned_bytes=(uint32_t)full;stage.pixels=packed;*out=stage;return 0;
}
