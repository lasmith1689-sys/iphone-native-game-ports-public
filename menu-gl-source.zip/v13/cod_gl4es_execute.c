/* Desktop GL names are confined to this C translation unit. Apple's native
 * GLES/Objective-C worker must never include this desktop GL header. */
#include "cod_gl_dispatch.h"
#include "cod_gl_owned_profile.h"
/* Keep unrelated extension typedefs out of this freestanding object.
 * The two added canonical GL1.3 signatures are declared narrowly below. */
#define GL_GLEXT_LEGACY 1
#include <GL/gl.h>
extern void GLAPIENTRY gl4es_glActiveTexture(GLenum texture);
extern void GLAPIENTRY gl4es_glClientActiveTexture(GLenum texture);

static float f32(uint32_t bits) {
 float value;for(uint32_t k=0;k<4;++k)((uint8_t *)&value)[k]=(uint8_t)(bits>>(8*k));return value;
}
/* Internal worker-only execution. The synchronous UIKit/EAGL owner validates
 * active/current context and originating engine thread before calling here. */
int cod_gl4es_execute(CodGLNativeCall *c,CodGLNativeResult *r) {
 const uint32_t *a=c->words;
 switch(c->function) {
 case COD_GL_FINISH:glFinish();break;
 case COD_GL_SCISSOR:glScissor((GLint)(int32_t)a[0],(GLint)(int32_t)a[1],(GLsizei)(int32_t)a[2],(GLsizei)(int32_t)a[3]);break;
 case COD_GL_ORTHO:glOrtho(c->ortho[0],c->ortho[1],c->ortho[2],c->ortho[3],c->ortho[4],c->ortho[5]);break;
 case COD_GL_ALPHA_FUNC:glAlphaFunc(a[0],f32(a[1]));break;
 case COD_GL_CLEAR:glClear(a[0]);break;
 case COD_GL_CLEAR_COLOR:glClearColor(f32(a[0]),f32(a[1]),f32(a[2]),f32(a[3]));break;
 case COD_GL_VIEWPORT:glViewport((int32_t)a[0],(int32_t)a[1],(int32_t)a[2],(int32_t)a[3]);break;
 case COD_GL_ENABLE:glEnable(a[0]);break;case COD_GL_DISABLE:glDisable(a[0]);break;
 case COD_GL_BLEND_FUNC:glBlendFunc(a[0],a[1]);break;
 case COD_GL_DEPTH_FUNC:glDepthFunc(a[0]);break;case COD_GL_DEPTH_MASK:glDepthMask((GLboolean)a[0]);break;
 case COD_GL_CULL_FACE:glCullFace(a[0]);break;case COD_GL_FRONT_FACE:glFrontFace(a[0]);break;
 case COD_GL_MATRIX_MODE:glMatrixMode(a[0]);break;case COD_GL_LOAD_IDENTITY:glLoadIdentity();break;
 case COD_GL_LOAD_MATRIX_F:glLoadMatrixf(c->matrix);break;
 case COD_GL_PUSH_MATRIX:glPushMatrix();break;case COD_GL_POP_MATRIX:glPopMatrix();break;
 case COD_GL_BEGIN:glBegin(a[0]);break;case COD_GL_END:glEnd();break;
 case COD_GL_COLOR_4F:glColor4f(f32(a[0]),f32(a[1]),f32(a[2]),f32(a[3]));break;
 case COD_GL_TEX_COORD_2F:glTexCoord2f(f32(a[0]),f32(a[1]));break;
 case COD_GL_VERTEX_3F:glVertex3f(f32(a[0]),f32(a[1]),f32(a[2]));break;
 case COD_GL_GEN_TEXTURES:glGenTextures((int32_t)a[0],c->names);break;
 case COD_GL_DELETE_TEXTURES:glDeleteTextures((int32_t)a[0],c->names);break;
 case COD_GL_BIND_TEXTURE:glBindTexture(a[0],a[1]);break;
 case COD_GL_TEX_PARAMETER_I:glTexParameteri(a[0],a[1],(int32_t)a[2]);break;
 case COD_GL_GET_ERROR:r->word=glGetError();break;
 case COD_GL_GET_STRING:r->string=glGetString(a[0]);break;
 case COD_GL_PIXEL_STORE_I:glPixelStorei(a[0],(int32_t)a[1]);break;
 case COD_GL_TEX_IMAGE_2D:{
  if(c->owned_profile_tail&COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1){
   if(c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 ||
      c->owned_profile_tail!=COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1 ||
      a[0]!=0x0de1u || a[1] || a[2] || a[3] || a[4]!=256u || a[5]!=256u ||
      a[6]!=0x1908u || a[7]!=0x1401u || !c->pixels)return COD_GL_ARGUMENT;
   r->pixel_effect=COD_GL_PIXELS_UNCERTAIN_V12;
   glTexSubImage2D(a[0],(GLint)a[1],(GLint)a[2],(GLint)a[3],
       (GLsizei)a[4],(GLsizei)a[5],a[6],a[7],c->pixels);break;
  }
  uint32_t input_format=a[6],input_type=a[7];
  if(a[2]==0x1907u && a[6]==0x1908u){
   if(c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 ||
      a[0]!=0x0de1u || a[5] || a[7]!=0x1401u || !c->pixels)return COD_GL_ARGUMENT;
   input_format=0x1907u; /* The bridge staged three opaque RGB bytes per pixel. */
  }
  if(a[2]==0x8056u || a[2]==0x8050u){
   if(c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 ||
      a[0]!=0x0de1u || a[5] || a[6]!=0x1908u || a[7]!=0x1401u || !c->pixels)return COD_GL_ARGUMENT;
   if(a[2]==0x8050u){
    input_format=0x1907u;
    input_type=0x8363u; /* The bridge packed the input as RGB565. */
   }else{
    input_type=0x8033u; /* The bridge packed the input as RGBA4444. */
   }
  }
  if(c->owned_profile_kind){
   if(c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 || c->owned_profile_tail>=14)return COD_GL_ARGUMENT;
   glTexParameteri(0x0de1u,0x813cu,0);glTexParameteri(0x0de1u,0x813du,(GLint)c->owned_profile_tail);glTexParameteri(0x0de1u,0x8191u,1);
  }
  if(c->pixels)r->pixel_effect=COD_GL_PIXELS_UNCERTAIN_V12;
  glTexImage2D(a[0],(int32_t)a[1],(int32_t)a[2],(int32_t)a[3],(int32_t)a[4],
                           (int32_t)a[5],input_format,input_type,c->pixels);break;}
 case COD_GL_ENABLE_CLIENT_STATE:glEnableClientState(a[0]);break;
 case COD_GL_DISABLE_CLIENT_STATE:glDisableClientState(a[0]);break;
 case COD_GL_VERTEX_POINTER:glVertexPointer((int32_t)a[0],a[1],(int32_t)a[2],c->pixels);break;
 case COD_GL_COLOR_POINTER:glColorPointer((int32_t)a[0],a[1],(int32_t)a[2],c->pixels);break;
 case COD_GL_TEX_COORD_POINTER:glTexCoordPointer((int32_t)a[0],a[1],(int32_t)a[2],c->pixels);break;
 case COD_GL_NORMAL_POINTER:glNormalPointer(a[0],(int32_t)a[1],c->pixels);break;
 case COD_GL_DRAW_ARRAYS:glDrawArrays(a[0],(int32_t)a[1],(int32_t)a[2]);break;
 case COD_GL_DRAW_ELEMENTS:
  if(c->pixels)r->pixel_effect=COD_GL_PIXELS_UNCERTAIN_V12;
  glDrawElements(a[0],(int32_t)a[1],a[2],c->pixels);break;
 case COD_GL_GET_INTEGER_V:glGetIntegerv(a[0],&c->query_integer);break;
 case COD_GL_CLEAR_DEPTH:glClearDepth(c->clear_depth);break;
 case COD_GL_LIGHT_MODEL_F:glLightModelf(a[0],f32(a[1]));break;
 case COD_GL_LIGHT_MODEL_FV:glLightModelfv(a[0],c->fixed_vector);break;
 case COD_GL_MATERIAL_F:glMaterialf(a[0],a[1],f32(a[2]));break;
 case COD_GL_MATERIAL_FV:glMaterialfv(a[0],a[1],c->fixed_vector);break;
 case COD_GL_TEX_ENV_I:glTexEnvi(a[0],a[1],(GLint)(int32_t)a[2]);break;
 case COD_GL_SHADE_MODEL:glShadeModel(a[0]);break;
 case COD_GL_POLYGON_MODE:glPolygonMode(a[0],a[1]);break;
 case COD_GL_ACTIVE_TEXTURE:gl4es_glActiveTexture(a[0]);break;
 case COD_GL_CLIENT_ACTIVE_TEXTURE:gl4es_glClientActiveTexture(a[0]);break;
 case COD_GL_COMPRESSED_TEX_IMAGE_2D:{
  if(c->owned_profile_kind!=COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12 || c->owned_profile_tail>=14)return COD_GL_ARGUMENT;
  GLenum format=a[2]==0x83f0u?0x1907u:0x1908u;
  glTexParameteri(0x0de1u,0x813cu,0);glTexParameteri(0x0de1u,0x813du,(GLint)c->owned_profile_tail);glTexParameteri(0x0de1u,0x8191u,1);
  r->pixel_effect=COD_GL_PIXELS_UNCERTAIN_V12;
  glTexImage2D(a[0],(GLint)(int32_t)a[1],(GLint)format,(GLsizei)(int32_t)a[3],(GLsizei)(int32_t)a[4],0,format,0x1401u,c->pixels);break;}
 case COD_GL_FOG_I:glFogi(a[0],(GLint)(int32_t)a[1]);break;
 case COD_GL_HINT:glHint(a[0],a[1]);break;
 case COD_GL_FOG_F:glFogf(a[0],f32(a[1]));break;
 default:return COD_GL_UNKNOWN;
 }return 0;
}
void cod_gl4es_finish(void) {glFinish();}
