/* Own typed producer policy; never a whole-GL readiness or state check. */
#ifndef COD_GL_FRESH51_POLICY_V1_H
#define COD_GL_FRESH51_POLICY_V1_H
#include "cod_gl_dispatch.h"
enum {COD_GL_FRESH51_VERTEX_PROGRAM_CAP_V1=0x8620u,
      COD_GL_FRESH51_FRAGMENT_PROGRAM_CAP_V1=0x8804u};
/* Called before execute/packed-list recording under the selected profile.
 * Packet storage must be valid native owned storage, never a guest pointer. */
static inline int cod_gl_fresh51_command_refused_v1(const CodGLNativeCall *call){
 if(!call||(uint32_t)call->function>=COD_GL_FUNCTION_COUNT)return 1;
 return call->function==COD_GL_ENABLE&&
  (call->words[0]==COD_GL_FRESH51_VERTEX_PROGRAM_CAP_V1||
   call->words[0]==COD_GL_FRESH51_FRAGMENT_PROGRAM_CAP_V1);
}
#endif
