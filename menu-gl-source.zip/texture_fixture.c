#include "cod_gl_dispatch.h"
#include "cod_gl_owned_profile.h"

#define CHECK(expr) do { if (!(expr)) return __LINE__; } while (0)
#define PIXELS 0x1000u
#define UPLOAD_BYTES (512u*512u*4u)

static uint8_t memory[PIXELS + UPLOAD_BYTES], regs[8960], original_regs[8960];
static _Alignas(16) uint8_t staged[16 + UPLOAD_BYTES + 16];
static CodGLRange ranges[] = {{0x100, 0x400, 3}, {0x600, 0x100, 2}, {PIXELS, UPLOAD_BYTES, 1}};
static CodGL bridge;
static CodGLOwnedProfileV12 profile;
static CodGLTextureFactV12 texture;
static uint32_t calls, allocs, releases, failures, row_length, allocated_bytes, fail_allocate;
static uint32_t requested_format, base_width, max_level, unpack_alignment;
static uint32_t backend_failure;

void *memset(void *destination, int value, size_t length) {
    uint8_t *out = destination;
    for (size_t i = 0; i < length; ++i) out[i] = (uint8_t)value;
    return destination;
}

void *memcpy(void *destination, const void *source, size_t length) {
    uint8_t *out = destination;
    const uint8_t *in = source;
    for (size_t i = 0; i < length; ++i) out[i] = in[i];
    return destination;
}

static int same_bytes(const uint8_t *a, const uint8_t *b, size_t count) {
    for (size_t i = 0; i < count; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

static void put_word(uint8_t *at, uint32_t value) {
    for (uint32_t i = 0; i < 4; ++i) at[i] = (uint8_t)(value >> (8 * i));
}

static int unpack(void *context, CodGLUnpackState *state) {
    (void)context;
    *state = (CodGLUnpackState){0};
    state->alignment = unpack_alignment;
    state->row_length = row_length;
    return 0;
}

static int client(void *context, CodGLClientState *state) {
    (void)context;
    *state = (CodGLClientState){0};
    state->texture_unit_count = 1;
    state->texture_coordinate_base = 4;
    state->attribute_count = 1;
    return 0;
}

static int owned(void *context, uint32_t requested, CodGLOwnedStateV12 *state) {
    (void)context;
    *state = (CodGLOwnedStateV12){0};
    state->profile_kind = COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12;
    state->context_identity = 1;
    state->glstate_identity = 2;
    state->context_generation = 1;
    state->esversion = 2;
    state->unit_count = 1;
    state->max_size = 8192;
    state->alignment = unpack_alignment;
    state->row_length = row_length;
    state->units[0] = texture;
    if (requested && requested == texture.name) {
        state->requested_exists = 1;
        state->requested = texture;
    }
    return 0;
}

static void *allocate(void *context, uint32_t bytes, uint32_t alignment) {
    (void)context;
    ++allocs;
    allocated_bytes = bytes;
    return !fail_allocate && bytes && bytes <= UPLOAD_BYTES && alignment == 16 ? staged + 16 : 0;
}

static void release(void *context, void *buffer) {
    (void)context;
    ++releases;
    if (buffer != staged + 16) ++failures;
}

static int invoke(void *context, CodGLNativeCall *call, CodGLNativeResult *result) {
    (void)context;
    const uint32_t *words = call->words;
    ++calls;
    if (call->function == COD_GL_BIND_TEXTURE) {
        texture = (CodGLTextureFactV12){.identity=3, .name=7, .native_name=17,
                                        .target=0x0de1, .base_level=-1, .max_level=-1};
        return 0;
    }
    CodGLOwnedStateV12 snapshot;
    owned(0, 0, &snapshot);
    if(call->owned_profile_tail & COD_GL_CINEMATIC_SUBIMAGE_PACKET_V1) {
        if(call->function!=COD_GL_TEX_IMAGE_2D || words[4]!=base_width || words[5]!=base_width ||
           words[0]!=0x0de1 || words[1] || words[2] || words[3] || words[6]!=0x1908 || words[7]!=0x1401 ||
           allocated_bytes!=base_width*base_width*4u || call->pixels!=staged+16 ||
           !same_bytes(call->pixels,memory+PIXELS,allocated_bytes) ||
           cod_gl_owned_v13_verify_worker_call(call,&snapshot)) {++failures;return COD_GL_BACKEND;}
        if(backend_failure)return COD_GL_BACKEND;
        result->pixel_effect=COD_GL_PIXELS_COMPLETED_V12;return 0;
    }
    const uint32_t level = words[1];
    const uint32_t width = words[3];
    const uint32_t components = requested_format == 3u ? 4u : requested_format == 0x1907 ? 3u : requested_format == 0x1908 ? 4u : 2u;
    const uint32_t packed_stride = (components*width + unpack_alignment-1u) & ~(unpack_alignment-1u);
    const uint32_t source_stride = (4u*width + unpack_alignment-1u) & ~(unpack_alignment-1u);
    if (call->function != COD_GL_TEX_IMAGE_2D ||
        words[0] != 0x0de1 || level > max_level || width != (base_width >> level) || words[4] != width ||
        words[2] != requested_format || words[5] || words[6] != 0x1908 || words[7] != 0x1401 ||
        call->owned_profile_tail != max_level || call->pixels != staged + 16 ||
        allocated_bytes != packed_stride * width ||
        cod_gl_owned_v13_verify_worker_call(call, &snapshot)) {
        ++failures;
        return COD_GL_BACKEND;
    }
    for (uint32_t y = 0; y < width; ++y) {
        for (uint32_t x = 0; x < width; ++x) {
            const uint8_t *rgba = memory + PIXELS + source_stride*y + 4u*x;
            const uint8_t *packed = staged + 16 + packed_stride*y + components*x;
            if (components >= 3u) {
                for (uint32_t k=0;k<components;k++) if (packed[k]!=rgba[k]) ++failures;
                continue;
            }
            uint16_t expected;
            if (requested_format == 0x8050)
                expected = (uint16_t)((rgba[0]/8u)*2048u + (rgba[1]/4u)*32u + rgba[2]/8u);
            else
                expected = (uint16_t)((rgba[0]/16u)*4096u + (rgba[1]/16u)*256u +
                                      (rgba[2]/16u)*16u + rgba[3]/16u);
            if (packed[0] != (expected & 255u) || packed[1] != (expected >> 8)) ++failures;
        }
        for (uint32_t x = components*width; x < packed_stride; ++x)
            if (staged[16 + packed_stride*y + x] != 0) ++failures;
    }
    if (level == 0) {
        texture.valid = 1;
        texture.width = texture.height = texture.nwidth = texture.nheight = (int32_t)base_width;
        texture.base_level = 0;
        texture.max_level = (int32_t)max_level;
        texture.mipmap_auto = 1;
    }
    if (backend_failure) return COD_GL_BACKEND;
    result->pixel_effect = COD_GL_PIXELS_COMPLETED_V12;
    return 0;
}

static int dispatch(uint32_t token, const uint32_t *words, uint32_t count) {
    memset(regs, 0x5a, sizeof(regs));
    put_word(regs + 16, 0x200);
    put_word(memory + 0x200, 0x4e1030);
    for (uint32_t i = 0; i < count; ++i) put_word(memory + 0x204 + 4*i, words[i]);
    memcpy(original_regs, regs, sizeof(regs));
    return cod_gl_dispatch(&bridge, token, regs, sizeof(regs));
}

__attribute__((visibility("default"))) int texture_fixture(uint32_t internal, uint32_t width, uint32_t alignment, int uncertain) {
    CHECK(internal == 3u || internal == 0x8050 || internal == 0x8056 || internal == 0x1907 || internal == 0x1908);
    CHECK(internal==3u ? cod_gl_cinematic_shape_v13(width,width) : width && width<=16 && !(width&(width-1)));
    CHECK(alignment==1 || alignment==2 || alignment==4 || alignment==8);
    unpack_alignment=alignment; backend_failure=0;
    requested_format = internal;
    base_width = width;
    max_level=0; if(internal!=3u)while ((1u<<max_level)<width) ++max_level;
    uint32_t upload_bytes = ((width*4u+alignment-1u)&~(alignment-1u))*(width-1u)+width*4u;
    calls = allocs = releases = failures = row_length = allocated_bytes = fail_allocate = 0;
    memset(&texture, 0, sizeof(texture));
    ranges[2].bytes = upload_bytes;
    const CodGLMemory guest = {memory, ranges, 3};
    const CodGLAllocator allocator = {0, allocate, release};
    CHECK(!cod_gl_v13_init_owned(&bridge, &profile, COD_GL_PROFILE_NATIVE_COD_FULL_CHAINS_V12,
                                  owned, guest, invoke, unpack, client, 0, allocator, 0x600, 0x100));
    const uint32_t bind[] = {0x0de1, 7};
    CHECK(!dispatch(cod_gl_token("glBindTexture"), bind, 2));
    const uint32_t token = cod_gl_token("glTexImage2D");
    CHECK(token == 0xfed4006c);
    for (uint32_t i = 0; i < UPLOAD_BYTES; ++i) memory[PIXELS+i] = (uint8_t)(17*i+3);
    memset(staged, 0xa5, sizeof(staged));
    uint32_t args[] = {0x0de1, 0, internal, base_width, base_width, 0, 0x1908, 0x1401, PIXELS};
    if (0) {
        CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
        CHECK(calls == 1 && !allocs && !releases && same_bytes(regs, original_regs, sizeof(regs)));
        return 0;
    }
    ranges[2].bytes = upload_bytes - 1;
    CHECK(dispatch(token, args, 9) == COD_GL_MEMORY);
    ranges[2].bytes = upload_bytes;
    args[7] = 0x8033;
    CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
    args[7] = 0x1401; args[6] = 0x80e1;
    CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
    args[6] = 0x1908; args[2] = 0x8057;
    CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
    args[2] = internal; args[8] = 0;
    CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
    args[8] = PIXELS; row_length = 1;
    CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
    row_length = 0;
    if (internal != 0x1908) {
        bridge.owned = 0;
        CHECK(dispatch(token, args, 9) == COD_GL_ARGUMENT);
        bridge.owned = &profile;
    }
    CHECK(calls == 1 && !allocs && !releases && same_bytes(regs, original_regs, sizeof(regs)));
    fail_allocate = 1;
    CHECK(dispatch(token, args, 9) == COD_GL_CAPACITY);
    CHECK(calls == 1 && allocs == 1 && !releases && same_bytes(regs, original_regs, sizeof(regs)));
    fail_allocate = 0;
    if (uncertain) {
        backend_failure=1;
        CHECK(dispatch(token,args,9)==COD_GL_BACKEND);
        CHECK(bridge.failed && bridge.quarantined_pixels==staged+16 && !releases);
        CHECK(bridge.quarantined_bytes==allocated_bytes && calls==2);
        CHECK(same_bytes(regs,original_regs,sizeof(regs)));
        CHECK(dispatch(token,args,9)==COD_GL_BACKEND && calls==2);
        CHECK(!failures); return 0;
    }
    for (uint32_t level = 0; level <= max_level; ++level) {
        args[1] = level; args[3] = args[4] = base_width >> level;
        CHECK(!dispatch(token, args, 9));
        put_word(original_regs + 16, 0x228);
        CHECK(same_bytes(regs, original_regs, sizeof(regs)));
    }
    CHECK(profile.textures[0].provided_mask == (1u << (max_level+1u))-1u);
    CHECK(calls == max_level+2u && allocs == max_level+2u && releases == max_level+1u);
    for (uint32_t i = 0; i < 16; ++i) CHECK(staged[i] == 0xa5 && staged[16+UPLOAD_BYTES+i] == 0xa5);
    CHECK(!failures && !bridge.failed);
    return 0;
}

__attribute__((visibility("default"))) int cinematic_fixture(uint32_t width,uint32_t alignment,int uncertain) {
    CHECK(cod_gl_cinematic_shape_v13(width,width));
    CHECK(!texture_fixture(3u,width,alignment,0));
    const uint32_t token=cod_gl_token("glTexSubImage2D");
    uint32_t args[]={0x0de1,0,0,0,width,width,0x1908,0x1401,PIXELS};
    uint32_t old_calls=calls,old_allocs=allocs,old_releases=releases;
    ranges[2].bytes=width*width*4u-1u;
    CHECK(dispatch(token,args,9)==COD_GL_MEMORY && calls==old_calls && allocs==old_allocs);
    ranges[2].bytes=width*width*4u;
    args[4]=128u;CHECK(dispatch(token,args,9)==COD_GL_ARGUMENT && calls==old_calls);args[4]=width;
    args[5]=width==256u?512u:256u;CHECK(dispatch(token,args,9)==COD_GL_ARGUMENT && calls==old_calls);args[5]=width;
    args[2]=1;CHECK(dispatch(token,args,9)==COD_GL_ARGUMENT && calls==old_calls);args[2]=0;
    int32_t old_native_width=texture.nwidth;texture.nwidth=width==256u?512:256;
    CHECK(dispatch(token,args,9)==COD_GL_ARGUMENT && calls==old_calls);texture.nwidth=old_native_width;
    /* Rejected owner facts may allocate staging, but never leak or invoke. */
    CHECK(allocs-old_allocs==releases-old_releases);
    old_releases=releases;
    for(uint32_t i=0;i<width*width*4u;i++)memory[PIXELS+i]=(uint8_t)(19u*i+71u);
    backend_failure=(uint32_t)uncertain;
    int rc=dispatch(token,args,9);
    if(uncertain){
        CHECK(rc==COD_GL_BACKEND && bridge.failed && releases==old_releases &&
              bridge.quarantined_pixels==staged+16 && bridge.quarantined_bytes==width*width*4u);
        CHECK(same_bytes(regs,original_regs,sizeof(regs)));
        CHECK(dispatch(token,args,9)==COD_GL_BACKEND && calls==old_calls+1u);
    }else{
        CHECK(!rc && !bridge.failed && releases==old_releases+1u && calls==old_calls+1u);
        put_word(original_regs+16,0x228);CHECK(same_bytes(regs,original_regs,sizeof(regs)));
        CHECK(profile.textures[0].width==width && profile.textures[0].height==width &&
              profile.textures[0].tail==0 && profile.textures[0].provided_mask==1u);
    }
    CHECK(!failures);return 0;
}
